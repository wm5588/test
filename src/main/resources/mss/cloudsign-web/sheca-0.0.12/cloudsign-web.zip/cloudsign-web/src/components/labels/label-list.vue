/*

暴露接口：
editLabel(label):
可传入已有的标签信息对标签进行修改
也可不传  则为创建标签


*/

<template lang="html">
    <ul class="label-container">
        <label-item v-for="label in labels"
            :key="label.labelWsid"
            :color="label.color"
            :name="label.text"
            @e-edit="editLabel(label)"
            @e-delete="deleteLabel(label)" />
        <label-edit v-if="editData"
            :labelData="editData"
            @success="getLabelEditData"
            @close="cancleEdit"
            ></label-edit>
    </ul>

</template>

<script>
import labelEdit from '@components/labels/label-edit.vue'
import labelItem from '@components/labels/label-item.vue'
import {delLabels,
        putLabels,
        postLabels} from '@interfaces/labels/labels.js'

export default {
    data(){
        return {
            editData:null
        }
    },
    computed:{
        labels(){
            return this.$store.state.userlabels.labels
        }
    },
    methods:{
        getLabelEditData(name,color){//获取标签返回结果
            if(this.editData.labelId){
                this.updateLabel({
                    labelId:this.editData.labelId,
                    labelName:name,
                    labelColor:color
                })
            }else{
                this.createLabel({
                    labelName:name,
                    labelColor:color
                })
            }

            this.cancleEdit();
        },
        cancleEdit(){//取消编辑
            this.editData = null;
        },
        editLabel(label = {}){
            this.editData = label;
        },
        closeEdit(){
            this.labelEdit = null;
        },
        createLabel(label){
            this.$store.dispatch('labels-create',{
                label
            })
        },
        updateLabel(label){
            this.$store.dispatch('labels-update',{
                label
            })
        },
        deleteLabel(label){
            this.$confirm(`是否删除该标签（${label.text.trim() || '未命名'}）? \n 相关文件也会移除此标签，文件不会删除`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                return this.$store.dispatch('labels-delete', {
                    labelWsid: label.labelWsid
                })
            }).catch(err => {
                console.error(err)
            })
        }
    },
    components:{
        labelItem,
        labelEdit
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

/**
  标签列表
*/
.label-container{
  position:absolute;
  top:420px;
  bottom:0;
  left:0;
  right:0;
  min-height: 200px;
  overflow-y:auto;
  overflow-x: hidden;
  padding-bottom:10px;
}

</style>
