import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path    /api/verifiers/wsid-verify
 * @method  POST
 * @desc    通过WISD验证信封
 * @author  陈曦源
 * @date    2018-03-26 16:34:01
 * ----------------------------------------------------
 */
export function verifyEnvelopByWsid(obj) {
    let {
        files
    } = obj
    
    return axios.post("/api/verifiers/wsid-verify", {
        files
    })
}