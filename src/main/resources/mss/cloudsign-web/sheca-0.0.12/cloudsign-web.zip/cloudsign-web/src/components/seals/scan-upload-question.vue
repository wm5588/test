<!--
    @id        ui-scan-upload-question
    @desc      印章扫码上传操作说明弹框
    @level     UI组件
    @author    潘维
    @date     2018-12-13 09:34:28
-->
<template>
    <div>
        <p class="info">遇到问题<i class="question el-icon-question" @click="dialog=true"></i></p>
         <el-dialog :title="type==='OFFICIAL'?'新建印章':'创建私章'" width="420px" :visible.sync="dialog" append-to-body class="scan-upload-question-dialog">
            <div class="step">
                <div class="left">
                    <p class="info-title">第一步</p>
                    <p class="info-explain">拿出白纸清晰盖印印章；</p>
                </div>
                <div class="right">
                    <img :src="stepOneImg">
                </div>
            </div>
            <div class="step">
                <div class="left">
                    <p class="info-title">第二步</p>
                    <p class="info-explain">手机拍摄第一步盖好的</p>
                    <p class="info-explain">印章，保存为照片即可；</p>
                </div>
                <div class="right">
                    <img :src="stepTwoImg">
                </div>
            </div>
            <div class="step">
                <div class="left">
                    <p class="info-title">第三步</p>
                    <p class="info-explain">扫描二维码，选取第二步</p>
                    <p class="info-explain">保存好的印章照片，即可</p>
                    <p class="info-explain">完成印章上传。</p>
                </div>
                <div class="right">
                    <img :src="stepThreeImg">
                </div>
            </div>
        </el-dialog>
    </div>
</template>
<script>
import stepOneImg from "@images/seals/seal-product-example/step1.png"
import stepTwoImg from "@images/seals/seal-product-example/step2.png"
import stepThreeImg from "@images/seals/seal-product-example/step3.png"
export default {
    props: {
        type: String
    },
    data(){
        return {
            dialog: false,
            stepOneImg: stepOneImg,
            stepTwoImg: stepTwoImg,
            stepThreeImg: stepThreeImg,
        }
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.info{
    text-align: center;
    margin-top: 20px;
    .question{
        color: @color-main;
        padding: 0 5px;
        font-size: 20px;
        cursor: pointer;
    }
}
.step{
    display: flex;
    justify-content: space-around;
    align-items: center;
    margin: 10px 0 ;
    p{
        line-height: 2;
    }
}
.info-title{
    font-size:@font-size-primary;
    color: #323c47;
    text-align: center;
}
.info-explain{
     font-size:@font-size-regular;
     text-align: left;
}
</style>
<style>
.scan-upload-question-dialog .el-dialog__header{
   text-align: center;
   background: rgb(245,245,245)
}
</style>



