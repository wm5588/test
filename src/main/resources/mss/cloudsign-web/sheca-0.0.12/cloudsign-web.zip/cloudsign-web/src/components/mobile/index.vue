<!--
    @id        index
    @desc      移动端主页（显示未签文档）
    @level     system：系统组件
    @author    潘维,陈曦源
    @date      2019-01-04 19:47:58
-->
<template>
    <div class="wesign-mobile-main">
        <div class="user-msg border">
            <avatar class="avatar" size="small"></avatar>
            <div style="display: flex;align-items: center;">
                <span class="user-name">{{userName}}</span>
                <div class="user-msg-info">
                    <userTypeTag :userType="userType" v-if="userType==='ENTE_OWNER'"></userTypeTag>
                    <span class="user-status" @click="toAuth" v-else>
                        <authStatus :status="userAuthStatus"/>
                    </span>
                    <div class="title-user-edition">
                        <span class="account-name">{{activeAccount.name}}</span>
                        <span class="change-user-btn" @click="changeUser">切换<i class="icon-down"></i></span>
                    </div>
                    <mt-popup class="boom" v-model="isShow" position="top">
                        <div class="mint-searchbar">
                            <div class="mint-searchbar-inner input-style">
                                <i class="search el-icon-search"></i> 
                                <input type="search" placeholder="请输入企业/组织名称" class="mint-searchbar-core input-style" @focus="search">
                            </div>
                        </div>
                        <div class="create-enterprise" @click="openCreateOrganization">
                            <i class="icon-enlarge"></i>
                            创建新企业
                        </div>
                        <div class="boom-list border normal" v-for="(account,index) in showResult" 
                            :key="account.id" @click="change(account)" 
                            :class="{active:account.now}">
                            <div style="flex:1;">
                                <i v-if="account.enterprise" class="icon icon-company"></i>
                                <i v-else class="icon icon-user"></i>
                                {{account.name}}
                            </div>
                            <i v-if="account.now" class="active el-icon-check"></i>
                            <!--<i v-if="account.memberStatus=== 'DISABLED'" class="icon-forbid forbid"></i>-->
                        </div>
                        <div class="boom-list more" v-if="accountJoined.length>4" @click="search">
                            <i class="icon icon-company"></i>
                            查看您的更多企业
                        </div>
                    </mt-popup>
                </div>
            </div>
        </div>
        <div class="auth-notice" v-if="!authStatusFlag">
            <span class="icon-notice"></span>
            <div class="notice-text">
                <div v-if="userAuthStatus === 'WAITING'">
                    <p>正在审核,请稍等。</p>
                    <p>加急审核<span style="color: #0c7ffc;">请联系</span><span style="color: #0c7ffc;border-bottom:1px solid  #0c7ffc">4000123918</span></p>
                </div>
                <div v-else-if="userEdition === 'p'" @click="toAuth">
                    <p>您还没有实名认证，《电子签名法》要求签署方身份真实</p>
                    <p>请点击<span style="color: #0c7ffc;border-bottom:1px solid  #0c7ffc">立即认证</span></p>
                </div>
                <div v-else @click="toEnterpriseAuth">
                    <template v-if="enterpriseAuthStatus==='SENIOR_DENY_NAME_REPEAT'">
                        <p>该企业已认证通过，若非本人，请联系相关企业人员加入该企业。若仍然存在问题，请联系人工客服021-962600</p>
                    </template>
                    <template v-else>
                        <p v-if="enterpriseAuthStatus==='WAITING' || enterpriseAuthStatus==='WAITING_SUM'">您的企业实名认证正在审核中，签署文件将存在法律风险</p>
                        <p v-else>您的企业还没有实名认证，签署文件将存在法律风险</p>
                        <p v-if="enterpriseAuthStatus==='WAITING' || enterpriseAuthStatus==='WAITING_SUM'" class="blue">查看</p>
                        <p v-else-if="enterpriseAuthStatus==='WAITING_SUM_CHECK'" class="blue">确认打款</p>
                        <p v-else class="blue">立即认证</p>
                    </template>
                </div>
            </div>
        </div>
        <div v-if="envelopes.length" class="unsign-detail-container" :style="{top:authStatusFlag?'0.8rem':'1.25rem'}">  
            <p class="unsign-total">待我处理文档（{{totalElements}}）</p>
            <div class="doc-list" v-infinite-scroll="loadMore" infinite-scroll-disabled="moreLoading" infinite-scroll-distance="10" infinite-scroll-immediate-check="false">
                 <div :key="index" v-for="(e,index) in envelopes" @click='getEnvelopeDetail(e.envelopeWsid)' class="envelope-list">
                    <div class="doc-detail">
                        <div style="display:flex;align-items: center">
                            <p class="doc-name">{{e.title}}</p> 
                            <span class="doc-bulk-tag" v-if="e.multisendNum">批量</span>
                        </div>
                        <p class="date">{{getDate(e.createdDatetime)}}</p>
                        <p class="send-people">发起方：{{e.sender.username}}</p>
                    </div>
                     <div class="wesign-mobile-tag-me-sign">{{getStatus(e.envelopeStatus)}}</div>
                 </div>
                 <div class="more-loading" v-show="moreLoading">
                    <mt-spinner type="snake" color="#999" :size="20" ></mt-spinner>
                </div>
            </div>   
        </div>
        <div class="unsign-detail-container-no" :style="{top:authStatusFlag?'0.8rem':'1.2rem'}" v-else>
            <div class="bg-pic">
                <img src="../../images/mobile/no-file-bg.png"/>
            </div>
        </div>
        <moreEnterprise ref="moreEnterprise" :data="accountJoined" @changeAccount="change"></moreEnterprise>
   </div>
</template>
<script> 
import { Indicator } from "mint-ui"
import { Spinner } from "mint-ui"
import { InfiniteScroll } from "mint-ui"
import { Toast,MessageBox } from "mint-ui"
import { newFormatDate } from "@commons/util.js"
import avatar from "@components/commons/avatar.vue"
import authStatus from "@components/auth/auth-status.vue"
import moreEnterprise from "./common/more-enterprise.vue"
import userTypeTag from "./common/user-type-tag.vue"
import qs from "qs"

import { getEnvelopes } from "@interfaces/envelopes/index.js"
import { EnvelopeStatus} from "@classes/mobile/envelopes.js"
import { getUserData } from "@interfaces/user/user.js"
import { authFlow } from "@interfaces/openapi/enterprise-authentication.js"
import { checkAuthStatus } from "@commons/check-status.js"
import { startPersonAuthProcess } from '@interfaces/openapi/person-authentication.js'

export default {
    data(){
        return {
            envelopes: [],
            statuses: {
                name: "待我签", 
                statusCodes: ["WAITING_ME_SIGN", "WAITING_ME_CHECK"]
            },
            moreLoading: false,
            totalPages: 20,
            totalElements: 0,
            limit: 10,
            allLoaded: false,
            currentPage: 1,
            enterpriseIdentity: "",
            isShow: false,
        }
    },
    computed: {
        accounts() {
            let activeUserWsid = this.$store.getters.activeUserWsid
            return this.$store.getters.userAccounts.map(account => {
                let name
                let memberStatus

                if (account.enterpriseName) name = account.enterpriseName
                else name = "个人版"

                if (account.memberStatus) memberStatus = account.memberStatus
                let now = false
                if (account.userWsid === activeUserWsid)
                    now = true

                return {
                    name,
                    now,
                    enterprise: !!account.enterpriseName, //是否为企业
                    id: account.userWsid,
                    memberStatus
                }
            })
        },
        // accountsDisabled(){
        //     return this.accounts.filter(account => {
        //         if (account.memberStatus === "DISABLED"){
        //             return account
        //         }
        //     })
        // },
        accountJoined(){
            return this.accounts.filter(account => {
                if (account.memberStatus === undefined || account.memberStatus === "JOINED"){
                    return account
                }
            })
        },
        // accountsSort(){
        //     return this.accountJoined
        // },
        // rearchResult(){
        //     let reg = this.searchEnterpriseName
        //     let arr = this.accountsSort.filter(account => account.name.indexOf(reg) !== -1)
        //     return this.accountsSort.filter(account => account.name.indexOf(reg) !== -1)
        // },
        showResult(){
            let arr = this.accountJoined
            if (arr.length >= 4){
                return arr.slice(0, 4)
            } else {
                return this.accountJoined
            }
        },
        activeAccount() {
            return this.accounts.find(a => a.now)
        },
        userName(){
            return this.$store.getters.userName
        },
        userAuthStatus(){
            return this.$store.getters.userIddtvStatus
        },
        enterpriseAuthStatus(){
            return this.$store.getters.enterpriseIddtvStatus
        },
        enterpriseName(){
            return this.$store.getters.enterpriseName
        },
        userEdition(){
            return this.$store.getters.userEdition
        },
        authStatusFlag(){
            if (this.userEdition === "p" && this.userAuthStatus !== "PASSED"
                || this.userEdition === "e" && this.enterpriseAuthStatus !== "SENIOR_PASSED" && this.enterpriseAuthStatus !== "SENIOR_NO_CERT"){
                return false
            } else {
                return true
            }
        },
        userType(){
            return this.$store.getters.userType
        }
    },
    mounted(){
        if (localStorage.getItem("AUTH_AUTO")){
            if (this.userEdition === "p"){
                if (localStorage.getItem("AUTH_PHONE_LOCK")){
                    this.toAuth({
                        phone: localStorage.getItem("AUTH_PHONE_LOCK"),
                        phonelock: true,
                        username: localStorage.getItem("AUTH_USERNAME_LOCK")
                    })
                    localStorage.removeItem("AUTH_PHONE_LOCK")
                    localStorage.removeItem("AUTH_USERNAME_LOCK")
                } else {
                    this.toAuth()
                }
            }
            localStorage.removeItem("AUTH_AUTO")
        }
    },
    activated(){
        this.envelopes = []
        this.currentPage = 1
        Indicator.open()
        setTimeout(_ => {
            this.getEnvelopesData(this.currentPage)
        }, 333)
        this.allLoaded = false
    },
    methods: {
        openCreateOrganization() {
            let userIddtvStatus = this.$store.getters.userIddtvStatus
            checkAuthStatus(this.$router, userIddtvStatus)
            if (userIddtvStatus == "PASSED"){
                this.$router.replace("crated-organizational")
            } 
        },
        changeUser(){
            this.isShow = !this.isShow
        },
        change(account) {
            if (account.memberStatus === "DISABLED"){
                return
            }
            let destinationWsid = account.id
            Indicator.open()
            this.$store.dispatch("changeUserAccount", destinationWsid).then(_ => {
                this.$router.push("/")
                this.envelopes = []
                this.getEnvelopesData(1)
                this.allLoaded = false
            })
            this.isShow = false
        },
        getEnvelopesData(page){
            let authorWsid = this.$store.getters.activeUserWsid
            let envelopeShownStatus = this.statuses.statusCodes.join(",")
            getEnvelopes({
                authorWsid,
                envelopeShownStatus,
                offset: (page - 1) * this.limit,
                limit: this.limit,
                filters: `currentSequence>=assignedSequence`,
            }).then(res => {
                let body = res.data
                let page = res.data.data.page
                this.envelopes = this.envelopes.concat(body.data.envelopes)
                this.envelopes.forEach(e => {
                    let array = e.sender.username.split(",")
                    if (array.length > 1){
                        e.sender.username = array[1] + " (" + array[0] + ")"
                    }
                })
                this.totalPages = page.totalPages
                this.totalElements = page.totalElements
                if (page.number === page.totalPages){
                    this.allLoaded = true
                }
                return getUserData({
                    userWsid: this.$store.getters.activeUserWsid
                })
            }).then(res => {
                let userInfo = res.data.data.userInfo.user
            }).catch(err => {
                console.error(err)
            }).then(_ => {
                Indicator.close()
                this.moreLoading = false 
            })
        },
        loadMore(){
            if (this.allLoaded){ //加载完所有数据，则不再触发loadMore方法
                Toast({
                    message: "已经加载所有文件了哦",
                    duration: 1000
                })
                this.moreLoading = false
                return
            }
            if (this.currentPage < this.totalPages){
                this.currentPage = this.currentPage + 1 
            }
            else {
                this.moreLoading = false
                return
            }
            this.getEnvelopesData(this.currentPage)
            this.moreLoading = true
        },
        getDate(date){
            return newFormatDate(date, "HH:mm:ss")
        },
        getStatus(status){
            return EnvelopeStatus.getStatusNameByKey(status)
        },
        getEnvelopeDetail(id){
            this.$router.push("/envelopes/" + id + "/detail/")
        },
        toAuth({
            phone = "",
            phonelock = "",
            username = ""
        } = {}) {
            if (this.userEdition === "p"){
                const userContact = this.$store.getters.userContact
                let query = {
                    userContact,
                    phone,
                    username,
                    phonelock
                }
                startPersonAuthProcess({
                    authModes:[],
                    presetPersonAuthentications: [{
                        name: username || this.userName,
                        phone:phone || userContact
                    }],
                    returnUrl: ''
                }).then(res =>{
                    let actionUrl = res.data.data.actionUrl
                    location.href = `${actionUrl}&${qs.stringify(query)}`
                }).catch(err=>{
                    console.error(err)
                })
            }
        },
        toEnterpriseAuth(){
            authFlow({
                returnUrl:`${location.origin}/wesign`
            }).then(res =>{
                let actionUrl = res.data.data.actionUrl
                location.href = actionUrl
            }).catch(err=>{
                if (err.response){
                    let code = err.response.data.code
                    if (code === 101){
                        MessageBox({
                            title: "提示",
                            message: "该企业已认证通过，请勿重复操作",
                            showConfirmButton: true,
                            confirmButtonText: "我知道了"
                        }).then(_ => {}, _ => {}).then(_ => {
                            this.$store.dispatch("updateModule")
                        })
                    } else if(code === 102){
                        let developerMessage = err.response.data.data.msg
                        let erorInfo 
                        if(developerMessage.indexOf("该企业已经注册认证") != -1){
                            erorInfo = `若是本人，请检查自己账号下是否已有该企业。若非本人，请联系相关企业人员加入该企业。若仍然存在问题，请联系人工客服021-962600。`
                        } else {
                            erorInfo =""
                        }
                        MessageBox({
                            title: "提示",
                            message: `<p>${developerMessage}${erorInfo}</p>`,
                            showConfirmButton: true,
                            dangerouslyUseHTMLString: true,
                            confirmButtonText: "我知道了"
                        }).then(_ => {}, _ => {}).then(_ => {
                        })
                    }
                } else {
                    Toast("网络开小差了，请检查您的网络是否正或刷新页面重试")
                }
                console.error(err)
            })
        },
        search(){
            this.$refs.moreEnterprise.open()
        }
    },
    components: {
        avatar,
        authStatus,
        userTypeTag,
        moreEnterprise
    }
}
</script>

<style  lang="less" scoped>
@import "~@styles/variable.less";
.user-msg{
    height: 65*@px;
    background-color: @color-white;
    font-size: @font-size-title;
    display: flex;
    margin-top: 10*@px;
    border-radius: 5*@px;
    box-shadow: rgba(0, 0, 0, 0.06) 0 0 0.2rem 0.01rem;
    align-items: center;
}
.avatar{
    line-height: 65*@px;
    margin: 0 15*@px 0 20*@px;
    display: inline-block;
}
.title-user-edition{
    color: #999999;
    font-size:@font-size-regular;
    padding: 2px 0;
    display: flex;
    align-items: center;
    .account-name{
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 1.35rem;
    }
}
.user-name{
    color: #333333; 
    padding-right: 10*@px;
}
.auth-notice{
    display: flex;
    background: @color-white;
    color:@color-danger;
    font-size:@font-size-regular;
    margin-top: 7*@px;
    .icon-notice{
        font-size: 20*@px;
        padding: 10*@px;
    }
    .notice-text{
        flex:1;
        p{
            display: inline;
            font-size: @font-size-info;
            line-height: 20*@px;
        }
    }
}
.user-msg-info{
    flex: 1;
}
.unsign-detail-container{
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    top: 65*@px
}
.unsign-detail-container-no{
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    top: 65*@px;
    text-align: center;
    .bg-pic{
        position: absolute;
        height: 160*@px;
        width:250*@px;
        left: 50%;
        top: 45%;
        transform: translate(-50%,-50%);
        color: #9b9ea2;
        img{
            width:200*@px;
        }
    }  
}
.doc-list{
    position: absolute;
    left: 0;
    width: 100%;
    top: 30*@px;
    overflow: scroll;
    bottom: 0;
}
.unsign-total{
    font-size: @font-size-primary;
    color:#666;
    height: 33*@px;
    line-height: 33*@px;
    padding-left: 20*@px;
}
.envelope-list{
    background-color: @color-white;
    display: flex;
    position: relative;
    height: 80*@px;
    margin: 0.1rem 0.2rem;
    box-shadow: rgba(0, 0, 0, 0.06) 0 0 0.2rem 0.01rem;
    border-radius: 5px;
}

.doc-detail{
    flex:1;
    padding: 10*@px;
    p{
        line-height: 1.5;
    }
}
.doc-name{
    font-size: @font-size-primary;
    color: @color-title;
    max-width: 200*@px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-block;
}
.doc-bulk-tag{
    font-size: 0.14rem;
    color: #333333;
    width: 0.4rem;
    background: #0c7ffc;
    border-radius: 0.04rem;
    text-align: center;
    color: #fff;
    margin: 0 0.05rem;
    line-height: 1.5;
}
.date{
    font-size: @font-size-info;
    color: @color-main;
}
.send-people{
    font-size: @font-size-info;
    color: #999;
    width: 250*@px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;

}
.more-loading{
    height: 30*@px;
    text-align: center;
    span{
        position: absolute;
    }
}
.change-user-btn{
    border: 1*@px solid #999;
    border-radius: 10*@px;
    height: 15*@px;
    font-size: 12*@px;
    color: #999;
    line-height: 15*@px;
    margin-left: 8*@px;
    padding: 0 2*@px;
}
.boom{
    top: 70*@px;
    background: @color-white;
    width: 100%;
    overflow-y:hidden;
    white-space: nowrap;
    max-height: 260*@px;
    border-radius: 0 0 5*@px 5*@px;
    
    .icon{
        padding-right:10*@px;
    }

    .normal{
        &.active{
            color: @color-main;
        }
    }
}
.boom-list{
    color: #333;
    font-size: @font-size-primary;
    height: 40*@px !important;
    line-height: 40*@px !important;
    border-bottom: 1px solid #e5e9ed;
    display: flex;
    align-items: center;
    padding: 0 20*@px;
}

.gray{
    background:#dcdbdb;
    position:relative;
}
.forbid{
    position:absolute;
    top:12px;
    right:10px;
    color:#81878e;
}
.more{
    color: @color-main;
}
.input-style{
    font-size:@font-size-regular;
    background:rgb(247,247,249)
}
.search{
    padding: 0 5px;
    font-size: @font-size-primary;
    color: rgb(153,153,153);
}
.blue{
    display: inline-block;
    color: #0c7ffc;
    border-bottom:1px solid #0c7ffc
}
.create-enterprise{
    color: @color-success;
    cursor:pointer;
    padding: 10px 40px 10px 20px;
    line-height: 24px;
    font-size:@font-size-primary;
    border-bottom: 1px solid @color-border-segment;

    &:hover{
        background: @color-success;
        color: white;
    }
}
</style>
<style>
.mint-searchbar{
  padding: 2px 10px;
  height:0.4rem;
  background:#fff;
}
.mint-searchbar-cancel{
    display:none;
}
.user-msg-info .v-modal{
    top: 0.7rem;
}
.mint-msgbox-message p{
    line-height: 20px !important;
    font-size: 12px !important;
    text-align: left !important;
}
</style>