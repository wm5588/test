import axios from "@interfaces/axios.js"
/**
 * ----------------------------------------------------
 * @desc  获取生成小程序分享二维码所需参数token
 * @from  GET /api/wechat/get-qr-code
 * @date  2018-09-29 16:15:34
 * ----------------------------------------------------
 */
export function get_token(obj) {
    return axios.get("/api/wechat/get-qr-code")
}

/**
 * ----------------------------------------------------
 * @desc  获取小程序分享二维码
 * @from  GET /api/wechat/get-qr-code
 * @date  2018-09-29 16:15:34
 * ----------------------------------------------------
 */
export function get_qr_code(obj) {
    let {
        access_token,
        path,
        width = 430
    } = obj

    return axios.post("/api/wechat/get-qr-code", {
        access_token,
        path,
        width
    })
}
