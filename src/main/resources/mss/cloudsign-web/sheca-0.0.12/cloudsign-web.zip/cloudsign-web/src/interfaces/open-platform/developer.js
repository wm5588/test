import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   api/developers
 * @method GET
 * @desc   批量查询开发者
 * @author 周雪梅
 * @date   2018-07-18 14:28:24
 * ----------------------------------------------------
 */
export function getDevelopers (obj) {
    let {
        fields = null,
        filters = null,
        offset,
        limit
    } = obj

    return axios.get(`/api/developers`, {
        params: {
            fields,
            filters,
            offset,
            limit
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   api/developers
 * @method POST
 * @desc   创建开发者
 * @author 周雪梅
 * @date   2018-07-16 15:56:39
 * ----------------------------------------------------
 */
export function createdDeveloper (obj) {
    return axios.post(`/api/developers`)
}


/**
 * ----------------------------------------------------
 * @path   /api/developers/applications/:appId/custom-styles
 * @method get
 * @desc   查询一个应用页面自定义风个应用格样式
 * @author 周雪梅
 * @date   2020-06-23 21:13:27
 * ----------------------------------------------------
 */
export function getCustomStyles(obj){
    let {
        appId,
    } = obj

    return axios.get(`/api/developers/applications/${appId}/custom-styles`)
}
