import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/file/contracts
 * @method GET
 * @desc   获取预置合同文档属性信息
 * @author 周雪梅
 * @date   2019-02-14 09:03:51
 * ----------------------------------------------------
 */
export function getContracts() {
    return axios.get("/file/contracts")
}

/**
 * ----------------------------------------------------
 * @desc  文件上传
 * @from  文件微服务-文件上传 | POST /file/upload
 * @date  2017-10-10 13:41:03
 * @author 陈曦源
 * ----------------------------------------------------
 */
export function fileUpload_post(obj) {
    let {
        userWsid,
        name,
        from = "DEFAULT",
        file,
        identifier
    } = obj

    let formdata = new FormData()
    
    formdata.append("file", file)
    formdata.append("properties", JSON.stringify({
        userWsid,
        name,
        from,
        identifier
    }))

    return axios.post(`/file/upload`, formdata)
}