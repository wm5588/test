<!--
    @id        ui-envelops-list
    @desc      信封展示列表
    @level     ui：UI组件
    @props     外部属性
        envelopes:Array 信封列表
    @events
        delete:envelopeId  尝试删除
        preview:envelopeId 尝试预览
        revoke:envelopeId  尝试撤销
        reject:envelopeId  尝试拒绝
    @author    陈曦源
    @date      2018-06-19 14:44:42
-->
<template>
    <div class="envelopes-list-container">
        <div class="envelopes-list-header envelope-col">
            <div class="envelope-title">
                <el-checkbox :disabled="completedEnvelopes.length===0" :value="allChecked" @change="allCheck" v-if="!enterpriseAll"></el-checkbox>
                主题</div>
            <div class="envelope-status-icon">状态</div>
            <div class="envelope-status"></div>
            <div class="envelope-actions">操作</div>
            <div class="envelope-actions-sm">状态/操作</div>
        </div>
        <div class="envelopes-list-body" v-loading="loading">
            <div class="envelopes-list-body-scroll">
                <template v-if="envelopes.length">
                    <EnvelopesListItem v-for="(envelope, index) in envelopes" :envelopes="envelopes" :key="envelope.envelopeWsid" :envelope="envelope" :enterpriseAll="enterpriseAll"
                        @delete="$emit('delete', envelope.envelopeWsid)" @preview="$emit('preview', envelope.envelopeWsid)"
                        @revoke="$emit('revoke', envelope.envelopeWsid)" @reject="$emit('reject', envelope.envelopeWsid)"
                        @notpass="$emit('notpass', envelope.envelopeWsid)"
                        @transfer="$emit('transfer', envelope.envelopeWsid)"
                        @cancel="$emit('cancel', envelope.envelopeWsid, envelope.title)"></EnvelopesListItem>
                </template>
                <div v-else class="envelopes-list-isnull">
                    <img :src="envelopesbg" />
                    <p>翻箱倒柜也没有找到您要的文件</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import EnvelopesListItem from "./envelopes-list-item.vue"
import envelopesbg from "@images/envelopes/mobile-envelopes-bg.png"

export default {
    props: {
        envelopes: Array,
        loading: Boolean,
        enterpriseAll: { //来自查看企业全部文件
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            envelopesbg:envelopesbg
        }
    },
    computed: {
        allChecked(){
            let envelopes = this.completedEnvelopes
            if (envelopes.length === 0) return false
            return envelopes.every(e => e.checked === true)
        },
        completedEnvelopes(){
            return this.envelopes.filter(e => e.envelopeStatus === "SUCCESS_COMPLETED")
        }
    },
    methods: {
        allCheck() {
            let allChecked = this.allChecked
            let envelopes = this.envelopes.filter(e => e.envelopeStatus === "SUCCESS_COMPLETED")
            if (allChecked){
                envelopes.forEach(item => item.checked = false)
            } else {
                envelopes.forEach(item => item.checked = true)
            }
        }
    },
    components: {
        EnvelopesListItem
    }
}
</script>


<style lang="less" scoped>
@import "~@styles/variable.less";

.envelopes-list-container{
    display: flex;
    flex-direction: column;

    .envelopes-list-body{
        z-index: 10;
        position: relative;
        flex:1;
    }

    .envelopes-list-body-scroll{
        position: absolute;
        top:0;
        left: 0;
        height: 100%;
        width: 100%;
        overflow: auto;
    }
}

.envelopes-list-header{
    display: flex;
    height: 20px;
    line-height: 20px;
    padding: 0 20px;
    background-color: #eaeaea;
    .lg-devices({
        height: 40px;
        line-height: 40px;
    });
    .md-devices({
        height: 40px;
        line-height: 40px;
    });
    .envelope-status-icon{
        width: 40px;
        display: none;
        .lg-devices({
            display: inline;
            margin-left:38%;
        });
        
    }
    .envelope-title{
        flex:1;
        width: 100px;
        // margin-left: 10px;
        position: absolute;
    }
    .envelope-status{
        flex:1;
    }
    .envelope-actions{
        width: 350px;
        text-align: left;
        display: none;
        .lg-devices({
            display: inline;
        });
        
    }
    .envelope-actions-sm{
        width: 350px;
        text-align: left;
        margin-left: 50%;
        .lg-devices({
            display: none;
        });
    }
}

.envelopes-list-isnull{
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);

    p{
        text-align:center;
        font-size:@font-size-primary;
        color:rgb(157,157,157);
    }
}
</style>

