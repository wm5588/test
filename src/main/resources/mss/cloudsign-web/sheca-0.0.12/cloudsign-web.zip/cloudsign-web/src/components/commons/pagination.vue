<!-- 分页组件 -->
<template>
	<div class="pagination">
		<ul v-if='maxPage < 7'>
			<li>
				<span v-if='nowPage === 1' class="disable">&lt;&nbsp;上一页</span>
				<a v-else @click='movePage(-1)' data-string='上一页'>&lt;&nbsp;上一页</a>
			</li>
			<li v-for='num in maxPage'>
				<span v-if='num === nowPage' class='current'>{{num}}</span>
				<a @click='gotoPage(num)' v-else>{{num}}</a>
			</li>
			<li>
				<span v-if='nowPage === maxPage' class="disable">下一页&nbsp;&gt;</span>
				<a v-else @click='movePage(1)'>下一页&nbsp;&gt;</a>
			</li>
		</ul>
		<ul v-else>
			<li>
				<span v-if='nowPage === 1' class="disable">&lt;&nbsp;上一页</span>
				<a v-else @click='movePage(-1)'>&lt;&nbsp;上一页</a>
			</li>
			<li v-for='num in pageArr'>
				<span v-if='nowPage == num || num === "..."' :class='{"current":nowPage == num}'>{{num}}</span>
				<a @click='gotoPage(num)' v-else>{{num}}</a>
			</li>
			<li>
				<span v-if='nowPage === maxPage' class="disable">下一页&nbsp;&gt;</span>
				<a v-else @click='movePage(1)'>下一页&nbsp;&gt;</a>
			</li>
		</ul>
	</div>
</template>

<script>
export default{
    props: {
        nowPage: {
            type: Number,
            default: 1
        },
        maxPage: {
            type: Number,
            default: 1
        }
    },
    data: function(){
        return {}
    },
    methods: {
        movePage(num) {
            if (num === 0) 
                return
            
            let newPage = this.nowPage + num

            if (newPage < 1) 
                newPage = 1

            if (newPage > this.maxPage) 
                newPage = this.maxPage
            
            this.gotoPage(newPage)
        },
        gotoPage(page) {
            this.$emit('changePage', page)
        }
    },
    computed: {
        pageArr: function(){
            let me = this
            let arr = []
            if (me.maxPage < 7){
                return arr
            }
            else {
                if (me.nowPage < 6){
                    for (let i = 0; i <= me.nowPage; i++){
                        arr.push(i + 1)
                    }
                    if (me.nowPage == 1){
                        arr.push(3)
                        arr.push('...')
                        arr.push(me.maxPage - 1)
                        arr.push(me.maxPage)
                    }
                    else {
                        if (me.maxPage - me.nowPage < 4){
                            for (let i = me.nowPage + 1; i < me.maxPage;i++){
                                arr.push(i + 1)
                            }
                        }
                        else {
                            arr.push('...')
                            arr.push(me.maxPage - 1)
                            arr.push(me.maxPage)
                        }
                    }
                }
                else if (me.maxPage - me.nowPage < 6){
                    arr.push(1)
                    arr.push(2)
                    arr.push('...')
                    if (me.nowPage === me.maxPage){
                        arr.push(me.nowPage - 2)
                    }
                    for (let i = me.nowPage - 1; i <= me.maxPage;i++)
                        arr.push(i)
                }
                else {
                    arr.push(1)
                    arr.push(2)
                    arr.push('...')
                    arr.push(me.nowPage - 1)
                    arr.push(me.nowPage)
                    arr.push(me.nowPage + 1)
                    arr.push('...')
                    arr.push(me.maxPage - 1)
                    arr.push(me.maxPage)
                }
                return arr
            }
        }
    }
}
</script>

<style scoped>
	a{
		cursor: pointer;
	}
	.pagination ul{
		line-height: 50px;
		list-style: none;
	}
	.pagination ul li{
		display: inline-block;
		margin: 0 5px;
		min-width: 20px;
	}
	.pagination ul li a{
		color:#999;
	}
	.pagination ul li a:hover{
		color:#000;
		border-bottom: 1px solid #000;
	}
	.pagination ul span{
		color:#000;
	}
	.pagination ul span.current{
		color:#fff;
	}
	.current {
		width: 20px;
		text-align: center;
		margin-top: 10px;
		border-radius: 10px;
		background: #619af0;
		display: inline-block;
		line-height: 20px;
	}
    .disable{
        cursor: not-allowed;
    }
</style>