<!--
    @name   sys-auth-status-enterprise
    @desc   当前用户企业实名认证状态
    @level  system
    @auther 陈曦源, 周雪梅
    @date   2018-02-02 10:46:07
-->

<template>
    <authStatus :status="enterpriseIddtvStatus" linkType="ENTERPRISE"></authStatus>
</template>

<script>
import authStatus from "./auth-status.vue"

export default {
    computed: {
        enterpriseIddtvStatus(){
            return this.$store.getters.enterpriseIddtvStatus
        },
    },
    components: {
        authStatus
    }
}
</script>