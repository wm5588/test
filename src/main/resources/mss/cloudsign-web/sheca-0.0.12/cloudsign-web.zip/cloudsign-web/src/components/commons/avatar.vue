<!--
    @desc   用户头像展示组件
    @props
        avatarimg:String    覆盖默认图片
        avatarname:String   覆盖默认名称
        size:String         头像大小 mini small middle large
    @auther 陈曦源
    @date   2018-09-11 16:47:26
-->
<template>
    <div class="avatar-box" :class="sizeClass">
        <img class="avatar-img" v-if="imageSrc && !loadError" :src="imageSrc" alt="头像" @error="imageLoadError" />
        <span v-else class="icon-main-menu-person"></span>
    </div>
</template>

<script>
export default {
    props: {
        avatarname: {
            type: String,
            default: "",
        },
        avatarimg: {
            type: String,
            default: "",
        },
        size: {
            default: "small",
            type: String
        }
    },
    data(){
        return {
            loadError: false
        }
    },
    watch: {
        avatarname(){
            this.loadError = false
        },
        avatarimg(){
            this.loadError = false
        }
    },
    computed: {
        userData() {
            return this.$store.state.userdata
        },
        userName(){
            return this.$store.getters.userName
        },
        imageSrc() {
            if (this.avatarimg)
                return this.avatarimg
            if (this.avatarname)
                return void (0)
            if (this.userData.avatarHref && this.userData.avatarHref.href)
                return this.userData.avatarHref.href
        },
        name() {
            if (this.avatarname){
                if (/^\d+$/.test(this.avatarname)){ //检测为手机号
                    return this.avatarname
                } else if (/@/.test(this.avatarname)){ //检测为邮箱
                    return this.avatarname
                } else {
                    return this.avatarname.substr(-2)
                }
            }

            let fullName = this.userName
            if (fullName)
                return fullName.substr(-2)
        },
        contact() {
            let contact = this.userData.phone || this.userData.email
            return contact
        },
        sizeClass() {
            switch (this.size){
                case "middle": return "avatar-middle"
                case "large": return "avatar-large"
                case "mini": return "avatar-mini"
                case "halfMiddle":return "avatar-half-middle"
                case "mobile":return "avatar-mobile"
                default: return "avatar-small"
            }
        },
    },
    methods: {
        imageLoadError(e){
            this.loadError = true
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

.avatar-box{
    position: relative;
    display:inline-block;
    text-align: center;
    vertical-align:middle;
    background-color: #E8E8E8;
    border-radius: 50%;
    overflow: hidden;
    
    img, .avatar-text{
        float: left;
        vertical-align:middle;
    }

    .avatar-size(mobile,36*@px,14*@px);

    .avatar-size(mini,30*@px,10*@px);
    .avatar-size(small,40*@px,14*@px);
    .avatar-size(middle,80*@px,24*@px);
    .avatar-size(half-middle, 60*@px, 18*@px);
    .avatar-size(large,120*@px,32*@px);
}

.avatar-size(@name, @size, @fontsize){

    &.avatar-@{name}{
        width: @size;
        height: @size;
        line-height: @size;
        font-size: @fontsize;
        color: #999999;

        img, .avatar-text, .icon-main-menu-person{
            width: @size;
            height: @size;
            line-height: @size;
            font-size: @fontsize;
            color: #999999;
        }
    }
}

.avatar-text{
	background-color:#E6E6E6;
    display: inline-block;
    overflow: hidden;
    color:#fff;
}
</style>