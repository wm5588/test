<!--
    @id        sysytem-add-member
    @desc      选择成员
    @level     system：系统组件
    @functions 内部提供给外部的驱动函数
        close():关闭组件
    @author    周雪梅
    @date      2018-12-12 09:36:47
-->
<template>
    <el-dialog width="600px" title="请选择" class="transfer-member-dialog" :visible.sync="dialogVisible" @close="cancle">
        <div class="members-container-box" v-loading="moreLoading" element-loading-text="加载中" ref="container">
                <div class="transter-member-search">
                    <el-input prefix-icon="el-icon-search" size="small" clearable v-model="searchMemberKeyword" @input="searchMember" placeholder="请输入成员姓名/联系方式"></el-input>
                </div>
                <div class="members-container" @scroll="scrollHandler">
                    <template v-if="enterpriseMembers.length > 0">
                        <div v-for="(member, index) in enterpriseMembers" :key="index" class="member-item" :class="member.checked===true ? 'active' :''" @click="selectedMember(member)">
                            <div v-if="member.avatarHref" class="circle">
                                <avatar class="avatar" :avatarimg="member.avatarHref" :avatarname="member.name"/>
                            </div>
                            <div v-else class="circle">
                                   <i class="icon-main-menu-person person"></i> 
                            </div>
                            <div class="user-info"><span class="user-name">{{member.name}}</span>({{member.phone ? member.phone.replace(/(\d{3})\d{6}(\d{2})/, '$1******$2') : member.email}})</div>
                        </div>
                        <center v-if="!pullRefreshss && totalPages>1" style="padding:10px 0;">没有更多了···</center>
                    </template>
                    <div v-else-if="searchMemberKeyword!==''" class="empty-content">
                        <div class="empty">
                            <div>没有查询到此用户</div>
                            <div class="btn" @click="inviteMember"><i class="el-icon-plus"></i> 邀请成员加入企业</div>
                        </div>
                    </div>
                    <div v-if="isEmpty" class="empty-content">
                        <div class="empty">
                            <div>还没有成员加入企业</div>
                            <div class="btn" @click="inviteMember"><i class="el-icon-plus"></i> 邀请成员加入企业</div>
                        </div>
                    </div>
                </div>
                <div style="text-align:right;margin-top:30px">
                    <el-button @click="close">取消</el-button>
                    <el-button type="primary" :loading="transferLoading" :disabled="selectMember" @click="complete">确认</el-button>
                </div>
            </div>
    </el-dialog>
</template>

<script>
import { ifRectIntersect, scrollExtend } from "@commons/util.js"
import SystemLoading from "@commons/system-loading.js"
import { translateParticipantDatasFromEnd } from "@classes/envelopes/participants.js"
import { transferSiginEnvelope } from "@interfaces/envelopes/envelope.js"
import { searchEnterpriseMember } from "@interfaces/enterprise/members.js"
import { checkAuthStatus } from "@commons/check-status.js"
import { getEnvelopeParticipants } from "@interfaces/envelopes/participants.js"
import { getUserRoles } from "@interfaces/policy/enterprise-roles.js"
import avatar from "@components/commons/avatar.vue"

export default {
    data(){
        return {
            dialogVisible: false,
            searchMemberKeyword:"",
            enterpriseMembers:[],
            moreLoading: false,
            pullRefreshss: true, 
            currentPage: 1, //当前页
            totalPages: 1, //总页数
            limit: 10,
            envelopeWsid:"",
            transferLoading:false,
            selectmemberInfo:null,
            participantWsid:"",
            successHandle:null,
            isEmpty:false
        }
    },
    computed: {
        userWsid(){ 
            return this.$store.getters.userWsid
        },
        activeUserWsid(){
            return this.userWsid || this.$store.getters.activeUserWsid
        },
        selectMember(){
            let checked = this.enterpriseMembers.filter(item => item.checked === true)
            if(checked.length > 0){
                return false
            } else {
                return true
            }
        },
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        enterpriseName(){
            return this.$store.getters.enterpriseName
        },
        activeUserParticipantWsid(){ //个人用PUSER 企业用EMEM
            if (this.$store.getters.userEdition === "p"){
                return this.$store.getters.activeUserWsid
            } else {
                return this.$store.getters.memberWsid
            }
        }
    },
    watch: {
        searchMemberKeyword(val){
            if (val === ""){
                this.getEneterpriseMember(1, this.searchMemberKeyword)
            }
        },
        envelopeWsid(nv){
            this.message = "文件内容不符合要求"
            if (!nv) return
            let handler = Promise.resolve()
            if (this.participantWsid) return

            let enterpriseRoles = []
            if (this.$store.getters.userEdition === "e"){
                handler = getUserRoles({
                    authorWsid: this.$store.getters.activeUserWsid
                }).then(res => {
                    enterpriseRoles = res.data.data.enterpriseRoles.map(enterpriseRole => enterpriseRole.wsid)
                })
            }

            handler.then(_ => {
                return getEnvelopeParticipants({
                    envelopeWsid: this.envelopeWsid
                })
            }).then(res => {
                let participants = res.data.data.participants
                let activeUserParticipantWsid = this.activeUserParticipantWsid

                participants = translateParticipantDatasFromEnd(participants)
                    .filter(participant => {
                        return participant.authorWsid === activeUserParticipantWsid || enterpriseRoles.find(r => participant.authorWsid === r)
                    }).filter(participant => {
                        return participant.status === "ING_WAIT" && participant.actionType === "SIGNER"
                    })
                this.participantWsid = participants[0].participantWsid
            }).catch(err => {
                this.envelopeWsid = ""
                this.$message.error("加载转签前置数据失败")
                this.close()
            })
        }
    },
    // created(){
    //     if(this.$store.getters.userEdition === "e"){
    //         this.getEneterpriseMember(1, this.searchMemberKeyword)
    //     }
    // },
    methods: {
        getEneterpriseMember(nowPage, keyword){
            this.moreLoading = true
            this.pullRefreshss = true
            searchEnterpriseMember({
                enterpriseWsid: this.enterpriseWsid,
                filters: "status=JOINED",
                offset: (nowPage - 1) * this.limit,
                limit: this.limit,
                scopes: "nickname,realName,contact,staffNo",
                keyword
            }).then(res => {
                let page = res.data.data.page
                let enterpriseMembers = res.data.data.enterpriseMembers.filter(item => item.memberWsid!== this.$store.getters.memberWsid).map(member => {
                    return {
                        authorWsid: member.authorWsid,
                        memberWsid: member.memberWsid,
                        name: member.realName || member.nickname,
                        phone:member.phone,
                        email:member.email,
                        checked:false,
                        avatarHref:member.avatarHref || ""
                    }
                })

                if(enterpriseMembers.length < 1 && keyword === ''){
                    this.isEmpty = true
                } else {
                    this.isEmpty = false
                }

                if (keyword != "" || nowPage == 1){
                    this.enterpriseMembers = enterpriseMembers
                } else {
                    enterpriseMembers = enterpriseMembers.forEach(item => {
                        this.enterpriseMembers.push(item)
                    })
                }

                this.currentPage = nowPage
                this.totalPages = page.totalPages
                if (page.number == page.totalPages){
                    this.pullRefreshss = false
                }
            }).catch(err => {
                console.log(err)
                this.$message.error("获取更多成员失败")
            }).then(_ => [
                this.moreLoading = false
            ])
        },
        scrollHandler: scrollExtend({
            scrollEnd: function(e){
                let scrollHeight = this.$refs.container.scrollHeight
                let scrollTop = this.$refs.container.scrollTop
                let clientHeight = this.$refs.container.clientHeight
                if (scrollTop + clientHeight >= scrollHeight){
                    if (!this.pullRefreshss){ //加载完所有数据，则不再触发loadMore方法
                        this.moreLoading = false
                        return
                    }
                    if (this.currentPage < this.totalPages){
                        this.currentPage = this.currentPage + 1 
                        this.getEneterpriseMember(this.currentPage, this.searchMemberKeyword)
                        this.moreLoading = true
                    } else {
                        this.moreLoading = false
                        return
                    }
                } else {
                    this.pullRefreshss = true
                }
            }
        }),
        selectedMember(member){
            this.selectmemberInfo = member
            this.enterpriseMembers.filter(item =>{
                if(item.memberWsid === member.memberWsid){
                    item.checked = true
                } else {
                    item.checked = false
                }
            })
        },
        searchMember: function(){
            let handle = null
            let fun = function(){
                let word = this.searchMemberKeyword
                this.getEneterpriseMember(1, word)
            }
            
            return function(){
                clearTimeout(handle)
                let that = this
                let arg = arguments

                handle = setTimeout(_ => {
                    fun.apply(that, arg)
                }, 300)
            }
        }(),
       async transgerMember(envelopeWsid, participantWsid, checkAuth = true){
            this.participantWsid = participantWsid
            if (checkAuth && !await checkAuthStatus(this.$router, this.$store.getters.userIddtvStatus)){
                return Promise.reject()
            }

            this.envelopeWsid = envelopeWsid
            this.dialogVisible = true
            this.getEneterpriseMember(1, this.searchMemberKeyword)
            return new Promise((reslove, reject) => {
                this.successHandle = reslove
                this.cancelHandel = reject
            })
        },
        complete(){
            this.transferLoading = true
            transferSiginEnvelope({
                envelopeWsid: this.envelopeWsid,
                participantWsid: this.participantWsid,
                message: this.message,
                name:this.selectmemberInfo.name,
                contact:{
                    phone: this.selectmemberInfo.phone,
                    email: this.selectmemberInfo.email,
                }
            }).then(res => {
                this.$message.success("转签成功")
                this.successHandle()
                this.successHandle = null
                this.cancelHandel = null
                this.close()
            }).catch(err => {
                this.$message.error("转签失败")
            }).then(_ => {
                this.transferLoading = false
            })
        },
        close(){
            this.searchMemberKeyword =""
            this.dialogVisible = false
        },
        cancle(){
            if (this.cancelHandel) this.cancelHandel()
            this.successHandle = null
            this.cancelHandel = null
        },
        inviteMember(){
            this.close()
            this.$emit("inviteMembe")
        },
    },
    components:{
        avatar
    }
}
</script>

<style lang="less" scoped>
.choose-seals-tabs{
    text-align: center;
}
.members-container{
    margin-top:20px;
    height: 342px;
    overflow: auto;
}
.circle{
    background: #E6E6E6;
    width:36px;
    height: 36px;
    border-radius: 50%;
    text-align: center;
    line-height: 36px;
    font-size: 20px;
    margin-right: 20px;
}
.member-item{
    padding: 10px;
    display: flex;
    align-items: center;
    border-bottom:1px solid #DCDFE6;
    &:hover{
        background: #F9FAFE;
    }
    &:active{
        background: #E6F2FF
    }
}
.active{
    background: #E6F2FF !important;
}
.select{
    font-size:24px;
    margin-right: 30px;
}
.user-info{
    flex:1;
    color:#999;
}
.user-name{
    display: inline-block;
    margin-right: 10px;
    color:#333
}
.empty-content{
    display: flex;
    align-items: center;
    height: 100%;
    justify-content: center;
}
.empty{
    display: block;
    div{
        text-align: center;
    }
    .btn{
        color:#0C7FFC;
        font-size:16px;
        padding: 10px 0;
        &:hover{
            cursor: pointer;
        }
    }
}
.person{
    color:#999
}
</style>
<style lang="less">
.transter-member-search .el-input__inner{
    border-radius: 15px !important;
}
.transfer-member-dialog .el-dialog__header{
    text-align:center;
}
</style>
