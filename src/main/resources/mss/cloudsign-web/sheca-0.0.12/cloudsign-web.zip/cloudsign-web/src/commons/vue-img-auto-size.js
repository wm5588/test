import "./vue-img-auto-size.css";
const ITEMLIST = [];

function inputDOM(dom){
    ITEMLIST.push({
        dom:dom,
        state:0 //1 偏宽 -1 偏高
    });
    dom.className = "vue-img-auto-size"
    if(ITEMLIST.length === 1){
        checkSize();
    }
}

function outputDOM(dom){
    let l = ITEMLIST.length;
    for(let i = 0;i < l;i++){
        if(ITEMLIST[i].dom === dom){
            ITEMLIST.splice(i,1);
            break;
        }
    }
}

function checkSize(){
    if(!ITEMLIST.length) return;
    ITEMLIST.forEach(item => {
        let img = item.dom;
        let parent = img.parentElement;

        if(parent){
            let w = parent.clientWidth;
            let h = parent.clientHeight;
            if(w && h){
                let state = item.state;
                let pd = w / h;
                let d = img.width / img.height;
                if((d - pd) * state <= 0){
                    if(d > pd){
                        img.style.width = '100%';
                        img.style.height = '';
                        state = 1;
                    }else{
                        img.style.width = '';
                        img.style.height = '100%';
                        state = -1;
                    }
                }
            }
        }
    });
    setTimeout(checkSize,1000 / 33);
}


export default {
  install(Vue,options){
    Vue.directive('img-auto-size', {
      inserted (el) {
          inputDOM(el);
      },
      unbind(el){
          outputDOM(el);
      }
    });
  }
};
