<!--
    @id     ui-picture-cut
    @desc   该组件为图片裁剪组件
    @props
        imageSrc:String 需要裁剪的图片的数据
        containerSize:Number 组件区域大小
        minClipSize：Number  裁剪框最小尺寸
    @events
        imagePreviewInfoChange(imageData)   图片预览信息数据改变
    @functions
        growRotate(deg)     以当前旋转度旋转图片: 第一个参数为需要修正的旋转度
        growScale(scale)    以当前的倍数放大图片: 第一个参数为需要放大的倍数
        setScale(scale)     直接设置图片的放大倍数:    第一个参数为需要设置的放大倍数
    @auther 陈曦源
    @date   2019-05-24 09:35:22
-->
<template>
    <div class="clip-main" @dragstart.prevent>
        <div class="clip-info-box" :style="boxStyle" @touchstart.stop.prevent="dragImageStart" @mousedown="dragImageStart" @mousewheel="zoomImage">
            <div class="image-box">
                <img class="cut-img" :src="imageSrcData || imageSrc" :style="imgStyle"/> 
            </div>
            <!--剪裁图片的选取区域-->
            <div class="cut-clip" :style="cilpStyle" @touchstart="dragClipStart" @mousedown="dragClipStart">
                <!-- 8个外围点 -->
                <div class="cut-clip-point top-left"></div>
                <div class="cut-clip-point top-center"></div>
                <div class="cut-clip-point top-right"></div>
                <div class="cut-clip-point center-left"></div>
                <div class="cut-clip-point center-right"></div>
                <div class="cut-clip-point bottom-left"></div>
                <div class="cut-clip-point bottom-center"></div>
                <div class="cut-clip-point bottom-right"></div>
                <!-- 8个监听点  -->
                <div class="cut-clip-point-listen top-left" @touchstart.stop.prevent="dragResizeByAngle($event, 'top-left')" @mousedown.stop="dragResizeByAngle($event, 'top-left')"></div>
                <div class="cut-clip-point-listen top-center" @touchstart.stop.prevent="dragResizeByEdge($event, 'top')" @mousedown.stop="dragResizeByEdge($event, 'top')"></div>
                <div class="cut-clip-point-listen top-right" @touchstart.stop.prevent="dragResizeByAngle($event, 'top-right')" @mousedown.stop="dragResizeByAngle($event, 'top-right')"></div>
                <div class="cut-clip-point-listen center-left" @touchstart.stop.prevent="dragResizeByEdge($event, 'left')" @mousedown.stop="dragResizeByEdge($event, 'left')"></div>
                <div class="cut-clip-point-listen center-right" @touchstart.stop.prevent="dragResizeByEdge($event, 'right')" @mousedown.stop="dragResizeByEdge($event, 'right')"></div>
                <div class="cut-clip-point-listen bottom-left" @touchstart.stop.prevent="dragResizeByAngle($event, 'bottom-left')" @mousedown.stop="dragResizeByAngle($event, 'bottom-left')"></div>
                <div class="cut-clip-point-listen bottom-center" @touchstart.stop.prevent="dragResizeByEdge($event, 'bottom')" @mousedown.stop="dragResizeByEdge($event, 'bottom')"></div>
                <div class="cut-clip-point-listen bottom-right" @touchstart.stop.prevent="dragResizeByAngle($event, 'bottom-right')" @mousedown.stop="dragResizeByAngle($event, 'bottom-right')"></div>
                <!-- 4条外围边 -->
                <div class="cut-clip-outline top" @touchstart.stop.prevent="dragResizeByEdge($event, 'top')" @mousedown.stop="dragResizeByEdge($event, 'top')"></div>
                <div class="cut-clip-outline bottom" @touchstart.stop.prevent="dragResizeByEdge($event, 'bottom')" @mousedown.stop="dragResizeByEdge($event, 'bottom')"></div>
                <div class="cut-clip-outline left" @touchstart.stop.prevent="dragResizeByEdge($event, 'left')" @mousedown.stop="dragResizeByEdge($event, 'left')"></div>
                <div class="cut-clip-outline right" @touchstart.stop.prevent="dragResizeByEdge($event, 'right')" @mousedown.stop="dragResizeByEdge($event, 'right')"></div>
                <!-- 4条内部边 -->
                <div class="cut-clip-inline row"></div>
                <div class="cut-clip-inline col"></div>
                <!-- 中心点 -->
                <div class="cut-clip-center"></div>
            </div>
        </div>
    </div>
</template>

<script>
const MIN_IMAGE_SHOW = 30 //图片至少显示边框距离
const MIN_IMAGE_SCALE = 0.0001 //图片最小缩放比例
const MAX_IMAGE_SCALE = 10 //图片最大缩放比例

export default {
    props: {
        imageSrc: {
            type: String,
            default: ""
        },
        minClipSize: {
            type: Number,
            default: 30
        },
        lockProp: {//锁定比例
            type: Boolean,
            default: false
        },
        containerSizeWidth: {
            type: Number,
            default: 200
        },
        containerSizeHeight: {
            type: Number,
            default: 200
        },
    },
    data() {
        return {
            imgCache: null,
            imageSrcData: "",
            canvas: document.createElement("canvas"),
            realImg: {
                width: 0,
                height: 0
            },
            img: {
                top: 0,
                left: 0,
                width: 0,
                height: 0
            },
            clip: {
                top: 0,
                left: 0,
                width: 0,
                height: 0
            },
            rotate: 0
        }
    },
    computed: {
        boxStyle() {
            return {
                height: `${this.containerSizeHeight}px`,
                width: `${this.containerSizeWidth}px`,
            }
        },
        imgStyle() {
            let img = this.img
            return {
                top: `${img.top}px`,
                left: `${img.left}px`,
                height: `${img.height}px`,
                width: `${img.width}px`,
                transform: `rotate(${this.rotate}deg)`
            }
        },
        cilpStyle() {
            let clip = this.clip
            return {
                top: `${clip.top}px`,
                left: `${clip.left}px`,
                height: `${clip.height}px`,
                width: `${clip.width}px`
            }
        },
        imagePreviewInfo() {
            let image = this.img
            let clip = this.clip

            return {
                imageSrc: this.imageSrcData || this.imageSrc,
                image: {
                    top: image.top - clip.top,
                    left: image.left - clip.left,
                    width: image.width,
                    height: image.height,
                },
                clip: {
                    width: clip.width,
                    height: clip.height,
                },
                rotate: this.rotate
            }
        }
    },
    watch: {
        imageSrc(nv) {
            this.resetImg(this.imageSrc)
        },
        imagePreviewInfo(nv){
            this.$emit("imagePreviewInfoChange", nv)
        },
        containerSizeWidth(nv, ov){
            if (nv != ov){
                this.resetImg(this.imageSrc)
            }
        },
        containerSizeHeight(nv, ov){
            if (nv != ov){
                this.resetImg(this.imageSrc)
            }
        }
    },
    mounted() {
        this.resetImg(this.imageSrc)
    },
    methods: {
        cutImage(width = this.clip.width, height = this.clip.height){
            if (!this.imgCache) return ""
            let img = this.img
            let clip = this.clip
            let canvas = this.canvas
            let containerSize = this.containerSize

            let p = Math.max(width / this.clip.width, height / this.clip.height, 1)

            canvas.width = clip.width * p
            canvas.height = clip.height * p

            let ctx = canvas.getContext("2d")
            ctx.save()
            ctx.clearRect(0, 0, canvas.width, canvas.height)
            ctx.translate((img.left - clip.left + img.width / 2) * p, (img.top - clip.top + img.height / 2) * p)
            ctx.rotate(this.rotate * Math.PI / 180)
            ctx.translate((-img.left + clip.left - img.width / 2) * p, (-img.top + clip.top - img.height / 2) * p)

            let imgRect = {
                x: img.left,
                y: img.top,
                w: img.width,
                h: img.height
            }

            let scale = img.height / this.realImg.height

            ctx.drawImage(this.imgCache, 
                (img.left - clip.left) * p, (img.top - clip.top) * p,
                img.width * p, img.height * p)
                
            return canvas.toDataURL()
        },
        resetImg(src){
            if (!src) return
            this.imgCache = new Image()
            this.imgCache.src = src
            this.imgCache.onload = _ => {
                let realImg = this.realImg
                let imgCache = this.imgCache
                imgCache.onload = null

                //兼容部分手机拍照，会带有EXIF旋转的问题
                let canvas = document.createElement("canvas")
                let p = 1500 / imgCache.width
                canvas.width = imgCache.width * p
                canvas.height = imgCache.height * p
                canvas.getContext("2d").drawImage(imgCache, 0, 0, imgCache.width, imgCache.height, 0, 0, canvas.width, canvas.height)
                src = canvas.toDataURL()
                this.imageSrcData = src

                realImg.width = imgCache.width * p
                realImg.height = imgCache.height * p
                this.imgLoaded()
            }   
        },
        imgLoaded(){
            let realImg = this.realImg
            let img = this.img
            let clip = this.clip
            let box = this.box
            let containerSize = this.containerSize
            let minClipSize = this.minClipSize
            let clipSize
            if (this.containerSizeWidth > this.containerSizeHeight){
                if (realImg.width > realImg.height) {
                    img.width = this.containerSizeWidth
                    img.height = this.containerSizeWidth / realImg.width * realImg.height
                    img.top = (this.containerSizeHeight - img.height) / 2
                    img.left = 0
                    clip.width = this.containerSizeWidth
                    clip.height = this.containerSizeHeight
                    clip.left = (this.containerSizeWidth - this.containerSizeWidth) / 2
                    clip.top = (this.containerSizeHeight - this.containerSizeHeight) / 2
                } else {
                    img.height = this.containerSizeHeight
                    img.width = this.containerSizeHeight / realImg.height * realImg.width
                    img.top = 0
                    img.left = (this.containerSizeWidth - img.width) / 2
                    clipSize = Math.max(minClipSize, img.width)
                    clip.width = this.containerSizeWidth
                    clip.height = clipSize
                    clip.left = (this.containerSizeWidth - this.containerSizeWidth) / 2
                    clip.top = (this.containerSizeHeight - clipSize) / 2
                }
            } else {
                if (realImg.width > realImg.height) {
                    img.width = this.containerSizeWidth
                    img.height = this.containerSizeWidth / realImg.width * realImg.height
                    img.top = (this.containerSizeHeight - img.height) / 2
                    img.left = 0
                    clipSize = Math.max(minClipSize, img.height)
                } else {
                    img.height = this.containerSizeHeight
                    img.width = this.containerSizeHeight / realImg.height * realImg.width
                    img.top = 0
                    img.left = (this.containerSizeWidth - img.width) / 2
                    clipSize = Math.max(minClipSize, img.width)
                }

                clip.width = clipSize
                clip.height = clipSize
                clip.left = (this.containerSizeWidth - clipSize) / 2
                clip.top = (this.containerSizeHeight - clipSize) / 2
            }
        },
        dragImageStart(e){ //拖动图片
            let img = this.img
            let box = this.box
            let containerSizeWidth = this.containerSizeWidth
            let containerSizeHeight = this.containerSizeHeight

            if (e.type === "touchstart"){
                e = e.touches[0]
            }
            let start = {
                x: e.clientX,
                y: e.clientY,
                top: img.top,
                left: img.left,
            }

            let dragImageMove = e => {
                if (e.type === "touchmove"){
                    e = e.touches[0]
                }
                let dx = e.clientX - start.x
                let dy = e.clientY - start.y

                let nleft = start.left + dx
                let ntop = start.top + dy

                if (nleft < MIN_IMAGE_SHOW - img.width) nleft = MIN_IMAGE_SHOW - img.width
                if (ntop < MIN_IMAGE_SHOW - img.height) ntop = MIN_IMAGE_SHOW - img.height
                if (nleft > containerSizeWidth - MIN_IMAGE_SHOW) nleft = containerSizeWidth - MIN_IMAGE_SHOW
                if (ntop > containerSizeHeight - MIN_IMAGE_SHOW) ntop = containerSizeHeight - MIN_IMAGE_SHOW

                img.top = ntop
                img.left = nleft
            }

            let dragImageStop = _ => {
                document.removeEventListener("mousemove", dragImageMove)
                document.removeEventListener("touchmove", dragImageMove)
                document.removeEventListener("mouseup", dragImageStop)
                document.removeEventListener("touchend", dragImageStop)
                document.removeEventListener("selectstart", stopSelect)
            }

            let stopSelect = e => {
                e.preventDefault()
            }

            document.addEventListener("mousemove", dragImageMove)
            document.addEventListener("touchmove", dragImageMove)
            document.addEventListener("mouseup", dragImageStop)
            document.addEventListener("touchend", dragImageStop)
            document.addEventListener("selectstart", stopSelect)
        },
        dragClipStart(e) { //拖动截取框
            let clip = this.clip
            let containerSizeWidth = this.containerSizeWidth
            let containerSizeHeight = this.containerSizeHeight
            if (clip.width === containerSizeWidth && clip.height === containerSizeHeight){ //最大尺不能移动，将事件透传
                return 
            } else {
                e.stopPropagation()
                e.preventDefault()
            }

            if (e.type === "touchstart"){
                e = e.touches[0]
            }
            let start = {
                x: e.clientX,
                y: e.clientY,
                top: clip.top,
                left: clip.left,
            }

            let dragClipMove = e => {
                if (e.type === "touchmove"){
                    e = e.touches[0]
                }
                let dx = e.clientX - start.x
                let dy = e.clientY - start.y

                let nleft = start.left + dx
                let ntop = start.top + dy

                if (nleft < 0) nleft = 0
                if (ntop < 0) ntop = 0
                if (nleft > containerSizeWidth - clip.width) nleft = containerSizeWidth - clip.width
                if (ntop > containerSizeHeight - clip.height) ntop = containerSizeHeight - clip.height

                clip.top = ntop
                clip.left = nleft
            }

            let dragClipStop = _ => {
                document.removeEventListener("mousemove", dragClipMove)
                document.removeEventListener("touchmove", dragClipMove)
                document.removeEventListener("mouseup", dragClipStop)
                document.removeEventListener("touchend", dragClipStop)
                document.removeEventListener("selectstart", stopSelect)
            }

            let stopSelect = e => {
                e.preventDefault()
            }

            document.addEventListener("mousemove", dragClipMove)
            document.addEventListener("touchmove", dragClipMove)
            document.addEventListener("mouseup", dragClipStop)
            document.addEventListener("touchend", dragClipStop)
            document.addEventListener("selectstart", stopSelect)
        },
        dragResizeByAngle(e, anglePosition){
            let ulX = false, //left
                ulY = false, //height
                lrX = false, //top
                lrY = false //width

            if (/^top/.test(anglePosition)){
                ulY = true
            }

            if (/^bottom/.test(anglePosition)){
                lrY = true
            }

            if (/left$/.test(anglePosition)){
                ulX = true
            }

            if (/right$/.test(anglePosition)){
                lrX = true
            }
            let clip = this.clip
            const containerSizeWidth = this.containerSizeWidth
            const containerSizeHeight = this.containerSizeHeight
            let p = containerSizeHeight / containerSizeWidth
            const minClipSize = this.minClipSize
            const lockProp = this.lockProp

            if (e.type === "touchstart"){
                e = e.touches[0]
            }

            const startX = e.clientX
            const startY = e.clientY

            const startTop = clip.top
            const startLeft = clip.left
            const startWidth = clip.width
            const startHeight = clip.height

            let dragAngleMove = e => {
                if (e.type === "touchmove"){
                    e = e.touches[0]
                }

                let dx = e.clientX - startX
                let dy = e.clientY - startY

                if (ulX){
                    let width = startWidth - dx
                    
                    if (width < minClipSize){
                        width = minClipSize
                    }

                    if (width > startLeft + startWidth){
                        width = startLeft + startWidth
                    }

                    dx = startWidth - width
                } else if (lrX){
                    let width = startWidth + dx

                    if (width < minClipSize){
                        width = minClipSize
                    }

                    if (width > containerSizeWidth - startLeft){
                        width = containerSizeWidth - startLeft
                    }

                    dx = width - startWidth
                }

                if (ulY){
                    let height = startHeight - dy
                    
                    if (height < minClipSize){
                        height = minClipSize
                    }

                    if (height > startTop + startHeight){
                        height = startTop + startHeight
                    }

                    dy = startHeight - height
                } else if (lrY){
                    let height = startHeight + dy

                    if (height < minClipSize){
                        height = minClipSize
                    }

                    if (height > containerSizeHeight - startTop){
                        height = containerSizeHeight - startTop
                    }

                    dy = height - startHeight 
                }

                if (lockProp){ //XY都需要计算时才找最小的偏移
                    if (ulX && ulY || lrX && lrY){
                        let min

                        if (ulX && ulY){ //左上角
                            min = Math.min(-dx, -dy)
                        } else if (lrX && lrY){ //右下
                            min = Math.min(dx, dy)
                        }

                        if (min === dx){
                            dy = dx * p
                        } else {
                            dx = dy / p
                        }
                    } else { //两个反向
                        let min = Math.min(Math.abs(dx), Math.abs(dy))
                        if (ulX && lrY){ //左下角
                            min = Math.min(-dx, dy)
                        } else if (lrX && ulY){ //右上
                            min = Math.min(dx, -dy)
                        }

                        if (min === Math.abs(dx)){
                            dy = -dx * p
                        } else {
                            dx = -dy / p
                        }
                    }
                }

                if (ulX){
                    clip.width = startWidth - dx
                    clip.left = startLeft + dx
                } else if (lrX){
                    clip.width = startWidth + dx
                }

                if (ulY){
                    clip.height = startHeight - dy
                    clip.top = startTop + dy
                } else if (lrY){
                    clip.height = startHeight + dy
                }
            }

            let dragAngleStop = _ => {
                document.removeEventListener("mousemove", dragAngleMove)
                document.removeEventListener("touchmove", dragAngleMove)
                document.removeEventListener("mouseup", dragAngleStop)
                document.removeEventListener("touchend", dragAngleStop)
                document.removeEventListener("selectstart", stopSelect)
            }

            let stopSelect = e => {
                e.preventDefault()
            }

            document.addEventListener("mousemove", dragAngleMove)
            document.addEventListener("touchmove", dragAngleMove)
            document.addEventListener("mouseup", dragAngleStop)
            document.addEventListener("touchend", dragAngleStop)
            document.addEventListener("selectstart", stopSelect)
        },
        dragResizeByEdge(e, direction){
            let clip = this.clip
            const containerSizeWidth = this.containerSizeWidth
            const containerSizeHeight = this.containerSizeHeight
            const minClipSize = this.minClipSize
            const lockProp = this.lockProp
            
            if (e.type === "touchstart"){
                e = e.touches[0]
            }

            const startX = e.clientX
            const startY = e.clientY

            const startTop = clip.top
            const startLeft = clip.left
            const startWidth = clip.width
            const startHeight = clip.height
            let p = containerSizeHeight / containerSizeWidth

            let dragEdgeMove = e => {
                if (e.type === "touchmove"){
                    e = e.touches[0]
                }

                let dx = e.clientX - startX
                let dy = e.clientY - startY

                if (direction === "left"){
                    let width = startWidth - dx
                    
                    if (width < minClipSize){
                        width = minClipSize
                    }

                    if (width > startLeft + startWidth){
                        width = startLeft + startWidth
                    }
                    dx = startWidth - width
                    
                    if (lockProp){
                        let max = startHeight - minClipSize
                        let min = Math.max(-startTop * 2, -(containerSizeHeight - startTop - startHeight) * 2)
                        dx = Math.max(Math.min(max, dx), min)
                        clip.left = startLeft + dx
                        clip.width = startWidth - dx
                        clip.top = startTop + dx / 2
                        clip.height = startHeight - dx * p
                    } else {
                        clip.left = startLeft + dx
                        clip.width = startWidth - dx
                    }

                } else if (direction === "right"){
                    let width = startWidth + dx

                    if (width < minClipSize){
                        width = minClipSize
                    }

                    if (width > containerSizeWidth - startLeft){
                        width = containerSizeWidth - startLeft
                    }

                    dx = width - startWidth
                    dy = 0

                    if (lockProp){
                        let min = minClipSize - startHeight
                        let max = Math.min(startTop * 2, (containerSizeHeight - startTop - startHeight) * 2)
                        dx = Math.max(Math.min(max, dx), min)
                        clip.width = startWidth + dx
                        clip.top = startTop - dx / 2
                        clip.height = startHeight + dx * p
                    } else {
                        clip.width = startWidth + dx
                    }
                } else if (direction === "top"){
                    let height = startHeight - dy
                    
                    if (height < minClipSize){
                        height = minClipSize
                    }

                    if (height > startTop + startHeight){
                        height = startTop + startHeight
                    }

                    dy = startHeight - height

                    if (lockProp){
                        let max = startWidth - minClipSize
                        let min = Math.max(-startLeft * 2, -(containerSizeWidth - startLeft - startWidth) * 2)
                        dy = Math.max(Math.min(max, dy), min)
                        clip.height = startHeight - dy
                        clip.top = startTop + dy
                        clip.left = startLeft + dy / 2
                        clip.width = startWidth - dy / p
                    } else {
                        clip.height = startHeight - dy
                        clip.top = startTop + dy
                    }
                } else if (direction === "bottom"){
                    let height = startHeight + dy

                    if (height < minClipSize){
                        height = minClipSize
                    }

                    if (height > containerSizeHeight - startTop){
                        height = containerSizeHeight - startTop
                    }

                    dy = height - startHeight
                    dx = 0
                    
                    if (lockProp){
                        let min = minClipSize - startWidth
                        let max = Math.min(startLeft * 2, (containerSizeWidth - startLeft - startWidth) * 2)
                        dy = Math.max(Math.min(max, dy), min)
                        clip.height = startHeight + dy
                        clip.left = startLeft - dy / 2
                        clip.width = startWidth + dy / p
                    } else {
                        clip.height = startHeight + dy
                    }
                }
            }

            let dragEdgeStop = _ => {
                document.removeEventListener("mousemove", dragEdgeMove)
                document.removeEventListener("touchmove", dragEdgeMove)
                document.removeEventListener("mouseup", dragEdgeStop)
                document.removeEventListener("touchend", dragEdgeStop)
                document.removeEventListener("selectstart", stopSelect)
            }

            let stopSelect = e => {
                e.preventDefault()
            }

            document.addEventListener("mousemove", dragEdgeMove)
            document.addEventListener("touchmove", dragEdgeMove)
            document.addEventListener("mouseup", dragEdgeStop)
            document.addEventListener("touchend", dragEdgeStop)
            document.addEventListener("selectstart", stopSelect)
        },
        zoomImage(e){
            if (e.wheelDelta < 0){
                this.growScale(0.9)
            } else {
                this.growScale(1.1)
            }
            e.preventDefault()
        },
        growRotate(deg) {
            this.rotate = (this.rotate + deg + 360) % 360
        },
        growScale(scale) {
            let nowScale = this.img.width / this.realImg.width
            this.setScale(nowScale * scale)
        },
        setScale(scale){
            let nowScale = this.img.width / this.realImg.width
            let nextScale = scale

            if (nextScale < MIN_IMAGE_SCALE) nextScale = MIN_IMAGE_SCALE
            if (nextScale > MAX_IMAGE_SCALE) nextScale = MAX_IMAGE_SCALE

            if (nowScale === nextScale) return

            let containerSizeWidth = this.containerSizeWidth
            let containerSizeHeight = this.containerSizeHeight
            let dScale = nextScale / nowScale
            let img = this.img
            let box = this.box

            let nowW = img.width
            let nowH = img.height

            let nextW = nowW * dScale
            let nextH = nowH * dScale

            img.width = nextW
            img.height = nextH

            let dW = nextW - nowW
            let dH = nextH - nowH

            let nleft = img.left - dW / 2
            let ntop = img.top - dH / 2

            if (nleft < MIN_IMAGE_SHOW - img.width) nleft = MIN_IMAGE_SHOW - img.width
            if (ntop < MIN_IMAGE_SHOW - img.height) ntop = MIN_IMAGE_SHOW - img.height
            if (nleft > containerSizeWidth - MIN_IMAGE_SHOW) nleft = containerSizeWidth - MIN_IMAGE_SHOW
            if (ntop > containerSizeHeight - MIN_IMAGE_SHOW) ntop = containerSizeHeight - MIN_IMAGE_SHOW

            img.top = ntop
            img.left = nleft
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

.clip-main{
    position: relative;
    box-sizing: content-box;
    border: 10px solid #ccc;
    width:220px;
    height:220px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.clip-info-box{
    position: relative;
}

.image-box{
    position: absolute;
    top:0;
    bottom:0;
    left:0;
    right: 0;   
    overflow: hidden;

    .cut-img{
        position: absolute;
        cursor: pointer;
        user-select: none;
    }
}


.cut-clip{
    position: absolute;
    cursor: move;
    box-sizing: border-box;
    border: 1px solid @color-main;
}

@listen-width: 20px;
@point-width: 7px;

.cut-clip-point{
    z-index: 10;
    position: absolute;
    width: @point-width;
    height: @point-width;
    background: @color-main;

    &.top-left{
        top: 0;
        left: 0;
        transform: translate(-50%, -50%);
    }

    &.top-center{
        top: 0;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    &.top-right{
        top: 0;
        left: 100%;
        transform: translate(-50%, -50%);
    }

    &.center-left{
        top: 50%;
        left: 0;
        transform: translate(-50%, -50%);
    }

    &.center-right{
        cursor: ew-resize;
        top: 50%;
        left: 100%;
        transform: translate(-50%, -50%);
    }

    &.bottom-left{
        top: 100%;
        left: 0;
        transform: translate(-50%, -50%);
    }

    &.bottom-center{
        top: 100%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    &.bottom-right{
        top: 100%;
        left: 100%;
        transform: translate(-50%, -50%);
    }
}

.cut-clip-point-listen{
    z-index: 11;
    position: absolute;
    width: @listen-width;
    height: @listen-width;
    background: transparent;

    &.top-left{
        cursor: nw-resize;
        top: 0;
        left: 0;
        transform: translate(-50%, -50%);
    }

    &.top-center{
        cursor: ns-resize;
        top: 0;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    &.top-right{
        cursor: ne-resize;
        top: 0;
        left: 100%;
        transform: translate(-50%, -50%);
    }

    &.center-left{
        cursor: ew-resize;
        top: 50%;
        left: 0;
        transform: translate(-50%, -50%);
    }

    &.center-right{
        cursor: ew-resize;
        top: 50%;
        left: 100%;
        transform: translate(-50%, -50%);
    }

    &.bottom-left{
        cursor: ne-resize;
        top: 100%;
        left: 0;
        transform: translate(-50%, -50%);
    }

    &.bottom-center{
        cursor: ns-resize;
        top: 100%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    &.bottom-right{
        cursor: nw-resize;
        top: 100%;
        left: 100%;
        transform: translate(-50%, -50%);
    }
}

.cut-clip-outline{
    z-index: 10;
    position: absolute;

    .row(){
        cursor: ns-resize;
        height: @listen-width;
        left: @listen-width / 2;
        right: @listen-width / 2;
        transform: translate(0, -50%);
    }

    &.top{
        .row;
        top:0;
    }

    &.bottom{
        .row;
        top:100%;
    }

    .col(){
        cursor: ew-resize;
        width: @listen-width;
        top: @listen-width / 2;
        bottom: @listen-width / 2;
        transform: translate(-50%, 0);
    }

    &.left{
        .col;
        left:0;
    }

    &.right{
        .col;
        left:100%;
    }
}

.cut-clip-inline{
    position: absolute;

    &.row{
        height: 100% / 3;
        bottom: 100% / 3;
        left: 0;
        right: 0;
        border-top: 1px dashed @color-white;
        border-bottom: 1px dashed @color-white;
    }

    &.col{
        top: 0;
        bottom: 0;
        left: 100% / 3;
        right: 100% / 3;
        border-left: 1px dashed @color-white;
        border-right: 1px dashed @color-white;
    }
}

.cut-clip-center{
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;

    &::before, &::after{
        content: "";
        position: absolute;
        display: block;
        background: @color-white;
    }

    &::before{
        top: -3.5px;
        left: -0.5px;
        width: 1px;
        height: 7px;
    }

    &::after{
        top: -0.5px;
        left: -3.5px;
        width: 7px;
        height: 1px;
    }
}
</style>
