<template lang="html">
    <div class="change-main">
        <div class="header">
            <div class="header-left">
                <a href="https://web-sign.djqian.com">
                    <img class="logo" :src="logoWhiteURL">
                </a>
            </div>
        </div>
        <div class="change-container">
            <h2 class="pic-title">选择您要进入的组织</h2>
            <div class="change-organization">
                <ul>
                    <li class="change-radio" v-for="(account, index) in accountJoined" :label="account.id" :key="account.id" :type="account.now ? 'info' : 'default'">
                        <a class="organization" @click="selectOrganization(account.id)">
                            <i v-if="account.now" class="icon-radio-checked checked"></i>
                            <i v-else class="icon-radio-unchecked unchecked"></i>
                            <span class="organization-name">{{account.name}}</span>
                        </a>
                        <span class="recharge" @click.stop.prevent="selectRecharge(account.id)">充值</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script>
import logoWhiteURL from "@images/wesign-logo-white.svg"
export default {
    data(){
        return {
            logoWhiteURL: logoWhiteURL,
            checkModel: false
        }
    },
    computed: {
       accounts() {
            let activeUserWsid = this.$store.getters.activeUserWsid
            return this.$store.getters.userAccounts.map(account => {
                let name
                let memberStatus

                if (account.enterpriseName) name = account.enterpriseName
                else name = "个人版"

                if (account.memberStatus) memberStatus = account.memberStatus
                let now = false
                if (account.userWsid === activeUserWsid)
                    now = true

                return {
                    name,
                    now,
                    enterprise: !!account.enterpriseName, //是否为企业
                    id: account.userWsid,
                    memberStatus
                }
            })
        },
        // accountsDisabled(){
        //     return this.accounts.filter(account => {
        //         if (account.memberStatus === "DISABLED"){
        //             return account
        //         }
        //     })
        // },
        accountJoined(){
            return this.accounts.filter(account => {
                if (account.memberStatus === undefined || account.memberStatus === "JOINED"){
                    return account
                }
            })
        },
        // accountsSort(){
        //     return this.accountJoined.concat(this.accountsDisabled)
        // },
    },
    created(){
        this.checkModel = this.accountJoined.find(a => a.now).id
    },
    methods: {
        selectOrganization(destinationWsid){
            this.$store.dispatch("changeUserAccount", destinationWsid).then(_ => {
                this.$router.replace("/")
            }).catch(err => {
                this.$message.error("切换失败")
            })
        },
        selectRecharge: function (destinationWsid) {
            this.$store.dispatch("changeUserAccount", destinationWsid).then(res => {
               this.checkModel = this.accountJoined.find(a =>a.id == destinationWsid).id
                if(/^WSID_EUSR/.test(destinationWsid)){
                    this.$router.replace("/enterprise/purchase")
                } else {
                    this.$router.replace("/person/purchase")
                }
            })
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.el-button{
    width:96%;
    margin: auto;
    display: block;
    margin-bottom: 10px;
}
.pic-title{
    margin-top: 16*@px;
    margin-bottom: 10*@px;
    text-align:center;
    font-size: 18*@px;
    color: #333;
}
.header{
    // .info-block-default;
    background:@color-main;
    height:60px;
    line-height:60px;
    padding:0 20px;
    color:@color-main;
    .header-left {
        float: left;
        line-height:60px;

        .logo{
            width: 100px;
        }
    }
}
.change-container{
    width: 96%;
    max-width:400*@px;
    min-width: 280px;
    height: auto;
    min-height:400*@px;
    position: absolute;
    top:14%;
    left:0;
    right:0;
    margin:0 auto;
    background:@color-white;
    box-shadow:@shadow-default;
    border-radius: 6px;
    padding-top:30px;
    z-index:99;
}
.change-organization{
    margin-top:40px;
    max-height: 300px;
    overflow: auto;

    ul{
        display:block;
        list-style:none;
        margin:0 auto;
        max-width:230px;
        li{
            margin:20px auto;
            position:relative;
            a {
                display: flex;
                align-items: center;
                cursor:pointer;
            }
            i{
                margin-right:10px;
                font-size:14px;
            }
        }
    }
}
.organization{
    width:200px;
    .organization-name{
        width:200px;
        display:inline-block;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
    }
}
.recharge{
    color:@color-warning;
    margin-left:10px;
    position:absolute;
    top:0;
    right:0;
    z-index:99;
    display:inline-block;
    cursor:pointer;
}
.checked{
    color:@color-main
}
.unchecked{
    color:@color-font-regular
}
</style>