function TranslateRuleToEnd(rule){
    let array = [{
        type: "FIXED_IDENTIFICATION",
        name: "固定标识",
        sequence: 1,
        pattern: rule.numberMark,
        description: ""
    },
    {
        type: "TYPE_SEPARATOR",
        name: "类型分隔符",
        sequence: 2,
        pattern: "-",
        description: "横线分隔符"
    },
    {
        type: "DATE",
        name: "日期",
        sequence: 3,
        pattern: rule.dateType,
        description: ""
    },
    {
        type: "TYPE_SEPARATOR",
        name: "类型分隔符",
        sequence: 4,
        pattern: "-",
        description: "横线分隔符"
    },
    {
        type: "SERIAL_NUMBER",
        name: "流水号",
        sequence: 5,
        pattern: rule.serialNumber,
        description: "",
        autoDigitIncrease: true,
        counterPeroid: "YEAR"
    }]
    return array
}
export {
    TranslateRuleToEnd
}
export default {
    TranslateRuleToEnd
}