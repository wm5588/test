import axios from "@interfaces/axios.js"
import SparkMD5 from "spark-md5"

/**
 * ----------------------------------------------------
 * @path   /api/users/sessions
 * @method POST
 * @desc   用户登录
 * @author 陈曦源
 * @date   2019-07-01 14:50:38
 * ----------------------------------------------------
 */
function sessions_post(obj) {
    let {
        accountNumber = "",
        password = "",
        verificationCode = "",
        loginType = "WEB"
    } = obj
    password = SparkMD5.hash(password)

    return axios.post("/api/users/sessions", {
        accountNumber,
        password,
        verificationCode,
        loginType
    })
}
export {sessions_post, sessions_post as login}

/**
 * ----------------------------------------------------
 * @path   /api/users/sessions-verification-code
 * @method POST
 * @desc   验证码登录
 * @author 陈曦源
 * @date   2018-03-12 20:18:02
 * ----------------------------------------------------
 */
export function verificationCodeSession(obj) {
    let {
        contact,
        destinationWsid,
        enableAutoRegist,
        opcode
    } = obj

    return axios.post("/api/users/sessions-verification-code", {
        contact,
        destinationWsid,
        enableAutoRegist,
        opcode
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/sessions-signing-object
 * @method POST
 * @desc   第三方平台验证非系统用户自动注册
 * @author 周雪梅
 * @date   2019-02-20 15:53:58
 * ----------------------------------------------------
 */
export function signingObjectSession(obj) {
    let {
        contact,
        destinationWsid,
        enableAutoRegist,
        opcode
    } = obj

    return axios.post("/api/users/sessions-signing-object", {
        contact,
        destinationWsid,
        enableAutoRegist,
        opcode
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/security-token/sessions
 * @method POST
 * @desc   token兑换弱权限session
 * @author 陈曦源
 * @date   2019-04-24 16:37:04
 * ----------------------------------------------------
 */
export function getSessionBySecurityToken(obj) {
    let {
        securityToken,
        loginType
    } = obj

    return axios.post("/api/users/security-token/sessions", {
        securityToken,
        loginType
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/sessions
 * @method GET
 * @desc   获取用户sessions数据，可以用于验证
 * @author 陈曦源
 * @date   2018-01-26 20:45:30
 * ----------------------------------------------------
 */
export function getSessionData() {
    return axios.get("/api/users/sessions")
}

/**
 * ----------------------------------------------------
 * @desc  用户登出
 * @from  用户中心微服务API-Session | DELETE /users/sessions
 * @date  2017-08-29 9:14:34
 * ----------------------------------------------------
 */
export function session_logout() {
    return axios.delete("/api/users/sessions")
}