import "script-loader!@commons/compatible-localstorage.js"

import Vue from "vue"
//vue-router 引入
import VueRouter from "vue-router"
Vue.use(VueRouter)

//vuex 引入
import Vuex from "vuex"
Vue.use(Vuex)

//element-ui 引入
import {
    Row,
    Col,
    Tag,
    Form,
    FormItem,
    Message,
    MessageBox,
    Notification,
    Loading,
    Input,
    Button,
    Dropdown,
    Dialog,
    Popover,
    InputNumber,
    Tabs,
    TabPane,
    Table,
    TableColumn,
    Checkbox,
    CheckboxGroup,
    Steps,
    Step,
    Radio,
    RadioGroup,
    RadioButton,
    Select,
    Option,
    Menu,
    Submenu,
    MenuItem,
    MenuItemGroup,
    Pagination,
    DatePicker,
    Transfer,
    Autocomplete,
    Tooltip,
    Tree,
    Carousel,
    CarouselItem,
    Cascader,
    Switch,
    Badge,
    Progress,
    Card,
    InfiniteScroll
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Tag)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Input)
Vue.use(Button)
Vue.use(Dropdown)
Vue.use(Dialog)
Vue.use(Popover)
Vue.use(Loading.directive)
Vue.use(InputNumber)
Vue.use(Tabs)
Vue.use(TabPane)
Vue.use(Checkbox)
Vue.use(CheckboxGroup)
Vue.use(Table)
Vue.use(TableColumn)
Vue.use(Steps)
Vue.use(Step)
Vue.use(Radio)
Vue.use(RadioGroup)
Vue.use(RadioButton)
Vue.use(Select)
Vue.use(Option)
Vue.use(Menu)
Vue.use(Submenu)
Vue.use(MenuItem)
Vue.use(MenuItemGroup)
Vue.use(Pagination)
Vue.use(DatePicker)
Vue.use(Transfer)
Vue.use(Autocomplete)
Vue.use(Tooltip)
Vue.use(Tree)
Vue.use(Carousel)
Vue.use(CarouselItem)
Vue.use(Cascader)
Vue.use(Switch)
Vue.use(Badge)
Vue.use(Progress)
Vue.use(Card)
Vue.use(InfiniteScroll)
Vue.prototype.$loading = Loading.service
Vue.prototype.$message = Message
Vue.prototype.$msgbox = MessageBox
Vue.prototype.$alert = MessageBox.alert
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$prompt = MessageBox.prompt
Vue.prototype.$notify = Notification

//easyLoading 引入
import EasyLoading from "@commons/vue-easy-loading.js"
Vue.use(EasyLoading)

//imgAutoSize 引入
import ImgAutoSize from "@commons/vue-img-auto-size.js"
Vue.use(ImgAutoSize)

import imagesFullscreenPreview from "@commons/images-fullscreen-preview.js"
Vue.use(imagesFullscreenPreview)

//fileDrop 引入
import fileDrop from "@commons/vue-file-drop.js"
Vue.use(fileDrop)

//MD5加密
import SparkMD5 from "spark-md5"
window.SparkMD5 = SparkMD5

//引入vue-grid-layout
import VueGridLayout from "vue-grid-layout"
window.VueGridLayout = VueGridLayout

//引入draggable
import draggable from "vuedraggable"
Vue.component("draggable", draggable)

//注册imagebox
import imgBox from "@components/commons/img-box.vue"
Vue.component("ws-img-box", imgBox)
