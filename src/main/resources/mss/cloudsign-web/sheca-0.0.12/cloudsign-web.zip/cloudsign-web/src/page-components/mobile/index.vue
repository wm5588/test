<!--
    @id        documens
    @desc      移动端查看信封列表页
    @level     system：系统组件
    @author    潘维
    @date      2018-02-27 16:05:42
-->
<template lang="html">
    <div>
        <!-- 主要内容-->
        <keep-alive>
            <router-view></router-view>
        </keep-alive>

        <!-- 底部-->
        <mt-tabbar class="footer-tab" :value="selected"  @input='input'>
            <mt-tab-item id="user">
                <div slot="icon" v-if="selected === 'user'" class="icon icon-nav-bar-select-home"></div>
                <div slot="icon" v-else class="icon icon-nav-bar-home"></div>主页
            </mt-tab-item>
            <mt-tab-item id="envelopes">
                <div slot="icon" v-if="selected === 'envelopes'" class="icon icon-nav-bar-select-file"></div>
                <div slot="icon" v-else class="icon icon-nav-bar-file"></div>文件
            </mt-tab-item>
            <mt-tab-item id="me">
                <div slot="icon" v-if="selected === 'me'" class="icon icon-nav-bar-select-user"></div>
                <div slot="icon" v-else class="icon icon-nav-bar-user"></div>我的
            </mt-tab-item>
        </mt-tabbar>
    </div>
</template>

<script>
    import modalTip from "@components/modal/modal.vue"
    import { session_logout } from "@interfaces/user/sessions.js"

    export default {
        data(){
            return {
                fheader: true,
            }
        },
        computed: {
            selected(){
                let path = this.$route.path
                if (!path || /^\/$|user/.test(path)){
                    return "user"
                }
                if (/envelopes/.test(path)){
                    return "envelopes"
                }
                if (/me/.test(path)){
                    return "me"
                }
            }
        },
        methods: {
            input(s){
                this.$router.push(s)
            },
            loginout: function(){
                this.$store.dispatch("user_logout").then(_ => {
                    this.$router.push("/login")
                })
            }
        },
        components: {modalTip}
    }

</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.footer-tab{
    height: 49*@px;

    .mint-tab-item{
        display: flex;
        justify-content: center;
        flex-direction: column;
    }
}

.mint-tabbar > .mint-tab-item{
    color: #1a1a1a;
}
.mint-tabbar > .mint-tab-item.is-selected {
    color: @color-main; 
    background: none;
}
</style>

<style lang="less">
@import "~@styles/variable.less";
.footer-tab{
    .mint-tab-item-icon{
        height: 18*@px;
        width: 18*@px;

        .icon{
            font-size: 18*@px;
        }
    }

    .mint-tab-item-label{
        font-size: 11*@px;
    }
}
</style>