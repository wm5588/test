import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @desc  验证是否微信账号绑定了大家签账号 || 绑定微信账号和大家签账号
 * @from  用户中心微服务API-Session | POST /users/extra-account/sessions
 * @date  2018-09-29 16:15:34
 * ----------------------------------------------------
 */
export function extra_account_sessions(obj) {
    let {
        uniqueCode,
        type = "WECHAT",
        sessionWsid
    } = obj

    return axios.post("/api/wechat/sessions", {
        uniqueCode,
        type,
        sessionWsid
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/unbind-extra-account
 * @method DELETE
 * @desc   第三方帐号解绑
 * @author 周雪梅
 * @date   2019-04-01 16:20:39
 * ----------------------------------------------------
 */
export function unbindExtraAccount(obj) {
    let {
        uniqueCode,
        type = "WECHAT"
    } = obj
    
    return axios.delete("/api/wechat/unbind-extra-account", {
        uniqueCode,
        type
    })
}