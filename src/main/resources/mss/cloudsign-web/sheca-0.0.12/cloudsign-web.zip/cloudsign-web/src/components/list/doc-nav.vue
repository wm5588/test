<!-- 我的中心左边列表组件 -->
<template>
	<div class="list-container">
		<ul>
			<li v-for="l in listItems" class="list-group" >
				<a :class="{'list-group-item-active':l.name===active}" class="list-group-item" @click='change(l.name)'>
					<i class="list-group-item-img" :class='l.icon'></i>
					<span class="list-group-item-cont">{{l.name}}</span>
				</a>
			</li>
		</ul>
	</div>
</template>

<script>
	import list from './list.vue'
	export default{
		extends: list,
		props:{
			active:{
				type:String,
				default:'全部文件'
			}
		},
		data:function(){
			return{
				listItems:[
					{name:'全部文件',icon:'icon-folder'},
					{name:'待我签署',icon:'icon-me-deal'},
					{name:'等待他人签署',icon:'icon-others-deal'},
					{name:'已完成',icon:'icon-done'},
					{name:'草稿',icon:'icon-draft'}
				]
			}
		},
		methods:{
			change:function(name){
				this.$emit('change-active',name);
			}
		}
	}
</script>

<style scoped>
	.list-group-item-img{
		margin-left: 45px;
	}
	.list-group a{
		font-size:16px;
	}
</style>
