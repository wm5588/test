const path = require("path")
const moduleAlias = require("module-alias")

moduleAlias.addAliases({
    "$exit": path.resolve(__dirname, "./routes/api-router/exit.js"),
    "$HMAC": path.resolve(__dirname, "./routes/api-router/HMAC.js"),
    "$error": path.resolve(__dirname, "./routes/api-router/error.js"),
    "$main": path.resolve(__dirname),
    "$config": path.resolve(__dirname, "./config.js"),
})