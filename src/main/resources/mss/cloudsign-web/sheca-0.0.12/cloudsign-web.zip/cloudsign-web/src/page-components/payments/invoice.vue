<template>
    <div>
        <div class="invoice-container">
            <div class="posR">
                <a @click='showInvoice=true' class="btn-blue-small">申请发票</a>&nbsp;
                <span class="error">注:单次发票申请金额不得少于500元</span>
            </div>
            <div class="records">
                <table class="record-table">
                    <thead>
                        <tr class="records-htr">
                            <td class="records-htd td-per1">发票抬头</td>
                            <td class="records-htd td-per1">金额（元）</td>
                            <td class="records-htd td-per1">状态</td>
                            <td class="records-htd td-per1">申请日期</td>
                            <td class="records-htd td-per1">处理日期</td>
                            <td class="records-htd td-per1">备注</td>
                        </tr>
                    </thead>
                    <tbody id="records-det" v-if='invoices.length === 0'> 
                        <tr class="records-btr"><td colspan="6" class="records-btd">暂无记录</td></tr>
                    </tbody>
                    <tbody id="records-det" v-else> 
                        <tr class="records-btr" v-for='i in invoices'>
                            <td class="records-btd">{{i.header}}</td>
                            <td class="records-btd">{{i.sum}}</td>
                            <td class="records-btd"
                                :class='[{"warn":i.state==="审核未通过"},{"success":i.state==="审核通过"},{"info":i.state==="正在审核"}]'
                            >{{i.state}}</td>
                            <td class="records-btd">{{getDate(i.applyDate,'yyyy-MM-dd hh:mm')}}</td>
                            <td class="records-btd">{{i.completedDate?getDate(i.completedDate,'yyyy-MM-dd hh:mm'):''}}</td>
                            <td class="records-btd">{{i.remarks}}</td>
                        </tr>
                    </tbody>
                </table>	
            </div>
        </div>
        <div class="page">
            <pagination :nowPage='nowPage'
             :maxPage='maxPage' 
             @changePage='changePage' 
             @nextOrlast='nextOrlast'></pagination>
        </div>
        <invoice @close-invoice='close' :dialogInvoiceVisibel='showInvoice'></invoice>
    </div>
</template>

<script>
    import pagination from '@components/commons/pagination.vue'
    import invoice from '@components/modal/invoice-modal.vue'
    import {get_invoices} from '@interfaces/payments/payments.js'
    export default{
        data:function(){
            return {
                nowPage:1,
                maxPage:1,
                showInvoice:false,
                invoices:[],
            }
        },
        components:{
            pagination,invoice
        },
        created:function(){
            this.getInvoices();
        },
        methods:{
            getInvoices:function(){
                let me = this;
                get_invoices({
                    sortings:'-apply_date',
                    page:me.nowPage
                }).then(data => {
                    this.invoices = data.invoices;
                    this.nowPage = data.nowPage;
                    this.maxPage = data.totalPage;
                }).catch(err => {
                    console.log(err);
                })
            },
            close:function(str){
                this.showInvoice = false;
                if(str){
                    this.nowPage = 1;
                    this.getInvoices();
                }
            },
            getDate:function(date,str){
                return FORMATDATE(date,str);
            },
            changePage:function(p){
                this.nowPage = p;
                this.getInvoices();
            },
            nextOrlast:function(string){
                let me = this;
				if(string === '上一页'){
					me.nowPage = me.nowPage - 1;
				}
				else{
					me.nowPage = me.nowPage + 1;
				}
                me.getInvoices();
            }
        }
    }
</script>

<style lang="less" scoped>
    @import '../../styles/user/invoice-claim.less'; 
</style>