import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path  /api/enterprises/search
 * @method GET
 * @desc  通过企业名称查找企业信息
 * @author 陈曦源
 * @date  2019-04-17 15:49:57
 * ----------------------------------------------------
 */
export function searchEnterprise(obj) {
    let {
        keyWords,
        scope
    } = obj

    return axios.get("/api/enterprises/search", {
        params: {
            keyWords,
            scope
        }
    })
}