<!--6位验证码输入框组件-->
<template>
 <div class="verification">
    <div class="input-wrapper" v-for="item in amount" :key="item">
        <input type="password" v-focus="(item - 1) === currentIndex" maxlength="1" 
            @input="handleInput($event,(item-1))" 
            @keyup.delete="onDelete($event,(item-1))"  
            autofocus
            v-model="code[item-1]">
    </div>
  </div>
</template>
 
<script>
export default {
    props: {
        amount: {
            type: Number,
            default: 6
        },
    },
    directives: {
        focus: {
            componentUpdated: function (el, obj) {
                obj.value && el.focus()
            }
        }
    },
    data () {
        return {
            code: [],
            currentIndex: 0,
        }
    },
    computed: {
        autofocus(){
            return true
        }

    },
    created () {
        this.code = new Array(this.amount).fill("")
    },
    methods: {
        handleInput (e, index) {
            this.currentIndex = index
            e.target.value = this.validateNumber(e.target.value)
            if (e.target.value !== ""){
                this.currentIndex++
            }
            this.$emit("input", this.code.join(""))
        },
        onDelete (e, index) {
            if (e.target.value === "") {
                this.currentIndex = index - 1
            }
        },
        validateNumber (val) {
            return val.replace(/\D/g, "")
        },
    },
}
</script>

<style lang="less" scoped>
  .verification{
    width:60%;
    display: flex;
    justify-content: center;
    margin: 20px auto;

    .input-wrapper{
      border-left: 1px solid #D6D6D6;
      border-top: 1px solid #D6D6D6;
      border-bottom: 1px solid #D6D6D6;
      width: 15%;
      height: 40px;
      position: relative;
      &:last-child{
          border-right: 1px solid #D6D6D6;
      }

      input{
        position: absolute;
        width: 100%;
        height: 100%;
        text-align: center;
        transition: all 0.3s;
        color: #333333;
        border: none;
        outline: none;
        padding: 0;
      }

    }
  }
</style>