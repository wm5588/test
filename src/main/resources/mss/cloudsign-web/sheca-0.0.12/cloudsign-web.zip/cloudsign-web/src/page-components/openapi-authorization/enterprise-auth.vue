<!--
    @id        page-enterprise-auth
    @desc      企业实名认证主页
    @level     page：页面组件
    @author    周雪梅
    @date      2019-02-27 14:20:32
-->
<template>
    <div class="wrap" v-loading="loadingAuthData">
        <div class="main-container" v-if="authEnterprise">
            <h2 class="company-name">企业认证</h2>
            <div class="container">
                <div class="step-box">
                    <el-steps class="progress" align-center :active="processStep" finish-status="finish">
                        <el-step description="提交材料"></el-step>
                        <el-step description="系统审核"></el-step>
                        <el-step description="系统打款"></el-step>
                        <el-step description="核对验证"></el-step>
                    </el-steps>
                </div>
                <div v-if='step === 0' class="auth-container">
                    <h2 class="oranization-name">{{stateInfo.enterpriseName}}</h2>
                    <div class="enterprise-info-box">
                        <p><span>统一社会信用代码：</span> {{unifiedSocialCode}}</p>
                        <p><span>企业名称： </span>{{stateInfo.enterpriseName}}</p>
                        <p v-if="stateInfo.authType == 'LEGAL_PERSON'"><span>法人姓名： </span>{{stateInfo.name}}</p>
                        <p v-if="stateInfo.authType == 'AGENT'"><span>经办人姓名： </span>{{stateInfo.name}}</p>
                        <p><span>身份证号： </span>{{stateInfo.idCardNo}}</p>
                        <p><span>手机号： </span>{{stateInfo.phone}}</p>
                        <p><span>银行名称：</span>{{stateInfo.bank}}</p>
                        <p><span>银行支行名称：</span>{{stateInfo.bankBranch}}</p>
                        <p><span>银行卡号：</span>{{stateInfo.bankCardNo}}</p>
                    </div>
                    <p v-show="showEnterpriseAuthInfo" class="public-title"><el-button size="large" class="auth-result-btn submit-btn" type="primary" :loading="loadingAuthNext" @click="submitVerifyIdentities">提交认证</el-button></p>
                </div>
                <div v-if='step === 2' class="auth-container">
                    <div class="auth-result">
                        <p class="auth-await-title">材料审核通过，等待系统打款</p>
                        <p><i class="icon-wait2 wait icon"></i></p>
                        <p class="pic-explain">系统将在24小时内向您预留的对公账号汇入0.01元，<br/>转账记录的交易附言/摘要/备注<span class="error">附有4位核对码</span>，<br/>请在收到汇款后回填核对码完成认证。</p>
                        <div>
                            <p class="size-info">温馨提示：可通过网上银行、手机银行、银行柜台查看转账记录。</p>
                            <p class="size-info" @click="helpFindCode"><i class="el-icon-question question"></i><span class="underline">如何查找核对码？</span></p>
                        </div>
                    </div>
                </div>
                <div v-if='step === 3' class="auth-container">
                    <stepSenior v-if="idttInfo" :iddtvData="idttInfo" @success="authSuccess" @error="authErr"></stepSenior>
                </div>
                <div v-if='step === 4' class="auth-container">
                    <div class="auth-result">
                        <p class="auth-await-title">认证结果</p>
                        <p><i class="icon-complete icon right"></i></p>
                        <p class="auth-await-title right">认证成功</p>
                        <p class="right">恭喜您,企业认证已通过</p>
                        <p class="hint" v-if="returnUrl!== 'DEFAULT' && this.invokeNo === this.oldInvokeNo">{{countDown}}s后自动跳转</p>
                        <el-button v-if="sameOwner===false" @click="successNext" type="primary" class="auth-result-btn" >下一步</el-button>
                        <el-button v-if="returnUrl!=='DEFAULT' && type==='WAITING_SUM'" type="primary" class="auth-result-btn" @click="goBack">返回</el-button>
                        <el-button v-if="returnUrl!=='DEFAULT' && type!=='WAITING_SUM' && this.invokeNo === this.oldInvokeNo" type="primary" class="auth-result-btn" @click="goBack">返回</el-button>
                    </div>
                </div>
                <div v-if='step === 5' class="auth-container">
                    <div class="auth-result">
                        <p class="auth-await-title">认证结果</p>
                        <p><i class="icon-refuse2 icon error"></i></p>
                        <p class="auth-await-title error">认证失败</p>
                        <p class="error">对不起,{{getDate(idttInfo.submitDatetime)}}提交的企业认证已失败</p>
                        <p class="error reason">原因:{{idttInfo.description}}</p>
                        <p class="hint" v-if="returnUrl!== 'DEFAULT'">请返回重新认证</p>
                        <p class="hint" v-if="type!=='WAITING_SUM'">{{countDown}}s后自动跳转</p>
                        <p class="hint" v-if="returnUrl!== 'DEFAULT' && type ==='WAITING_SUM'">{{countDown}}s后自动跳转</p>
                        <el-button v-if="type ==='WAITING_SUM' && returnUrl!== 'DEFAULT'" type="primary" class="auth-result-btn" @click="openAPIAuthCompleteJump('ERROR')">返回</el-button>
                        <el-button v-if="type!=='WAITING_SUM'" type="primary" class="auth-result-btn" :loading="loadingReAuth" @click="reAuth('RETURN')">返回</el-button>
                    </div>
                </div>
                <div v-if='step === 6' class="auth-container">
                    <div class="auth-result">
                        <p class="auth-await-title"> 材料提交成功，等待系统审核</p>
                        <p><i class="icon-wait2 wait icon"></i></p>
                        <p class="pic-explain">系统将会在24小时内完成审核，<br>审核结果将通过短信或邮件通知您，请耐心等待</p>
                    </div>
                </div>
            </div>
        </div>
        <div v-if="applyEnterpriseOne" class="main-container">
            <h2 class="company-name">申请加入企业</h2>
            <div class="container">
                <div class="auth-container apply-enterprise">
                    <p><i class="icon-user-plus icon"></i><i class="icon-arrow-right arrow-right icon"></i><i class="icon-company icon"></i></p>
                    <h2 class="oranization-name">{{stateInfo.enterpriseName}}</h2>
                    <div class="apply-box">
                        <div class="hint">
                            本企业已在电子签约平台完成认证
                        </div>
                        <div class="apply-line hint">
                            <p>系统主管理员是<span class="font-normal">* {{enterpriseAuthorName.substr(1)}} &nbsp;({{(enterpriseAuthorContact).replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')}})</span></p>
                            <!--<p>代表企业进行签约活动，需要管理员审核同意</p>-->
                            <span class="font-normal">请主管理员登录签约系统添加新帐号{{stateInfo.name}} &nbsp; ({{(stateInfo.phone).replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')}})</span>
                        </div>
                        <!-- <div class="question-box">
                            <p @click="gotoHelp"><i class="el-icon-question question"></i><span class="underline">如何添加新帐号？</span></p>
                            <p @click="gotoHelp"><i class="el-icon-question question"></i><span class="underline">如何变更主管理员？</span></p>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <div v-if="applyEnterpriseTwo" class="main-container">
            <h2 class="company-name">申请加入企业</h2>
            <div class="container">
                <div class="auth-container apply-enterprise">
                    <p><i class="icon-complete icon right"></i></p>
                    <h2 class="oranization-name">{{stateInfo.enterpriseName}}</h2>
                    <div class="apply-box">
                        <div class="hint">
                            本企业已在电子签约平台完成认证
                        </div>
                        <div class="apply-line">
                            <p>{{(stateInfo.phone).replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')}}, {{stateInfo.name}}</span></p>
                            <span class="hint">已作为签约人加入企业帐号，可代表企业进行签约活动</span>
                        </div>
                        <!-- <div class="question-box">
                            <p @click="gotoHelp"><i class="el-icon-question question"></i><span class="underline">如何签署一份文件？</span></p>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <div class="signit">
            <img :src="signit" style="width:20px">由大家签提供技术支持
        </div>
        <el-dialog title="提示" width="340px" v-if="stateInfo.enterpriseNames" :visible.sync="accountDialogVisble" :close-on-click-modal="true" :show-close="false" :modal-append-to-body="false">
            <div class="enterprise-auth-dialog">
                <p class="line">数据异常：你的帐号下有多个相同企业待认证</p>
                <p>如何解决？</p>
                <p>1.请登录电脑版https://web-sign.djqian.com到账户设置下删除多余企业</p>
                <p class="line">2.仍无法解决请联系客服021-962600</p>
                <div class="enterprise-auth-header-dialog"><span>企业名称</span><span>认证状态</span></div>
                <div class="enterprise-auth-content" v-for="(item, index) in enterpriseNames">
                    <div>{{index + 1}}.<span>{{item.enterpriseName}}</span> <authStatus :status="item.idttvStatus"></authStatus></div>
                </div>
            </div>
            <div style="text-align:center;margin-top:30px">
                <el-button type="primary" @click="closeAccountVisble">退出</el-button>
            </div>
        </el-dialog>
        <el-dialog title="已收到打款，如何查找核对码？" class="check-code-box-dialog" :visible.sync="checkCodeDialogVisble" :close-on-click-modal="true" :modal-append-to-body="false">
            <div class="enterprise-auth-dialog check-code-dialog">
                <p class="hint">企业材料审核通过，系统会向您预留的对公帐号汇入0.01元的金额，转帐记录的交易附言/摘要/备注附有4位核对码，收到汇款后回填核对码完成认证。温馨提示：可通过手机银行、网上银行、银行柜台查询的转帐记录单</p>
                <div style="margin:0 auto">
                    <p class="line-height">1、手机网上银行查找核对码，以【农业银行】为例</p>
                    <div class="pic-img-box">
                        <bigImg :src="receipt1" :width="300" :height="450"></bigImg>
                    </div>
                    <p class="line-height">2、附言中查找核对码的示例图</p>
                    <div class="pic-img-box"><bigImg :src="receipt" :width="300"></bigImg> </div>
                    <p class="line-height">3、摘要中查找核对码的示例图</p>
                    <div class="pic-img-box"><bigImg :src="receipt2" :width="300" :height="160"></bigImg></div>
                    <p class="line-height">4、备注中查找核对码的示例图</p>
                    <div class="pic-img-box"><bigImg :src="receipt3" :width="300"></bigImg></div>
                    <p class="line-height">友情提醒：</p>
                    <p class="red-hint">使用MBNK-手机银行（分行版）交易的用户，你的核对码是舍弃转出方帐号后剩余的数字</p>
                    <div class="pic-img-box"><bigImg :src="receipt4" :width="300"></bigImg></div>
                </div>
            </div>
            <div style="text-align:center;padding-top:15px">
                <el-button type="primary" @click="checkCodeDialogVisble= false">关闭</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import config from "@configs"

import {
    enterpriseAuth,
    getVerifications, 
    getVerificationInfo,
    resetAuthStatus, examine, enterpriseCheck} from "@interfaces/auth/auth.js"
import { newFormatDate } from "@commons/util.js"
import stepPrimary from "@components/openapi-authorization-auth/verifications/step-primary.vue"
import stepSenior from "@components/openapi-authorization-auth/verifications/step-senior.vue"
import authStatus from "@components/auth/auth-status.vue"
import { createEnterprise} from "@interfaces/enterprise/enterprise.js"
import { getUserAccounts, changeSession,getUserData, checkAccount} from "@interfaces/user/user.js"

import querystring from "querystring"
import { LoginLocalStatus } from "@classes/login/login-info.js"
import receipt from "@images/openapi-authorization/receipt.jpg"
import receipt1 from "@images/openapi-authorization/receipt1.png"
import receipt2 from "@images/openapi-authorization/receipt2.jpg"
import receipt3 from "@images/openapi-authorization/receipt3.png"
import receipt4 from "@images/openapi-authorization/receipt4.jpg"
import signit from "@images/openapi-authorization/logo-ico.png"

import bigImg from "@components/commons/big-img.vue"

export default {
    data(){
        return {
            /* 企业认证状态：
             * INCOMPLETE-未认证
             * WAITING-等待审核
             * PRIMARY_PASSED-初级认证
             * PRIMARY_DENY-认证未通过
             * WAITING_SUM-等待打款
             * WAITING_SUM_CHECK-确认打款(等待用户汇款信息确认)
             * SENIOR_PASSED-高级认证(用户汇款信息确认成功),
             * SENIOR_DENY-认证未通过(打款失败/汇款验证失败)
             * SENIOR_NO_CERT-高级认证(但颁发证书失败),
             */
            loadingAuthData: false,
            loadingAuthNext: false,
            loadingReAuth: false,
            loadingNext: false, //创建企业时的按钮loading

            idttInfo: null,
            step: 0,

            isCreatedEnterprise: false, //是否创建企业（下一步）
            showEnterpriseAuthInfo: false, //是否显示提交认证按钮

            name: "",
            phone: "",
            unifiedSocialCode: "",
            returnUrl: "",
            // userWsid: "",
            invokeNo: "",
            oldInvokeNo: "",
            targetIdttvWsid: "",
            type: "",

            idttvStatus: "",
            
            enterpriseWsid: "",
            idttvWsid: "",
            // authoreWsid: "",
            euserInfo: null,
            authPass: "",
            sameUnifiedSocialCode: "", //统一社会信用代码是否一致
            
            enterpriseNames: [],
            accountDialogVisble: false, //多个相同企业信息展示弹框
            checkCodeDialogVisble:false,

            countDown: 0,
            intervalHandle: null,

            applyEnterpriseOne: false, //申请加入企业未加入
            applyEnterpriseTwo: false,//申请加入企业已加入
            authEnterprise: true,
            enterpriseAuthorName: "", //企业创建者姓名
            ownerHasEnterprise: "",//用户是否拥有企业
            sameOwner: "",//拥有者
            accounts: [],

            receipt: receipt,
            receipt1: receipt1,
            receipt2: receipt2,
            receipt3: receipt3,
            receipt4: receipt4,
            signit: signit,

            loginLocalStatus: new LoginLocalStatus(),
            enterpriseAuthorContact: "",
            targetUserId:"",
        }
    },
    computed: {
        stateInfo(){
            return this.$store.state
        },
        userWsid(){
            return this.$store.state.userWsid
        },
        activeUserWsid(){
            return this.$store.state.activeUserWsid
        },
        processStep(){
            let step = this.step
            switch (step){
                case 0: return 0; break
                case 6: return 1; break
                case 2: return 2; break
                case 3: return 3; break
                case 5: return this.idttvStatus === 'PRIMARY_DENY' ? 2 : 4; break
                case 4: return 4; break
            }
        },
    },
    created(){
        let query = location.search.slice(1)
        query = querystring.parse(query)
        this.unifiedSocialCode = query.unifiedSocialCode || query.registCode
        this.targetIdttvWsid = query.idttvWsid
        this.returnUrl = decodeURIComponent(query.returnUrl) || "DEFAULT"
        this.invokeNo = query.invokeNo
        this.type = query.type
        this.checkEnterprise()
    },
    methods: {   
        helpFindCode(){
            this.checkCodeDialogVisble = true
        },
        getDate(date){
            return newFormatDate(date * 1000, "HH:mm:ss")
        },
        goSignit(){
            location.href = config.url.app
        },
        closeAccountVisble(){
            this.accountDialogVisble = false
            this.isCreatedEnterprise = false
            this.loginLocalStatus.setLogin(false)
            this.$router.push({
                path: "/",
                query: this.$route.query
            })
        },
        async checkEnterprise(){
            this.loadingAuthData = true
            await getUserAccounts({
                userWsid: this.userWsid,
                limit: 10000
            }).then(res => {
                // let authoreWsid = res.data.data.accounts.find(account => account.userType == "PERSON").userWsid
                // this.authoreWsid = authoreWsid
                this.accounts = res.data.data.accounts
                if(this.targetIdttvWsid) {
                    let euserInfo = res.data.data.accounts.filter(account => account.enterpriseName === this.stateInfo.enterpriseName && account.idttvWsid === this.targetIdttvWsid)[0]
                    if(euserInfo){
                        this.euserInfo = euserInfo
                    } else {
                       this.euserInfo = res.data.data.accounts.filter(account => account.enterpriseName === this.stateInfo.enterpriseName)[0]
                    }
                } else {
                    let euserInfo = res.data.data.accounts.filter(account => account.enterpriseName === this.stateInfo.enterpriseName)
                    if(euserInfo.length > 1){
                        let passAuthAccount = euserInfo.filter(item => item.idttvStatus === "SENIOR_PASSED" || item.idttvStatus === "SENIOR_NO_CERT")
                        if(passAuthAccount){
                            this.authEnterprise = false
                            this.applyEnterpriseTwo = true
                        } else {
                            this.accountDialogVisble = true
                            this.enterpriseNames = euserInfo
                        }
                    } else {
                        this.euserInfo = euserInfo[0]
                    }
                }
            }).catch(err => {
                this.loadingAuthData = false
                console.error(err)
            })
            
            enterpriseCheck({
                ownerWsid:this.userWsid,
                enterpriseName: this.stateInfo.enterpriseName,
                unifiedSocialCode: this.unifiedSocialCode,
                notifyIfSameUnifiedSocialCode: false,
                invokeNo:this.invokeNo
            }).then(res => {
                let authResult = res.data.data.result
                this.authPass = authResult.pass
                this.sameUnifiedSocialCode = authResult.sameUnifiedSocialCode
                this.enterpriseAuthorName = authResult.passedEnterpriseAuthorName
                this.enterpriseWsid = authResult.passedEnterpriseWsid
                if(authResult.ownerHasEnterprise == true){
                    this.authorEnterpiserWsid = authResult.enterpriseAuthorWsid
                    this.enterpriseWsid = authResult.enterpriseWsid
                    this.idttvWsid = authResult.idttvWsid 
                    let idttvStatus = authResult.idttvStatus
                } else {
                    if(authResult.pass=== true){
                        getUserData({
                            userWsid:authResult.passedEnterpriseAuthorWsid
                        }).then(res =>{
                            let enterpriseAuthorContact = res.data.data.userInfo.user.phone || res.data.data.userInfo.user.email
                            this.enterpriseAuthorContact = enterpriseAuthorContact
                        }).catch(err =>{
                            console.error(err)
                        })
                    }
                }
                this.ownerHasEnterprise = authResult.ownerHasEnterprise
                this.sameOwner = authResult.sameOwner

                if (authResult.exist === true){
                    if(this.ownerHasEnterprise===true){
                        let targetUserId = this.euserInfo.userWsid
                        this.targetUserId = this.euserInfo.userWsid
                        this.enterpriseWsid = this.euserInfo.enterpriseWsid
                        if(targetUserId === this.userWsid){
                            this.getAuthId().then(id => {
                                return this.getAuthInfo()
                            }).then(_ => {
                            }).catch(err => {
                                this.$message.error("获取认证信息数据失败")
                            })
                        } else {
                            this.activeIdentity()
                        }
                    } else {
                        if(this.authPass === false){
                            this.createEnterprise()
                        } else {
                            if(this.sameUnifiedSocialCode == false ||this.sameOwner===false){
                                this.enterpriseCheck()
                                this.$router.push({
                                    name: "enterprise-authentication",
                                    query: this.$route.query
                                })
                            } else {
                                if(this.euserInfo){
                                    let result = this.accounts.find(item => item.enterpriseWsid === this.enterpriseWsid)
                                    if(result){
                                        if(result.memberStatus === "JOINED" && (result.idttvStatus=="SENIOR_PASSED" || result.idttvStatus === "SENIOR_NO_CERT")){
                                            this.authEnterprise = false
                                            this.applyEnterpriseTwo = true
                                        } else {
                                            this.authEnterprise = false
                                            this.applyEnterpriseOne = true
                                        }
                                    } else {
                                        this.authEnterprise = false
                                        this.applyEnterpriseOne = true
                                    }
                                    this.enterpriseCheck()
                                }
                            }
                        }
                        
                    }
                } else {
                    if(this.ownerHasEnterprise===true){
                        this.getAuthId().then(id => {
                            return this.getAuthInfo()
                        }).then(_ => {
                        }).catch(err => {
                            this.$message.error("获取认证信息数据失败")
                        })
                    } else {
                        this.createEnterprise()
                    }   
                }
                this.loadingAuthData = false
            }).catch(err =>{
                this.loadingAuthData = false
                console.error(err)
            })
        },
        authSuccess(){
            this.step = 4
            this.enterpriseCheck()
            if(this.invokeNo === this.oldInvokeNo && this.returnUrl !== 'DEFAULT'){
                let startTime = Date.now()
                this.countDown = 5
                this.intervalHandle = setInterval(_ => {
                    let countDown = 5 - Math.floor((Date.now() - startTime) / 1000)
                    this.countDown = countDown
                    if (countDown <= 0){
                        clearInterval(this.intervalHandle)
                        this.goBack()
                    }
                }, 33)
            }
        },
        successNext(){
            let memberStatus = this.euserInfo.memberStatus
            if(memberStatus === "JOINED"){
                this.authEnterprise = false
                this.applyEnterpriseTwo = true
            } else {
                this.authEnterprise = false
                this.applyEnterpriseOne = true
            }
        },
        getAuthId(){
            return getVerifications({
                filters: `author_wsid=${this.enterpriseWsid}` //FIXME: 后端目前只支持下划线
            }).then(body => {
                if (body.data.data.identities[0] && body.data.data.identities[0].wsid){
                    this.idttvWsid = body.data.data.identities[0].wsid
                    this.oldInvokeNo = body.data.data.identities[0].invokeNo || ""
                    return body.data.data.identities[0].wsid
                } else {
                    return this.createAuthId()
                }
            })
        },
        createEnterprise(){
            createEnterprise({
                name: this.stateInfo.enterpriseName || this.stateInfo.name,
                authorWsid: this.userWsid
            }).then(res => {
                let enterpriseWsid = res.data.data.enterprise.enterpriseWsid
                this.enterpriseWsid = enterpriseWsid
                this.isCreatedEnterprise = false
                this.targetUserId = res.data.data.enterprise.authorEuserWsid
                return this.activeIdentity()
            }).catch(err => {
                if (err.response){
                    let code = err.response.data.code
                    if (code === 101){
                        this.applyEnterpriseOne = true
                    } else if(code === 102){
                        this.enterpriseCheck()
                        this.$alert(`你的帐号下已有该企业，请不要重复创建`, "提醒", {
                            type: "warning",
                            confirmButtonText: "确定",
                        }).catch(_ => {})
                    }
                } else {
                    this.$message.error("创建企业请求失败")
                }
            })
        },
        activeIdentity(){
            changeSession({
                userWsid: this.userWsid,
                destinationWsid: this.targetUserId
            }).then(_ => {
                this.getAuthId().then(id => {
                    return this.getAuthInfo()
                }).then(res => {
                }).catch(err => {
                    this.$message.error("获取认证信息数据失败")
                })
                this.loginLocalStatus.setActiveUserWsid(this.targetUserId)
                this.$store.commit("setActiveUserWsid", this.targetUserId)
            }).catch(err =>{
                console.error(err)
            })
        },
        createAuthId(){
            return enterpriseAuth({
                authorWsid: this.enterpriseWsid,
                authType: "LEGAL_PERSON",
                invokeNo: this.invokeNo,
                fromTag: this.stateInfo.developerEnterpriseWsid,
            }).then(body => {
                this.idttvWsid = body.data.data.identity.wsid
                this.idttvStatus = body.data.data.identity.status
                return body.data.data.identity.wsid
            })
        },
        getAuthInfo(){
            getVerificationInfo({
                identityWsid: this.idttvWsid || this.targetIdttvWsid
            }).then(body => {
                this.idttInfo = body.data.data.identity
                let idttvStatus = body.data.data.identity.status
                this.idttvStatus = idttvStatus
                this.oldInvokeNo = body.data.data.identity.invokeNo || ""
                if (idttvStatus === "PRIMARY_PASSED"){
                    this.step = 0
                    if(this.returnUrl !== 'DEFAULT'){
                        setTimeout(this.reAuth, 1000)
                    } else {
                        setTimeout(this.reAuth, 1000)
                    }
                } else if (idttvStatus === "WAITING"){
                    this.step = 6
                } else if (idttvStatus === "SENIOR_PASSED" || idttvStatus === "SENIOR_NO_CERT"){
                    this.authSuccess()
                } else if (idttvStatus === "WAITING_SUM"){
                    this.step = 2
                } else if (idttvStatus === "WAITING_SUM_CHECK"){
                    this.step = 3
                } else if (idttvStatus === "PRIMARY_DENY" || idttvStatus === "SENIOR_DENY"){
                    this.enterpriseCheck()
                    this.step = 5
                    if(this.type === "WAITING_SUM" && idttvStatus === "SENIOR_DENY"){
                            if(this.returnUrl !== 'DEFAULT'){
                                let startTime = Date.now()
                                this.countDown = 5
                                this.intervalHandle = setInterval(_ => {
                                    let countDown = 5 - Math.floor((Date.now() - startTime) / 1000)
                                    this.countDown = countDown
                                    if (countDown <= 0){
                                        clearInterval(this.intervalHandle)
                                        this.openAPIAuthCompleteJump()
                                    }
                                }, 33)
                            }
                    } else if(idttvStatus === "SENIOR_DENY"){
                        this.returnJump()
                    } else {
                        this.returnJump()
                    }
                } else {
                    this.showEnterpriseAuthInfo = true
                    this.authEnterprise = true
                    this.step = 0
                }
            })
        },
        enterpriseCheck(){
            enterpriseCheck({
                ownerWsid: this.userWsid,
                enterpriseName: this.stateInfo.enterpriseName,
                unifiedSocialCode: this.unifiedSocialCode,
                notifyIfSameUnifiedSocialCode: true,
                invokeNo:this.invokeNo,
                notifyIfExistEntesForOwner: true
            }).then(res => {
                let authResult = res.data.data.result
                this.sameOwner = authResult.sameOwner
                // this.$message.success("高级认证通过")
            }).catch(err =>{
                console.error(err)
            })
        },
        async submitVerifyIdentities() {
            this.loadingAuthNext = true
            let bankCardInfo = {
                bankCardNo: this.stateInfo.bankCardNo,
                bankBranch: this.stateInfo.bankBranch,
                bank: this.stateInfo.bank
            }

            if (this.stateInfo.authType == "AGENT"){
                let agent = {
                    name: this.stateInfo.name,
                    idCardNo: this.stateInfo.idCardNo,
                    idCardType: this.stateInfo.idCardType,
                    phone: this.stateInfo.phone
                }
                let imageFileDatas = [{
                    imageCode: this.stateInfo.businessLicenceImageCode,
                    fileWsid: this.stateInfo.businessLicenceImageFileWsid
                }, {
                    imageCode: this.stateInfo.trustInstrumentImageCode,
                    fileWsid: this.stateInfo.trustInstrumentImageFileWsid
                }]

                try {
                    await enterpriseAuth({
                        authorWsid: this.enterpriseWsid,
                        fromTag: this.stateInfo.developerEnterpriseWsid,
                        name: this.stateInfo.enterpriseName,
                        unifiedSocialID: this.unifiedSocialCode,
                        agent,
                        authType: this.stateInfo.authType,
                        bankCardInfo,
                        imageFileDatas,
                        invokeNo: this.invokeNo
                    })
                    examine({
                        identityWsid: this.idttvWsid || this.targetIdttvWsid
                    }).then(_ => {
                        this.loadingAuthNext = false
                        return this.getAuthInfo()
                    }).catch(err => {
                        this.loadingAuthNext = false
                        if (err.response){
                            let code = err.response.data.code
                            if (code === 101){
                                this.$message.warning("认证信息未完整，请填写完整信息后，重新提交")
                            }
                        } else {
                            this.$message.error("提交申请失败")
                        }
                        throw "检查未通过"
                    })
                } catch (e){
                    this.$message.error("提交认证信息失败")
                    this.loadingAuthNext = false
                }
            } else {
                let legalPerson = {
                    name: this.stateInfo.name,
                    idCardNo: this.stateInfo.idCardNo,
                    idCardType: this.stateInfo.idCardType,
                    phone: this.stateInfo.phone
                }
                let imageFileDatas = [{
                    imageCode: this.stateInfo.businessLicenceImageCode,
                    fileWsid: this.stateInfo.businessLicenceImageFileWsid
                }]

                try {
                    await enterpriseAuth({
                        authorWsid: this.enterpriseWsid,
                        fromTag: this.stateInfo.developerEnterpriseWsid,
                        name: this.stateInfo.enterpriseName,
                        unifiedSocialID: this.unifiedSocialCode,
                        legalPerson,
                        authType: this.stateInfo.authType,
                        imageFileDatas,
                        bankCardInfo,
                        invokeNo: this.invokeNo
                    })

                    examine({
                        identityWsid: this.idttvWsid || this.targetIdttvWsid
                    }).then(_ => {
                        this.loadingAuthNext = false
                        return this.getAuthInfo()
                    }).catch(err => {
                        this.loadingAuthNext = false
                        if (err.response){
                            let code = err.response.data.code
                            if (code === 101){
                                this.$message.warning("认证信息未完整，请填写完整信息后，重新提交")
                            }
                        } else {
                            this.$message.error("提交申请失败")
                        }
                        throw "检查未通过"
                    })
                } catch(e){
                    this.$message.error("提交认证信息失败")
                    this.loadingAuthNext = false
                }
            }
        },
        authErr(){
            this.step = 5
            this.enterpriseCheck()
            getVerificationInfo({
                identityWsid: this.idttvWsid
            }).then(body => {
                this.idttInfo = body.data.data.identity
                let idttvStatus = body.data.data.identity.status
                if(this.type === "WAITING_SUM" && idttvStatus === "SENIOR_DENY"){
                    this.showEnterpriseAuthInfo = false
                    this.$alert(`核对验证3次失败，本次认证已结束`, "提醒", {
                        type: "warning",
                        dangerouslyUseHTMLString: true,
                        showConfirmButton:false,
                        showCancelButton:true,
                        cancelButtonText: "取消",
                    }).then(_ => {
                    }).catch(action =>{
                        if(this.returnUrl !== 'DEFAULT' && action === "cancel"){
                            let startTime = Date.now()
                            this.countDown = 5
                            this.intervalHandle = setInterval(_ => {
                                let countDown = 5 - Math.floor((Date.now() - startTime) / 1000)
                                this.countDown = countDown
                                if (countDown <= 0){
                                    clearInterval(this.intervalHandle)
                                    this.openAPIAuthCompleteJump()
                                }
                            }, 33)
                        }
                    })
                } else if(idttvStatus === "SENIOR_DENY"){
                    this.$alert(`核对验证3次失败，本次认证已结束`, "提醒", {
                        type: "warning",
                        dangerouslyUseHTMLString: true,
                        showConfirmButton:false,
                        showCancelButton:true,
                        cancelButtonText: "取消",
                    }).then(_ => {
                    }).catch(action =>{
                        if(action === "cancel"){
                            this.returnJump()
                        }
                    })
                }
                else if(idttvStatus=== "PRIMARY_DENY"){
                    this.returnJump()
                }
            })
        },
        returnJump(){
            let startTime = Date.now()
            this.countDown = 5
            this.intervalHandle = setInterval(_ => {
                let countDown = 5 - Math.floor((Date.now() - startTime) / 1000)
                this.countDown = countDown
                if (countDown <= 0){
                    clearInterval(this.intervalHandle)
                    this.reAuth("RETURN")
                }
            }, 33)
        },
        goBack(){
            if (this.returnUrl === "DEFAULT"){
                this.$router.replace({
                    name: "enterprise-auth",
                    query: this.$route.query
                })
            } else {
                if(/^http/i.test(this.returnUrl)){
                    location.href = this.returnUrl
                } else {
                    location.href = "http://"+ this.returnUrl 
                }
            }
        },
        openAPIAuthCompleteJump(val){
            if( val ==="SUCCESS" || val === "ERROR"){
                clearInterval(this.intervalHandle)
            }

            if (this.returnUrl === "DEFAULT"){
                this.$router.replace({
                    name: "enterprise-auth",
                    query: this.$route.query
                })
            } else {
                if(this.invokeNo !== this.oldInvokeNo){
                    this.getAuthInfo()
                } else {
                    if(/^http/i.test(this.returnUrl)){
                        location.href = this.returnUrl
                    } else {
                        location.href = "http://"+ this.returnUrl 
                    }
                }
            }
        },
        reAuth(val){
            this.loadingReAuth = true
            resetAuthStatus({
                identityWsid: this.idttvWsid,
            }).then(_ => {
                clearInterval(this.intervalHandle)
                if(val === "RETURN" && this.returnUrl!== "DEFAULT"){
                    this.openAPIAuthCompleteJump()
                } else {
                    this.getAuthInfo()
                }
            }).catch(err => {
                console.error(err)
                this.$message.error("返回重新认证失败")
            }).then(_ => {
                this.loadingReAuth = false
            })
        },
        // gotoHelp(){
        //     window.open("https://help.signit.cn/guide/newUsers/startUse.html")
        // },
    },
    components: {
        stepPrimary,
        stepSenior,
        authStatus,
        bigImg
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
@media screen and (max-width: 780px){
    .main-container{
        top:0px !important;
    }
}
@media screen and (max-width: 500px){
    .step-box{
        text-align:left !important
    }
}
.auth-hint{
    color:@color-danger;
    span{
        font-weight:bold;
    }
}
.preview{
    text-align:center;
    cursor:pointer;
}
.oranization-name{
    text-align:center;
    padding:20px;
}
.main-container{
    width:100%;
    max-width:600px;
    position:relative;
    top:70px;
    margin:0 auto;
    overflow-x:hidden;
    .company-name{
        text-align:center;
        padding: 20px 0;
    }
    .container{
        .info-block-default;
        box-shadow: rgba(0, 0, 0, 0.06) 0 0 0.2rem 0.01rem;
        padding:0;
        min-height:60%;
        .step-box{
            text-align:center;
            padding:10px 0;
            border-bottom:1px solid @color-border-button;
            p{  
                max-width:480px;
                margin:0 auto;
                line-height:25px;
            }
        }
        .auth-container{
            max-width:600px;
            margin:0 auto;
            padding:15px;
            min-height:400px;
            .auth-identity{
                margin-right:15px;
            }
        }
    }
}
.public-title{
    padding: 20px 0;
    display:block;
    text-align:center;
}
.pic-explain{
    font-size:@font-size-info;
    color:@color-font-regular;
    line-height:20px;
    margin-top:0 !important
}
.verfi-entrlegal-img{
    vertical-align:top
}
.auth-btn{
    width:100%;
    margin-top:40px;
    cursor:pointer;
}
.identity-message{
    max-width:480px;
    padding-top:30px;
}
.auth-result{
    // padding:40px 0;
    margin:0 auto;
    text-align:center;
    p{
        padding-top:15px;
        text-align:center;
        font-size:@font-size-info
    }
    .hint{
        color:@color-font-regular
    }
}
.auth-await-title{
    font-size:@font-size-primary !important;
}
.right{
    color:@color-success;
}
.error{
    color:@color-danger;
}

.auth-result .icon{
    font-size:@font-size-largger
}
.wait{
    color:@color-warning
}
.await{
    color:@color-info;
}
.await-title{
    font-size:@font-size-info !important;
    line-height:25px;
}

.auth-result-btn{
    width:100%;
    max-width:300px;
    margin-top:40px;
    cursor:pointer;
}
.reason{
    font-size:@font-size-info!important;
}
.signit{
    position:fixed;
    left:0;
    right:0;
    bottom:0;
    text-align:center;
}
.enterprise-auth-dialog span{
    width: 135px;
    text-align: right;
    display: inline-block;
}
.enterprise-auth-dialog p{
    font-size:@font-size-info;
    line-height:25px;
}
.enterprise-auth-header-dialog span{
    display:inline-block;
    text-align:center
}
.enterprise-auth-content span{
    text-align:center;
    display:inline-block;
}
.enterprise-auth-dialog .line{
    border-bottom:1px solid @color-border;
    padding-bottom:5px;
}
.enterprise-auth-dialog img{
    max-width:800px;
}
.enterprise-auth-dialog .line-height{
    padding:15px 0; 
    color:#333;
    font-size:14px;
}
.link-url{
    color:@color-main
}
.developer-enterprise-name{
    color:@color-main
}
.hint-box{
    max-width:240px;
    margin:20px auto;
    p{
        line-height:25px;
    }
}
.question{
    margin-right:3px;
    font-size:16px;
}
.size-info{
    font-size:@font-size-info
}
.question-box{
    color:@color-main;
    max-width: 140px;
    margin: 20px auto 0 auto;
    text-align: left;
    p{
        padding-bottom:20px;
    }
}
.underline{
    text-decoration:underline;
    cursor:pointer;
}
// .underline:hover,.underline:active{
    
// }
.auth-result .line-height{
    padding-top: 5px;
    display: inline-block;
}
.apply-enterprise{
    text-align:center;
    .apply-box{
        margin:0 auto;
        text-align:center;
        font-size:@font-size-info
    }
    .apply-line{
        padding-top:15px;
        line-height:20px;
        p{
            padding-bottom:2px;
        }
    }
    .hint{
        color:@color-font-regular
    }
    .font-normal{
        color:#333;

    }
    .arrow-right{
        padding-left:5px;
        padding-right:5px;
        display:inline-block
    }
    .icon{
        font-size:@font-size-title
    }
}
.enterprise-info-box{
    width:300px;
    margin:0 auto;
    line-height:25px;
    font-size:@font-size-info;
    span{
        width: 135px;
        text-align: right;
        display: inline-block;
    }
}
.submit-btn{
    margin-top:0 !important
}
</style>
<style>
@media screen and (max-width: 780px){
    .enterprise-auth-dialog .el-dialog{
        width:360px !important;
    }
    .check-code-box-dialog .el-dialog__body{
        padding: 0px 20px 15px 20px;
    }
    .check-code-dialog {
        max-height:280px !important;
        overflow:auto;
    }
}
@media screen and (min-width: 780px){
    .check-code-dialog {
        max-height:450px !important;
        overflow:auto;
    }
}
.check-code-box-dialog .el-dialog{
    min-width:340px;
    max-width:600px;
}
.step-box .el-step__main{
    margin-top:10px
}
.question{
    margin-right:3px;
    font-size:16px;
}
.underline{
    text-decoration:underline;
    cursor:pointer
}
.underline:hover,.underline:active{
    color:@color-main
}
</style>
