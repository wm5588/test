let path = require("path")
let pagesConfig = require("../../build/entrys.config")
let jsdom = require("jsdom")
let fs = require("fs")
let crypto = require("crypto")

function resolve(){
    return path.resolve.call(this, __dirname, ...arguments)
}

const configData = fs.readFileSync(resolve("./page-global-config.js"), {encoding: "utf8"})

const cache = new Map()

function getHash(str){
    let hash = crypto.createHash('sha256')
    hash.update(str)
    return hash.digest("hex")
}

//注入全局配置
function injectGlobalConfig(htmlStr){
    let hash = getHash(htmlStr)
    if(cache.has(hash)) return cache.get(hash)

    let dom = new jsdom.JSDOM(htmlStr)
    let script = dom.window.document.createElement("script")
    script.appendChild(dom.window.document.createTextNode(configData))
    dom.window.document.querySelector("head").appendChild(script)
    let data = dom.serialize()

    cache.set(hash, data)
    return data
}

exports.setPages = function(app){
    app.get("/wx-intercept", (req, res) => {
        if (/MicroMessenger\//i.test(req.headers["user-agent"]) || /QQ\//i.test(req.headers["user-agent"])){ 
            res.render("wx-intercept")
        } else {
            let query = req.query
            res.redirect(query.targetURL)
        }
    })

    app.get("/waiting-sum", (req, res) => {
        res.render("waiting-sum")
    })

    pagesConfig.config.forEach(({
        name,
        paths,
        pathFor
    }) => {
        paths.forEach(path => {
            LOG.debug(`加载路径 ${path} =>页面 ${name} ${pathFor === "all" ? "" : (pathFor === "pc" ? "only pc" : "only mobile")}`)

            app.get(path, (req, res, next) => {
                if (pathFor === "pc"){
                    if (/mobile/i.test(req.headers["user-agent"])){
                        return next()   
                    }
                } else if (pathFor === "mobile"){
                    if (!/mobile/i.test(req.headers["user-agent"])){
                        return next()
                    }
                }

                fs.readFile(resolve(`../public/outputs/html/${name}.html`), (err, data) => {
                    if(err){
                        next()
                    } else {
                        res.send(injectGlobalConfig(data.toString()))
                    }
                })
            })
        })
    })
    
    app.get("*", (req, res) => {
        res.render("error/404")
    })
}
