<template>
    <keep-alive>
        <router-view></router-view>
    </keep-alive>
</template>

<script>
    export default{
        data:function(){
            return {}
        },
        created(){
        }
    }
</script>

<style lang="less" scoped>
</style>