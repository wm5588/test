const axios = require("axios")
const proxy = require('express-http-proxy')

// const p = proxy("http://api.signit.cn", {
const p = proxy("http://api.ns.me:8280", {
    proxyReqPathResolver: function(req) {
        let url = require('url').parse(req.url).path
        // url = url.replace("/api/pass2bk/", "/")
        return url
    }
})

exports.get = p
exports.post = p
exports.put = p
exports.delete = p