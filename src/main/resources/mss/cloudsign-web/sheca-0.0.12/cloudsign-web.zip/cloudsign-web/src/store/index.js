import moudle_userData from "@store/modules/userdata.js" //用户数据
import moudle_userEnterprise from "@store/modules/userenterprise.js" //用户企业数据
import moudle_userLabels from "@store/modules/userlabels.js" //标签数据
import moudle_userAuth from "@store/modules/userauth.js" //认证状态
import moudle_userAccounts from "@store/modules/useraccounts.js" //用户账户
import moudle_userCharge from "@store/modules/usercharge.js" //用户账户
import moudle_localStorage from "@store/modules/localstorage.js" //本地存储
import module_TemplateData from "@store/modules/template.js"
import moudle_userMessage from "@store/modules/usermessage.js"
import module_envelopeDetailPath from "@store/modules/envelope-detail-path.js" //存储进入信封详情的页面路径
import module_signaturedata from "./modules/signature-data.js"
import module_signatureData from "./modules/signature-data-new.js"
import module_userPermissionData from "@store/modules/userpermission.js"

import { getSessionData, session_logout } from "@interfaces/user/sessions.js"
import {pullMessage} from "@interfaces/message-pusher/system-message.js"
import { _assignObjectWithSrcProperties } from "@commons/util.js"
import { LoginLocalStatus } from "@classes/login/login-info.js"

import { MessageBox, Message } from "element-ui"

const ACTIVE_TIME = 1000 * 60 * 30//活动时间 半小时

export default {
    state: {
        loginLocalStatus: new LoginLocalStatus(),
        activity: true, //是否处于活动状态
        activeCheckHandle: null,
    },
    getters: {
        userWsid(state) {
            return state.loginLocalStatus.userWsid
        },
        activeUserWsid(state) {
            return state.loginLocalStatus.activeUserWsid || state.loginLocalStatus.userWsid
        },
        lastActiveTime(state){
            return state.loginLocalStatus.lastActiveTime
        },
        login(state) {
            return state.loginLocalStatus.login
        },
        userEdition(state, getters) { //用户所处版本  'p' 个人版 'e'企业版
            if (/^WSID_PUSR/.test(getters.activeUserWsid)){
                return "p"
            } else if (/^WSID_EUSR/.test(getters.activeUserWsid)) {
                return "e"
            }
        },
        userAuthorWsidInEnvelope(state, getters){
            if (getters.userEdition === "e"){
                return getters.memberWsid
            } else {
                return getters.userWsid
            }
        }
    },
    mutations: {
        setActiveUserWsid (state, id){
            state.loginLocalStatus.setActiveUserWsid(id)
        },
        user_login: (state, userWsid ) => {
            state.loginLocalStatus.setLogin(true)
            if (userWsid) state.loginLocalStatus.setUserWsid(userWsid)
        },
        user_logout: (state, autoJump = true) => {
            state.loginLocalStatus.setLogin(false)
            state.loginLocalStatus.setUserWsid("")
            state.loginLocalStatus.setActiveUserWsid("")
            //清除session数据
            sessionStorage.clear()
            if (autoJump) location.href = "/login"
        },
        check_user_active(state, getters){
            let nowDate = Date.now()
            if (getters.login && nowDate - getters.lastActiveTime > ACTIVE_TIME) { //30分钟超时
                state.activity = false
            } else {
                state.activity = true
            }
        }
    },
    actions: {
        async init({ state, commit, dispatch, getters }){ //状态树初始化
            
            await getSessionData().then(res => {
                let session = res.data.data.session
                //免登陆状态不能进入系统
                if (session.sessionScopes && session.sessionScopes.length > 0){
                    throw new Error("ERROR_CANT_USE_FREE_LOGIN")
                }
                state.loginLocalStatus.setActiveUserWsid(session.userWsid)
                return true
            }).catch(_ => {
                commit("user_logout", false)
                throw new Error("ERROR_NOT_LOGIN")
            })
            
            //检测数据是否正确
            await dispatch("updateModule").then(_ => {
                commit("user_login")
                return true
            }).catch(err => {
                console.error(err)
                throw new Error("ERROR_LOAD_DATA")
            })
            pullMessage({
                userWsid: this.userWsid || this.getters.userWsid
            }).then(_ => {}).catch(err => {
                Message.error("拉取私信失败")
            })

            //检测是否在目前这个企业当中
            let userAccounts = getters.userAccounts
            let userWsid = getters.activeUserWsid
            let userAccount = userAccounts.find(acount => acount.userWsid === userWsid)
            if (!userAccount || userAccount.memberStatus === "DISABLED"){
                await dispatch("changeUserAccount", getters.puserWsid)
                MessageBox.alert("您已经被企业管理员从该企业移除，无法进入该企业内部,将返回个人主页", "提醒", {
                    type: "warning",
                    confirmButtonText: "确定",
                }).then(_ => {}, _ => {}).then(_ => {
                    //TODO: 跳转
                    location.href = "/wesign"
                })
            }
            
            //检测是否处于活动状态
            dispatch("checkUserActive")

            //启动消息推送监听
            dispatch("initListenPushMessage")
        },
        async user_login({ state, commit, dispatch }, {
                accountNumber,
                password,
                verificationCode = ""
            }){
            
            return sessions_post({
                accountNumber,
                password,
                verificationCode,
                loginType: "WEB"
            }).then(body => {
                let data = body.data
                state.login = true
                commit("user_login")
                commit("setUserWsid", data.session.userWsid)
                return dispatch("updateModule")
            }).catch(err => {
                console.error(err)
                return Promise.reject(err)
            })
        },
        async user_logout({ state, commit, dispatch }){
            return session_logout().then(data => {
                commit("user_logout")
                commit("setUserWsid", "")
            }).catch(err => {
                console.error(err)
                commit("user_logout")
                commit("setUserWsid", "")
            })
        },
        updateUserActive({ state, dispatch}){
            state.loginLocalStatus.updateLastActiveTime()
            dispatch("checkUserActive")
        },
        checkUserActive({ state, dispatch }){ //循环检测是否长时间未活动
            if (state.activeCheckHandle) clearTimeout(state.activeCheckHandle)
            state.activeCheckHandle = setTimeout(() => {
                dispatch("userNotActive")
            }, ACTIVE_TIME)
        },
        userNotActive({commit, state}){
            state.activity = false
            MessageBox.alert("由于长时间无操作，为了您的帐号安全，与服务器的连接已断开，请重新登录", "断开连接", {
                confirmButtonText: "确定",
                callback: action => {
                    commit("user_logout")
                },
                type: "warning"
            })
        }
    },
    modules: {
        userdata: moudle_userData,
        userenterprise: moudle_userEnterprise,
        userlabels: moudle_userLabels,
        // userauth: moudle_userAuth,
        useraccounts: moudle_userAccounts,
        charges: moudle_userCharge,
        template: module_TemplateData,
        userMessage: moudle_userMessage,
        envelopeDetailPath: module_envelopeDetailPath,
        signatureData: module_signaturedata,
        signatureData: module_signatureData,
        userPermission: module_userPermissionData
    }
}
