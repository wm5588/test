<template lang="html">
    <externalFrame>
        <h1 class="pic-title invite-info">{{inviteUser}}邀请您加入<a class="company-name" href="#">"{{companyName}}"</a></h1>
        <inviteRegister></inviteRegister>
    </externalFrame>
</template>

<script>
import externalFrame from "@page-components/frames/external-frame.vue"
import inviteRegister from "@components/login/invite-regist.vue"
import querystring from "querystring"

export default {
    data(){
        return {
            inviteUser: "",
            companyName: ""
        }
    },
    created(){
        let query = location.search.slice(1)
        query = querystring.parse(query)
        this.inviteUser = query["inviterName"]
        this.companyName = query["inviterEnterpriseName"]
    },
    components: { inviteRegister, externalFrame },
}
</script>

<style lang="less" scoped>
.company-name{
    color:#0c7ffc;
    line-height:25px;
}
.invite-info{
    width:85%;
    font-size:16px;
}
</style>
