let config = {
    url: {
        app: "http://192.168.58.145:61110", //主站地址
        developer: "http://192.168.58.145:61113", //开放平台地址
        ws: "ws://192.168.58.145:61117", //websocket地址
        link: "http://112.44.251.136:61112"
    }
}

export { config }