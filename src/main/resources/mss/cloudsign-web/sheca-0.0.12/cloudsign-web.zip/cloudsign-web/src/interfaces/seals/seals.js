import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @desc  获取指定用户的私章列表
 * @date  2017-11-20 09:59:17
 * @author chenxiyuan
 * ----------------------------------------------------
 */
export function getPersonSeals(obj) {
    let {
        authorWsid,
        fields
    } = obj

    return axios.get(`/api/seals/person-seals/author-person-seals`, {
        params: {
            authorWsid,
            fields,
        }
    })
}

/**
 * ----------------------------------------------------
 * @desc  上传用户私章
 * @date  2017-11-29 09:46:40
 * @author chenxiyuan
 * ----------------------------------------------------
 */
export function uploadPersonalSeals(obj) {
    let {
        name,
        file,
        from = "DEFAULT",
        authorWsid
    } = obj

    let formdata = new FormData()
    formdata.append("file", file)
    // formdata.append("properties", )

    return axios.post(`/api/seals/person-seals/form-upload`, formdata, {
        params: {
            properties: JSON.stringify({
                name,
                from,
                authorWsid
            })
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/person-seals/:personSealWsid
 * @method DELET
 * @desc   删除指定用户私章
 * @author 潘维,陈曦源
 * @date   2018-02-06 17:10:07
 * ----------------------------------------------------
 */
export function deletePersonalSeal(obj) {
    let {
        personSealWsid
    } = obj

    return axios.delete(`/api/seals/person-seals/${personSealWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/admin
 * @method GET
 * @desc   企业拥有者获取指定企业的全部印章GET或可指定groupWsid查询其含有的所有印章
 * @author 潘维,陈曦源
 * @date   2018-06-29 10:52:44
 * ----------------------------------------------------
 */
export function getAdminOfficeSeals(obj) {
    let {
        enterpriseWsid,
        fileds,
        filters,
        offset = 0,
        limit = 10,
        sorts = "-createdDatetime",
        groupWsid,
        keyword
    } = obj

    return axios.get(`/api/seals/office-seals/admin`, {
        params: {
            enterpriseWsid,
            fileds,
            filters,
            offset,
            limit,
            sorts,
            groupWsid,
            keyword
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/general
 * @method GET
 * @desc   企业拥有者获取指定企业的全部印章GET或可指定groupWsid查询其含有的所有印章
 * @author 潘维,陈曦源
 * @date   2018-09-30 11:03:37
 * ----------------------------------------------------
 */
export function getGeneralOfficeSeals(obj) {
    let {
        enterpriseWsid,
        groupWsid,
        status,
        fileds,
        filters,
        offset = 0,
        limit = 10,
        sorts = "-createdDatetime",
        keyword
    } = obj

    return axios.get(`/api/seals/office-seals/general`, {
        params: {
            enterpriseWsid,
            groupWsid,
            status,
            fileds,
            filters,
            offset,
            limit,
            sorts,
            keyword
        }
    })
}
/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/general
 * @method POST
 * @desc  普通成员申请使用某个印章
 * @author 潘维
 * @date   2018-09-26 15:02:44
 * ----------------------------------------------------
 */
export function sealApply(obj) {
    let {
        officeSealWsid,
        seals
    } = obj
    
    return axios.post(`/api/seals/office-seals/general`, seals, {
        params: {
            officeSealWsid,
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/:officeSealWsid
 * @method get
 * @desc   获取指定印章
 * @author 潘维
 * @date   2018-04-02 10:32:50
 * ----------------------------------------------------
 */
export function getOfficeSealInfo(obj) {
    let {
        officeSealWsid
    } = obj
    
    return axios.get(`/api/seals/office-seals/${officeSealWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/form-upload
 * @method POST
 * @desc   上传印章
 * @author 潘维,陈曦源
 * @date   2018-09-29 20:56:52
 * ----------------------------------------------------
 */
export function uploadOfficeSeals(obj) {
    let {
        name,
        file,
        from = "DEFAULT",
        enterpriseWsid,
        authorWsid,
        groupWsid,
        metadata,
    } = obj

    let formdata = new FormData()
    formdata.append("file", file)
    // formdata.append("properties", )

    return axios.post(`/api/seals/office-seals/form-upload`, formdata, {
        params: {
            properties: JSON.stringify({
                name,
                from,
                enterpriseWsid,
                authorWsid,
                groupWsid,
                metadata
            })
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/seal-abandon/:officeSealWsid
 * @method POST
 * @desc   废弃指定印章
 * @author 潘维,陈曦源
 * @date   2018-02-06 17:09:09
 * ----------------------------------------------------
 */
export function sealAbandon(obj) {
    let {
        officeSealWsid
    } = obj
    
    return axios.post(`/api/seals/office-seals/seal-abandon/${officeSealWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/seal-authorize/:officeSealWsid
 * @method POST
 * @desc   将印章授权给指定企业成员使用
 * @author 潘维,陈曦源
 * @date   2018-02-06 17:09:39
 * ----------------------------------------------------
 */
export function sealAuthorize(obj) {
    let {
        officeSealWsid,
        seals
    } = obj
    
    return axios.post(`/api/seals/office-seals/seal-authorize/${officeSealWsid}`, seals)
}
/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/seal-authorize-revoke/:officeSealWsid
 * @method POST
 * @desc   管理员撤销企业成员对指定签章的使用权
 * @author 潘维
 * @date   2018-04-02 14:31:48
 * ----------------------------------------------------
 */
export function cancelSealAuthorize(obj) {
    let {
        officeSealWsid,
        seals
    } = obj
    
    return axios.post(`/api/seals/office-seals/seal-authorize-revoke/${officeSealWsid}`, seals)
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/seal-authorize
 * @method GET
 * @desc   查询指定用户的可用(已获得授权)的所有印章
 * @author 潘维,陈曦源
 * @date   2019-09-23 17:14:45
 * ----------------------------------------------------
 */
export function getAuthorizeSeals(obj) {
    let {
        enterprisePersonWsid,
        fileds,
        filters,
        offset = 0,
        limit = 10000000,
        sorts = "-createdDatetime",
        scope,
        keyword
    } = obj

    return axios.get(`/api/seals/office-seals/seal-authorize`, {
        params: {
            enterprisePersonWsid,
            fileds,
            filters,
            offset,
            limit,
            sorts,
            scope,
            keyword
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/applications/:officeSealWsid
 * @method GET
 * @desc   查询指定印章的所有申请记录
 * @author 周雪梅
 * @date   2018-02-07 20:24:36
 * ----------------------------------------------------
 */
export function getOfficeSealsApplications(obj) {
    let {
        officeSealWsid,
        fileds,
        filters,
        limit = 10,
        offset = 0,
        sorts
    } = obj

    return axios.get(`/api/seals/office-seals/applications/${officeSealWsid}`, {
        params: {
            fileds,
            filters,
            limit,
            offset,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/modify-seal-name/:officeSealWsid
 * @method PATCH
 * @desc   印章修改
 * @author 周雪梅
 * @date   2018-05-10 19:07:00
 * ----------------------------------------------------
 */
export function modifySealName(obj) {
    let {
        officeSealWsid,
        name
    } = obj

    return axios.patch(`/api/seals/office-seals/modify-seal-name/${officeSealWsid}`, {
        name
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/:officeSealWsid/use-records
 * @method GET
 * @desc   获取指定印章的使用记录
 * @author 周雪梅
 * @date   2018-06-24 19:01:01
 * ----------------------------------------------------
 */
export function getOfficeSeallogs(obj) {
    let {
        officeSealWsid,
        fields,
        filters,
        limit = 20,
        offset = 0,
        sorts = "-signDatetime"
    } = obj

    return axios.get(`/api/seals/office-seals/${officeSealWsid}/use-records`, {
        params: {
            fields,
            filters,
            limit,
            offset,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/:officeSealWsid/use-records
 * @method GET
 * @desc   印章审核
 * @author 周雪梅
 * @date   2018-09-30 11:04:11
 * ----------------------------------------------------
 */
export function getOfficeSealStatusAudit(obj) {
    let {
        officeSealWsid,
        fields,
        filters,
        limit = 20,
        offset = 0,
        sorts = "-signDatetime"
    } = obj

    return axios.get(`/api/seals/office-seals/${officeSealWsid}/office-seal-status-audit`, {
        params: {
            fields,
            filters,
            limit,
            offset,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/:officeSealWsid/use-records
 * @method GET
 * @desc   印章申请
 * @author 周雪梅
 * @date   2018-09-30 11:04:08
 * ----------------------------------------------------
 */
export function OfficeSealApply(obj) {
    let {
        officeSealWsid,
        seals
    } = obj

    return axios.get(`/api/seals/office-seals/${officeSealWsid}/apply`, {
        seals
    })
}

/**
 * ----------------------------------------------------
 * @method  get
 * @description 获取企业印章列表
 * @date   2018-10-12 15:01:59
 * @author 周雪梅
 * ----------------------------------------------------
 */
export function getOfficeSealsApplyLists(obj) {
    let {
        enterpriseWsid,
        ignoreSealAuthor,
        fileds,
        filters,
        offset = 0,
        limit = 10,
        sorts = "-createdDatetime"
    } = obj
    
    return axios.get("/api/seals/office-seals/office-seal-apply-record", {
        params: {
            enterpriseWsid,
            ignoreSealAuthor,
            fileds,
            filters,
            offset,
            limit,
            sorts
        }
        
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/:officeSealWsid/handle-application
 * @method POST
 * @desc   处理印章申请
 * @author 周雪梅
 * @date   2018-09-30 11:03:53
 * ----------------------------------------------------
 */
export function officeSealsHandleApplication(obj) {
    let {
        enterpriseWsid,
        handledApplications
    } = obj
    
    return axios.post(`/api/seals/office-seals/handle-application`, {
        enterpriseWsid,
        handledApplications
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/public/form-upload-process
 * @method POST
 * @desc   form方式加工处理印章接口
 * @author 周雪梅
 * @date   2018-09-30 11:03:53
 * ----------------------------------------------------
 */
export function formUploadProcess(obj) {
    let {
        autoBackgroundLucency,
        autoEdgeCutting,
        enableCandidateBase64s,
        candidateBase64sNum,
        name,
        file
    } = obj

    let formdata = new FormData()
    formdata.append("file", file)
    formdata.append("name", name)
    formdata.append("autoBackgroundLucency", autoBackgroundLucency)
    formdata.append("autoEdgeCutting", autoEdgeCutting)
    formdata.append("enableCandidateBase64s", enableCandidateBase64s)
    formdata.append("candidateBase64sNum", candidateBase64sNum)

    return axios.post(`/api/seals/public/form-upload-process`, formdata)
}