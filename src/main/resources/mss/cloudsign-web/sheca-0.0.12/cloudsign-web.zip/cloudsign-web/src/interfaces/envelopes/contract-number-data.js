import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/contract-number-datas/customizations
 * @method POST
 * @desc   生成指定信封自定义的指定合同编号数据(自定义数据，不使用编号规则)
 * @author 潘维
 * @date   2019-06-28 15:12:19
 * ----------------------------------------------------
 */
export function customizeEnvelopeContractNumberData(obj) {
    let {
        envelopeWsid,
        contractNumberRule,
        createdAuthorWsid,
        description = "用户自定义的指定合同编号规则",
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/contract-number-datas/customizations`, {
        contractNumberRule,
        createdAuthorWsid,
        description
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/contract-number-datas/:contractNumberDataWsid/edit
 * @method POST
 * @desc   更新指定信封指定合同编号数据(自定义数据，不使用编号规则)
 * @author 潘维
 * @date   2019-06-28 15:12:19
 * ----------------------------------------------------
 */
export function updateEnvelopeContractNumberData(obj) {
    let {
        envelopeWsid,
        contractNumberDataWsid,
        contractNumberRule,
        description = "用户修改自定义的指定合同编号数据",
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/contract-number-datas/${contractNumberDataWsid}/edit`, {
        contractNumberRule,
        description
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/contract-number-datas/:contractNumberDataWsid/delete
 * @method delete
 * @desc   删除指定信封指定合同编号数据(自定义数据，不使用编号规则)
 * @author 潘维
 * @date   2019-06-28 15:12:19
 * ----------------------------------------------------
 */
export function deleteEnvelopeContractNumberData(obj) {
    let {
        envelopeWsid,
        contractNumberDataWsid,
    } = obj

    return axios.delete(`/api/envelopes/${envelopeWsid}/contract-number-datas/${contractNumberDataWsid}/delete`)
}