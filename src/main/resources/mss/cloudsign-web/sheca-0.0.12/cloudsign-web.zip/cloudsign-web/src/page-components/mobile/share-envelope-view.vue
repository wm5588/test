<!--
    @id        ui-documents-preview-page
    @desc      文档预览页面
    @author    潘维, 陈曦源
    @date      2019-01-24 09:42:19
-->
<template>
    <div class="container">
        <div class="title">
            <p>文件预览</p>
           <span v-if="envelopeData"><span v-if="envelopeData.status === 'ED_SUCCESS' || envelopeData.envelopeShownStatus === 'SUCCESS_COMPLETED'" class="icon-download" @click='download'></span></span>
        </div>
        <div class="envelope-preview-contanier">
            <envelopePreview class="preview-container" :linkKey="linkKey" @envelopeUpdate="envelopeUpdate" :envelopeWsid="envelopeWsid" :scale="resizeScale"></envelopePreview>
        </div>
    </div>
</template>

<script>
import envelopePreview from "@components/commons/share/mobile/envelope-preview.vue"
import { Toast,MessageBox} from "mint-ui"
import {
  downloadShareEnvelope,
} from "@interfaces/envelopes/share/index.js"
import querystring from "querystring"
export default {
    data(){
        return {
            envelopeWsid: "",
            linkKey:"",
            envelopeData:null
        }
    },
    computed: {
        resizeScale(){
            return document.documentElement.clientWidth / 595
        }
    },
    created(){
        let query = location.search.slice(1)
        query = querystring.parse(query)
        this.linkKey = query.token.split("&")[0] || query.token
        this.envelopeWsid = query.envelopeWsid
    },
    methods: {
        envelopeUpdate(data){
            this.envelopeData = data
        },
        download(){
            MessageBox.confirm(`您确定下载文件《${this.envelopeData.title}》?`, "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {
                return  downloadShareEnvelope({
                    envelopeWsid: this.envelopeWsid,
                    linkKey:this.linkKey,
                  }).then(res =>{
                    Toast({
                        message: "下载文件成功",
                        iconClass: "icon icon-confirm"
                    })
                  }).catch(err=>{
                    console.error(err)
                    Toast({
                        message: "下载文件失败",
                        iconClass: "icon icon-refuse"
                    })
                  })
            }, () => {})
        }
    },
    components: {envelopePreview}
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.container{
     position: absolute;
     left: 0;
     right: 0;
     top: 0;
     bottom: 0;
}
.title{
    background: @color-main;
    height: 50*@px;
    text-align: center;
    color:@color-white; 
    p{
        line-height: 50*@px; 
        font-size: @font-size-title;
        display: inline-block;
    }
    .icon-download{
        position: absolute;
        right: 15*@px;
        top: 15*@px;
        font-size:@font-size-large;
        cursor: pointer;
    }
}
.envelope-preview-contanier{
    position: absolute;
    left: 0;
    width: 100%;
    top: 50*@px;
    bottom: 0;
    
    .preview-container{
        padding:0;
        position:absolute;
        top:0;
        bottom:0;
        left: 0;
        right:0;
        overflow:auto;
    }
}
</style>
