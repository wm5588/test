<!--
    @id        page-envelope-audit
    @desc      新的信封审核页面
    @level     page
    @props     外部属性
    @author    潘维,陈曦源
    @date      2019-04-23 14:44:42
-->
<template>
    <div>
        <div class="envelope-signature-header">
            <div class="documents-info-toolbar">
                <div class="documents-select">
                    <el-select :value="activeDocumentId" size="mini" @change="gotoDocument">
                        <el-option v-for="document in documents" :key="document.id" :value="document.id" :label="document.name"></el-option>
                    </el-select>
                </div>
                <div class="document-progress">
                    <span>
                        <el-input-number style="width:50px;" size="mini" :value="activePage" :min="1" :max="activeDocumentData.pagesCount"
                            :controls="false" @change="gotoPage"></el-input-number>
                    </span>
                    <span>/{{activeDocumentData.pagesCount}}</span>
                </div>
                <div class="documents-scale">
                    <i class="icon icon-reduce" style="margin-right:5px" @click="zoomOut"></i>
                    <el-select v-model="scale" style="width: 100px;" size="mini" placeholder="">
                        <el-option v-for="s in scaleList" :key="s" :value="s" :label="(s * 100 / CSS_UNITS).toFixed(0) + '%'"></el-option>
                    </el-select>
                    <i class="icon icon-enlarge" style="margin-left:5px" @click="zoomIn"></i>
                </div>
            </div>
        </div>
        <div class="envelope-signature-container">
            <envelopePreview ref="preview" class="document-container" :style="{right:rightNavOpen?'120px':0}"
                :envelopeWsid="envelopeWsid" :scale="scale" 
                @loaded="documentsLoaded" @view-update="documentsViewUpdate">
            </envelopePreview>
            <div class="right-container" :style="{width:rightNavOpen?'120px':0}">
                <div class="right-container-switch" :class="{open:rightNavOpen, close:!rightNavOpen}" @click="rightNavOpen = !rightNavOpen">
                    <svg width="20" height="60">
                        <polyline points="7,10 13,30 7,50" class="line"/>
                    </svg>
                </div>
                <div class="right-box">
                    <div class="documents-preview-nav">
                        <div class="title">文档列表</div>
                        <documentsPreviewBar class="documents-preview" ref="previewbar" :documents="documents" 
                            :activeData="{
                                docId: activeDocumentId,
                                page: activePage
                            }" @select-docpage="prevewNavSelect"></documentsPreviewBar>
                    </div>
                </div>
            </div>
        </div>
        <div class="envelope-signature-footer">
            <el-button v-if="isSender" plain class="btn-danger" type="danger" @click="revokeDialogOpen=true">撤销</el-button>
            <el-button plain class="btn-danger-reject" type="danger" @click="checkNotPassDialogOpen=true">不通过</el-button>
            <el-button plain class="btn-complete" type="primary" @click="passCheck">通过</el-button>
        </div>
        
        <!-- 撤销弹框 -->
        <el-dialog title="撤销文件" :visible.sync="revokeDialogOpen" :close-on-click-modal="false" :append-to-body="true" width="500px" top="30vh">
            <div style="font-size:16px;margin-bottom: 20px;">告知其他人撤销该文件的原因：</div>
            <el-input type="textarea" v-model="revokeMessage" placeholder="请输入撤销文件的理由"></el-input>
            <div style="text-align:right;margin-top:30px">
                <el-button @click="dialogOpen = false">取消</el-button>
                <el-button type="primary" :loading="revoking" @click="revokeEnvelope">撤销</el-button>
            </div>
        </el-dialog>
        <!-- 审核弹框 -->
        <el-dialog title="审核不通过" :visible.sync="checkNotPassDialogOpen" width="500px" top="30vh" :close-on-click-modal="false">
            <div style="font-size:16px;margin-bottom: 20px;">告知其他人审核不通过的原因：</div>
            <el-input type="textarea" v-model="checkNotPassMessage" placeholder="请输入审核不通过的原因"></el-input>
            <div style="text-align:right;margin-top:30px">
                <el-button @click="checkNotPassDialogOpen=false">取消</el-button>
                <el-button type="primary" :loading="checking" @click="notPassEnvelope">审核不通过</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import wesignSignatureSDK from "@commons/wesign-signature-sdk-child.js"
import { revokeEnvelope } from "@interfaces/envelopes/envelope.js"

import { checkEnvelope } from "@interfaces/envelopes/envelope.js"
import { getEnvelopeDocuments } from "@interfaces/envelopes/documents.js"
import { viewEnvelope } from "@interfaces/envelopes/envelope.js"
import { ACTIONS, gotoOpenSignatureReturnURL } from "@classes/openapi/sign-callback.js"

import envelopePreview from "@components/commons/documents/envelope-preview.vue"
import documentsPreviewBar from "@components/commons/documents/documents-preview-bar.vue"
const CSS_UNITS = 96.0 / 72.0

export default {
    data(){
        return {
            pageCallback: "", //回调链接

            envelopeWsid: this.$store.state.envelopeWsid,
            currentSequence: -1,

            activeDocumentId: "", //当前浏览活跃的文档
            activePage: 1,
            documents: [],
            documentsData: [],
            enterpriseRoles: [], //当前人的企业角色

            scale: 1 * CSS_UNITS,
            scaleList: [
                0.75 * CSS_UNITS,
                1 * CSS_UNITS,
                1.25 * CSS_UNITS,
                1.5 * CSS_UNITS
            ],
            CSS_UNITS: CSS_UNITS,

            rightNavOpen: false,

            revokeDialogOpen: false,
            revoking: false,
            revokeMessage: "文件内容有误",
            
            checkNotPassDialogOpen: false,
            checking: false,
            checkNotPassMessage: "文件内容不符合要求",
        }
    },
    computed: {
        activeUserParticipantWsid(){
            return this.$store.getters.userAuthorWsidInEnvelope
        },
        activeDocumentData(){
            let index = this.documents.findIndex(doc => doc.id === this.activeDocumentId)
            if (this.documentsData[index]){
                return this.documentsData[index]
            } else {
                return {
                    pagesCount: 0
                }
            }
        },
        envelopeData(){
            return this.$store.state.envelopeData.basicInfo
        },
        isSender(){
            if (this.envelopeData){
                return this.activeUserParticipantWsid === this.envelopeData.senderWsid
            } else {
                return false
            }
        },
        participantWsid(){
            return this.$store.state.envelopeData.currentParticipant.participantWsid
        }
    },
    created(){
        this.currentSequence = this.envelopeData.currentSequence || -1

        //签署页面回调
        let query = this.$route.query
        if (query.pageCallback){
            this.pageCallback = query.pageCallback
        } else {
            this.pageCallback = localStorage.getItem(`pageCallback:${this.envelopeWsid}`) || ""
        }
        if (localStorage){
            localStorage.setItem(`pageCallback:${this.envelopeWsid}`, this.pageCallback)
        }

        this.activePage = 1

        getEnvelopeDocuments({
            envelopeWsid: this.envelopeWsid
        }).then(res => {
            let documents = res.data.data.documents
            documents = documents.map(document => {
                return {
                    id: document.fileWsid,
                    pdfSrc: document.fileHref.href,
                    name: document.fileName
                }
            })
            this.documents = documents
            this.activeDocumentId = this.documents[0].id
        }).catch(err => {
            this.$message.error("加载文件文档数据失败")
            console.error(err)
        })

        //更新预览时间
        viewEnvelope({
            envelopeWsid: this.envelopeWsid,
            participantWsid: this.participantWsid
        }).then(_ => _, _ => _)
    },
    methods: {
        passCheck(){
            this.$confirm("是否通过该文件的内容?", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {
                checkEnvelope({
                    envelopeWsid: this.envelopeWsid,
                    participantWsid: this.participantWsid,
                    censorReason: "审核通过",
                    checkPass: true
                }).then(_ => {
                    wesignSignatureSDK.operationComplete("AUDIT_PASS")
                    if (this.pageCallback){
                        this.$alert("审核操作完成!", "提醒", {
                            type: "success"
                        }).then(_ => {}, _ => {}).then(_ => {
                            this.openAPIEnvelopCompleteJump(ACTIONS.PASSED)
                        })
                    } else {
                        this.$message.success("审核结果提交成功")
                        this.$router.push({
                            name: "envelope-detail",
                            params: {
                                envelopeId: this.envelopeWsid
                            }
                        })
                    }
                }).catch(err => {
                    if (err.response){
                        let code = err.response.data.code
                        if (code == 104){
                            this.$alert("对不起,信封状态在您审核的过程中已经发生改变,请返回签署详情页面进行查看", "错误", {
                                type: "error"
                            }).then(_ => {}, _ => {}).then(_ => {
                                location.reload()
                            })
                        } else {
                            this.$message.error("审核结果提交失败")
                        }
                    } else {
                        this.$message.error("审核结果提交失败")
                    }
                })
            }).catch(() => {})
        },
        notPassEnvelope(){
            this.checking = true
            checkEnvelope({
                envelopeWsid: this.envelopeWsid,
                participantWsid: this.participantWsid,
                censorReason: this.checkNotPassMessage,
                checkPass: false
            }).then(err => {
                this.$message.success("审核结果提交成功")
                wesignSignatureSDK.operationComplete("AUDIT_NOTPASS")
                if (this.pageCallback){
                    this.$alert("操作成功!", "提醒", {
                        type: "success"
                    }).then(_ => {}, _ => {}).then(_ => {
                        this.openAPIEnvelopCompleteJump(ACTIONS.NOT_PASSED)
                    })
                } else {
                    this.$router.push({
                        name: "envelope-detail",
                        params: {
                            envelopeId: this.envelopeWsid
                        }
                    })
                }
            }).catch(err => {
                if (err.response){
                    let code = err.response.data.code
                    if (code == 104){
                        this.$alert("对不起,信封状态在您审核的过程中已经发生改变,请返回签署详情页面进行查看", "错误", {
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.reload()
                        })
                    } else {
                        this.$message.error("审核结果提交失败")
                    }
                } else {
                    this.$message.error("审核结果提交失败")
                }
            }).then(_ => {
                this.checking = false
            })
        },
        revokeEnvelope(){
            this.revoking = true
            revokeEnvelope({
                envelopeWsid: this.envelopeWsid,
                revokeReason: this.revokeMessage
            }).then(err => {
                this.$message.success("撤销文件成功")
                wesignSignatureSDK.operationComplete("REVOKE")
                if (this.pageCallback){
                    this.$alert("撤销成功!", "提醒", {
                        type: "success"
                    }).then(_ => {}, _ => {}).then(_ => {
                        this.openAPIEnvelopCompleteJump(ACTIONS.REVOKED)
                    })
                } else {
                    this.$router.push({
                        name: "envelope-detail",
                        params: {
                            envelopeId: this.envelopeWsid
                        }
                    })
                }
            }).catch(err => {
                this.$message.error("撤销文件失败")
            }).then(_ => {
                this.revoking = false
            })
        },
        documentsLoaded(documentsData){
            this.documentsData = documentsData
        },
        documentsViewUpdate(updateInfo){
            this.activeDocumentId = updateInfo.docId
            this.activePage = updateInfo.page
            this.$refs.previewbar.gotoDocumentPage(this.activeDocumentId, this.activePage)
        },
        zoomIn(){
            let biggerScale = this.scaleList.find(scale => scale > this.scale)
            if (biggerScale){
                this.scale = biggerScale
            }
        },
        zoomOut(){
            let index = this.scaleList.findIndex(scale => scale >= this.scale)
            if (index == undefined) index = this.scaleList.length
            if (index > 0) index--
            this.scale = this.scaleList[index]
        },
        gotoDocument(docId){ //选择文档
            this.$refs.preview.gotoDocumentPage(docId, 1)
            this.$refs.previewbar.gotoDocumentPage(docId, 1)
        },
        gotoPage(page){
            this.$refs.preview.gotoDocumentPage(this.activeDocumentId, page)
            this.$refs.previewbar.gotoDocumentPage(this.activeDocumentId, page)
        },
        prevewNavSelect(docId, page){
            this.$refs.preview.gotoDocumentPage(docId, page)
        },
        openAPIEnvelopCompleteJump(action){ //开放平台来的页面进行跳转
            if (!this.pageCallback || this.pageCallback === "DEFAULT"){
                this.$router.replace({
                    path: "/result",
                    query: {
                        result: action
                    }
                })
            } else {
                gotoOpenSignatureReturnURL(this.pageCallback, action, {
                    envelopeWsid: this.envelopeWsid,
                    participantWsid: this.participantWsid
                })
            }
        }
    },
    components: {
        envelopePreview,
        documentsPreviewBar,
        // checkNotpassDialog,
        // revokeDialog
    }
}
</script>

<style lang="less" scoped>
@import '~@styles/variable.less';

.envelope-signature-header{
    z-index: 10;
    position: absolute;
    top:0;
    left: 0;
    width: 100%;
    height: @length-top-nav-height;
    line-height: @length-top-nav-height;
    background: @color-nav-background;
    box-shadow: @shadow-default;
    font-size: @font-size-primary;
    color:@color-list-font;


    .envelope-editor-back{
        cursor: pointer;
        float: left;
        margin-left: 20px;
    }

    .documents-info-toolbar{
        position: absolute;
        top:0;
        bottom: 0;
        left: 200px;
        right: 0;
        display: flex;
        justify-content: center;

        & > div{
            margin-right: 50px;
        }

        .documents-select{
            width: 200px;
        }

        .document-progress{
            width: 100px;
        }

        .documents-scale{
            width: 200px;
            display: flex;
            align-items: center;

            i{
                width: 20px;
                text-align: center;
                cursor: pointer;
                font-size: @font-size-large;
            }
        }
    }

    .envelope-signature-help{
        cursor: pointer;
        float: right;
        margin-right: 40px;

        i{
            font-size: 20px;
            vertical-align: middle;
        }
    }
}

.envelope-signature-footer{
    position: absolute;
    z-index: 10;
    height: @length-top-nav-height;
    line-height: @length-top-nav-height;
    left: 0;
    width: 100%;
    bottom: 0;
    text-align: center;

    background: @color-nav-background;
    box-shadow: @shadow-default;

    .forms-count{
        display: inline-block;
        margin-right: 60px;
        width: 120px;
        text-align: center;
        font-size: @font-size-primary;
    }

    .btn-complete{
        height: 40px;
        width: 120px;
        margin-right: 60px;
    }

    .btn-danger{
        height: 40px;
        width: 80px;
        margin-right: 30px;
    }

    .btn-danger-reject{
        height: 40px;
        width: 120px;
        margin-right: 30px;
    }
}

.envelope-signature-container{
    z-index: 9;
    position: absolute;
    top:@length-top-nav-height;
    left: 0;
    width: 100%;
    bottom: @length-top-nav-height;

    .right-container{
        position: absolute;
        top:0;
        right: 0;
        bottom: 0;
        transition:  width .3s;

        .right-box{
            position: absolute;
            top:0;
            width: 100%;
            left: 0;
            bottom: 0;
            overflow: hidden;
        }

        .documents-preview-nav{
            position: absolute;
            top:0;
            width: 120px;
            left: 0;
            bottom: 0;
            background: @color-nav-background;
            box-shadow: @shadow-default;

            .title{
                font-size: @font-size-regular;
                text-align: center;
                height: 50px;
                line-height: 50px;
            }
            
            .documents-preview{
                position: absolute;
                top:50px;
                bottom: 0;
                left: 0;
                right: 0;
            }
        }

        .right-container-switch{
            cursor:pointer;
            z-index: 10;
            position: absolute;
            top:50%;
            left:0;
            height: 60px;
            width: 20px;
            text-align: center;
            transform: translate(-100%, -50%);
            background: rgba(0,0,0,0.1);
            transition: all .3s;

            &.open{
                border-top-right-radius: 5px;
                border-bottom-right-radius: 5px;
                transform: translate(0, -50%);
            }

            &.close{
                border-top-left-radius: 5px;
                border-bottom-left-radius: 5px;
                transform: translate(-100%, -50%);

                .line{
                    transform-origin: 50% 50%;
                    transform: rotateY(180deg);
                }
            }

            &:hover{
                background: @color-main;

                .line{
                    stroke:@color-white;
                }
            }

            .line{
                fill:transparent;
                stroke:@color-info;
                stroke-width:2;
                transition: all .3s;
            }
        }
    }

    .document-container{
        position: absolute;
        top:0;
        left: 0;
        bottom: 0;
        transition:  right .3s;
    }
}

.page-form-container{
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height: 100%;
}
</style>
