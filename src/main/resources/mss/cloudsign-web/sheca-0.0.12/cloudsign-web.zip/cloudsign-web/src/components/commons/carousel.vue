<!--
    @id        ui-carousel
    @desc      轮播内容组件
    @level     ui
    @author    周雪梅  
    @date      2018-05-28 11:53:55
-->
<template>
    <div>
        <el-carousel :interval="5000" trigger="click" :height="fullHeight + 'px'" arrow="always">
            <div>
                <img @click="closeHelp" class="close-help" :src="closeBtn"/>
            </div>
            <el-carousel-item v-for="img in images" :key="img">
                <img class="carousel-img" :src="img">
            </el-carousel-item>
        </el-carousel>
    </div>
</template>
<script>
import closeBtn from "@images/help/close.jpg" 
export default{
    props: {
        images: {
            type: Array
        }
    },
    data(){
        return {
            closeBtn: closeBtn,
            fullHeight: document.documentElement.clientHeight,
            timer: false
        }
    },
    watch: {
        fullHeight (val) {
            if (!this.timer) {
                this.fullHeight = val
                this.timer = true
                setTimeout(_ => {
                    this.timer = false
                }, 400)
            }
        }
    },
    mounted(){
        this.resizeFullHeight()
        window.addEventListener("resize", this.resizeFullHeight)
    },
    beforeDestroy(){
        window.removeEventListener("resize", this.resizeFullHeight)
    },
    methods: {
        resizeFullHeight(){
            this.fullHeight = document.documentElement.clientHeight
        },
        closeHelp(){
            this.$emit("closeHelp")
        }
    }
}
</script>
<style lang="less" scoped>
.close-help{
    width:40px;
    height:40px;
    position:absolute;
    right:15px;
    top:5px;
    z-index:100;
    cursor:pointer;
}
</style>