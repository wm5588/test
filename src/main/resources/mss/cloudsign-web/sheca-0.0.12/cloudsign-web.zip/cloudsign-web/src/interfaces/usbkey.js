import _axios from "axios"

const axios = _axios.create()
axios.defaults.withCredentials = false
let UkJsBridge = window.SheCaSDK.UkJsBridge;
let Util = window.SheCaSDK.Util

/**
 * ----------------------------------------------------
 * @path   http://127.0.0.1:8223
 * @method POST
 * @desc   查询USBkey的内容
 * @author 陈曦源
 * @date   2019-09-03 14:32:02
 * ----------------------------------------------------
 */
export function getUSBKeysList(obj) {

    return axios.post("http://127.0.0.1:8223", {
        Function: "SOF_GetUserList"
    }).then(res => {
        if (res.data){
            let data = res.data
            let usbkeys = data.split("&&&").filter(x => x).map(usbkey => {
                let [name, certId] = usbkey.split("||")
                return getCertData({certId}).then(res => {
                    return {
                        name,
                        certId,
                        certData: res.data,
                    }
                })
            })
            return Promise.all(usbkeys).then(usbkeys => {
                res.data = usbkeys
                return res
            })
        } else {
            throw new Error("NOT_FIND_USBKEY")
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   http://127.0.0.1:8223
 * @method POST
 * @desc   查询获取USBKEY证书
 * @author 陈曦源
 * @date   2019-09-03 14:32:07
 * ----------------------------------------------------
 */
export function getCertData(obj) {
    let {
        certId
    } = obj

    return axios.post("http://127.0.0.1:8223", {
        Function: "SOF_ExportUserCert",
        CertID: certId
    })
}

/**
 * ----------------------------------------------------
 * @path   http://127.0.0.1:8223
 * @method POST
 * @desc   查询获取USBKEY的图片
 * @author 陈曦源
 * @date   2019-09-04 10:17:33
 * ----------------------------------------------------
 */
export function getCertImage(obj) {
    let {
        certId
    } = obj

    return axios.post("http://127.0.0.1:8223", {
        Function: "SOF_GetPic",
        strConName: certId
    })
}

/**
 * ----------------------------------------------------
 * @path   http://127.0.0.1:8223
 * @method POST
 * @desc   签名
 * @author 陈曦源
 * @date   2019-09-03 14:32:11
 * ----------------------------------------------------
 */
export function signByteData(obj) {
    let {
        certId,
        signData
    } = obj

    return axios.post("http://127.0.0.1:8223", {
        Function: "SOF_SignByteData",
        CertID: certId,
        Base64Data: signData
    })
}

/**
 * ----------------------------------------------------
 * @method POST
 * @desc   查询USBkey的内容
 * @author 周雪梅
 * @date   2020-08-12 11:25:44
 * ----------------------------------------------------
 */
export function gethSheCaUSBKeysList(obj) {
    return UkJsBridge.getUkList().then(res =>{
        if(res.list){
            let data = res.list
            let usbkeys = data.map(usbkey => {
                return getSheCaCertData({
                    asymid:usbkey.asymid, 
                    usage:usbkey.usage, 
                    devType:usbkey.devType,
                    devParam:usbkey.devParam,
                    keySN:usbkey.keySN
                }).then(res => {
                    console.log(res,1)
                    let cert = res.cert
                    let params = {
                            cert:cert, 
                            oidArray:[]
                        }
                   let resInfo =  Util.certificateDecoder(params.cert,params.oidArray)
                   console.log(resInfo,3)
                   return {
                        cert:cert,
                        sourceName:resInfo.issueerInfo.value.O,
                        certPath:resInfo.issueerInfo.value.CN,
                        startDateTime:resInfo.date.value.validBeginDate,
                        endDateTime:resInfo.date.value.validEndDate,
                        ownerInfoName:resInfo.ownerInfo.value.CN,
                        certSerialNumber: resInfo.sn.value,
                        algorithm:resInfo.algorithm.value,
                        asymid:usbkey.asymid,
                        usage:usbkey.usage,
                        devType:usbkey.devType,
                        devParam:usbkey.devParam,
                    }
                })
            })
            return Promise.all(usbkeys).then(usbkeys => {
                res.data = usbkeys
                return res
            })
        }else {
            throw new Error("ERR_CONNECTION_REFUSED")
        }
    })
}

export function  sheCaCertificateDecoder(obj){
    return Util.certificateDecoder(obj)
}

/**
 * ----------------------------------------------------
 * @method POST
 * @desc   签名
 * @author 周雪梅
 * @date   2020-08-12 11:24:44
 * ----------------------------------------------------
 */
export function  sheCaSignByteData(params) {
    return UkJsBridge.sign(params.data,params.pwd,params.isHex,params.algid,params.devType,params.devParam,params.asymid)
}

/**
 * ----------------------------------------------------
 * @method GET
 * @desc   查询获取USBKEY证书
 * @author 周雪梅
 * @date   2020-08-12 11:24:28
 * ----------------------------------------------------
 */
export function getSheCaCertData(obj) {
    return UkJsBridge.getCert(obj)
}