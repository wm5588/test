<template>
    <div class="sys-rmain-container">
        <div class="sys-rmain-header">
            <span class="bar-title"><i class="icon icon-contact"></i>通讯录</span>
            <div class="right-nav">
                <div class="search-group">
                    <el-button type="info" @click="openAddContactDialog">添加联系人</el-button>
                    <input type="text" class="search-input" placeholder="搜索成员姓名和手机号" v-model.trim="query">
                    <a href="#" @click="queryContacts(1)"><i class="icon icon-search"></i></a>
                </div>
            </div>
        </div>
        <div class="sys-container-content">
            <div class="tabel-header">
                <div class="tab-head">
                    <div class="td-item td-w1">姓名</div>
                    <div  class="td-item td-w2">手机</div>
                    <div  class="td-item td-w3">邮箱</div>
                    
                    <div  class="td-item td-w4">状态</div>
                    <div  class="td-item td-w5">类型</div>
                    <div  class="td-item td-w6">操作</div>
                </div>
            </div>
            <div class="contacts-container view" v-loading="loading">
                <div class="td-public" v-for="(c,index) in contactsList" :key="c">
                    <div class="td-item td-w1">
                        {{c.nickname}}
                        <span v-if="c.companyName">
                            ({{c.companyName}})
                        </span>
                    </div>
                    <div  class="td-item td-w2">{{c.phone}}</div>
                    <div  class="td-item td-w3">{{c.email}}</div>
                    <div  class="td-item td-w4"><a href="#" :class='{"active": c.status <1}'>{{c.authentic}}</a></div>
                    <div  class="td-item td-w5">
                        <template v-if="c.companyName">企业</template>
                        <template v-else>个人</template>
                    </div>
                    <div  class="td-item td-w6">
                        <li>
                            <a href="#" @click="openUpdateContactDialog(c)"><i class="edit icon-edit"></i>编辑</a>
                        </li>
                        <li>
                            <a href="#" @click="deleteContact(c.contactWsid)"><i class="bin icon-bin"></i>删除</a>
                        </li>
                        <ul v-if="c.status === 0">
                            <li>
                                <a href="#"><i class="email icon-email"></i>发送邀请</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div>
                <pagination :nowPage = 'nowPage'
                :maxPage='maxPage' @changePage='changePage' @nextOrlast='changePage'></pagination>
            </div>
        </div>
        <el-dialog title="添加联系人" :visible.sync="addContact">
            <el-tabs v-model="activeTab">
                <el-tab-pane label="个人" name="personal">
                    <el-input v-model="personalContact.name">
                        <template slot="prepend">姓名:</template>
                    </el-input>
                    <el-input v-model="personalContact.contact">
                        <template slot="prepend">手机号/邮箱:</template>
                    </el-input>
                    <el-row style="text-align:center">
                        <el-button type="info" @click="appendContact">添加</el-button>
                        <el-button @click="closeAddContactDialog">取消</el-button>
                    </el-row>
                </el-tab-pane>
                <el-tab-pane label="企业" name="enterprise">企业</el-tab-pane>
            </el-tabs>
        </el-dialog>
        <el-dialog title="修改联系人" :visible.sync="updateContact">
            <el-input v-model="updateContactData.nickname">
                <template slot="prepend">姓名:</template>
            </el-input>
            <el-row style="text-align:center">
                <el-button type="info" @click="reqUpdateContact">更新</el-button>
                <el-button @click="closeUpdateContactDialog">取消</el-button>
            </el-row>
        </el-dialog>
    </div>
</template>


<script>
import pagination from "@components/commons/pagination.vue"
import {isEmail, isPhone} from "@wesign/check"
import { contacts_get, contacts_post, contacts_delete, contact_put } from "@interfaces/user/contacts.js"

const AUTH_NAME = {
    ENTERPRISE: "企业认证",
    PERSON: "个人认证",
    INCOMPLETE: "未完善",
    UNREGIST: "未注册",
    UNAUTHENTIC: "未实名认证"
}

export default {
    data: function () {
        return {
            nowPage: 1,
            maxPage: 5,
            limit: 20,
            loading: false,
            addContact: false,
            updateContact: false,
            query: "", //查询
            activeTab: "personal",
            contactsList: [],
            personalContact: {
                name: "",
                contact: ""
            },
            updateContactData: {
                contactWsid: "",
                nickname: ""
            }
        }
    },
    created(){
        this.queryContacts()
    },
    methods: {
        changePage(page) {
            this.queryContacts(page)
        },
        status(status) {
            switch (status) {
                case 0: return "未注册"; break
                case 1: return "已认证"; break
            }
        },
        openAddContactDialog(){
            this.addContact = true
        },
        resetpersonalContact(){
            this.personalContact = {
                name: "",
                phone: ""
            }
        },
        closeAddContactDialog(){
            this.resetpersonalContact()
            this.addContact = false
        },
        appendContact(){
            let {
                name,
                contact
            } = this.personalContact

            if (name === ""){
                this.$message.info("联系人姓名不能空!")
                return
            }

            if (!(isEmail(contact).result || isPhone(contact).result)){
                this.$message.info("请输入正确的联系手机号或邮箱!")
                return
            }

            let userWsid = this.$store.getters.userWsid

            contacts_post({
                userWsid,
                nickname: name,
                contact
            }).then(data => {
                this.$message.success("添加联系人成功!")
                this.queryContacts()
                this.closeAddContactDialog()
            }).catch(err => {
                if (err.data){
                    if (err.data.code === "0306"){
                        this.$message.info("联系人已存在!")
                        return
                    }
                }
                this.$message.error("添加联系人失败!")
                console.error(err)
            })
        },
        //打开更新联系人弹框
        openUpdateContactDialog(contact){
            this.updateContact = true
            this.updateContactData.contactWsid = contact.contactWsid
            this.updateContactData.nickname = contact.nickname
        },
        //重置更新联系人对象信息
        resetupdateContact(){
            this.updateContactData = {
                contactWsid: "",
                nickname: ""
            }
        },
        //关闭更新联系人弹框
        closeUpdateContactDialog(){
            this.resetupdateContact()
            this.updateContact = false
        },
        //请求更新联系人
        reqUpdateContact(){
            let {
                nickname,
                contactWsid
            } = this.updateContactData

            if (nickname === ""){
                this.$message.info("联系人姓名不能空!")
                return
            }

            let userWsid = this.$store.getters.userWsid

            contact_put({
                userWsid,
                nickname,
                contactWsid
            }).then(_ => {
                this.$message.success("修改联系人成功!")
                let contact = this.contactsList.find(c => c.contactWsid === contactWsid)
                contact.nickname = nickname
                this.closeUpdateContactDialog()
            }).catch(err => {
                this.$message.error("修改联系人失败!")
                console.error(err)
            })
        },
        queryContacts(page = 1){
            this.loading = true
            
            let keyword, scope
            if (this.query !== ""){
                keyword = this.query
                scope = "name,email,phone"//FIXME: 后台nickname未转换先用name
            }

            contacts_get({
                userWsid: this.$store.getters.userWsid,
                limit: this.limit,
                offset: this.limit * (page - 1),
                keyword,
                scope
            }).then(body => {
                let data = body.data

                this.contactsList = data.contactsList
                this.nowPage = page
                this.maxPage = data.page.totalPages
            }).catch(err => {
                console.error(err)
            }).then(_ => {
                this.loading = false
            })
        },
        deleteContact(contactWsid){
            let userWsid = this.$store.getters.userWsid

            this.$confirm("此操作将删除该联系人, 是否继续?", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {

                contacts_delete({
                    userWsid,
                    contactWsid
                }).then(data => {
                    this.$message.success("删除联系人成功!")
                    this.queryContacts()
                }).catch(err => {
                    console.error(err)
                })

            }).catch(() => {
                this.$message({
                    type: "info",
                    message: "已取消删除"
                })
            })
        }
    },
    components: { pagination },
}
</script>


<style lang="less" scoped>
@import "~@styles/variable.less";
.view{
    padding:0 30px;

    bottom:50px;
}
.contacts-container{
    position: absolute;
    left: 0;
    right:0;
    top:50px;
    
    overflow-y: auto;
    z-index: 0
}
 .tab-head{
    padding: 0 30px;
    height:50px;
    line-height:50px;
}
.td-public:nth-child(even){
 background:@color-list-choose;
}
.td-w1{
    width:15%;
    text-indent: 20px;
}
.td-w2{
    width:20%
}
.td-w3{
    width:25%
}
.td-w4{
    width:10%
}
.td-w5{
    width:10%
}
.td-w6{
    width: 15%
}
.td-w6 a{
    margin-right:10px;
}
.td-item{
    display:inline-block;
    text-align:left;
    
}

.view .td-item span{
    display: block;
    color:@color-subtitle;
    font-size:@font-size-info;
   
}
.view .td-item{
      padding:15px 0;
      vertical-align: middle;
}
.tab-head,.td-public{
    border-bottom:1px solid @color-line;
}
li{
    display:inline-block;
}
.td-public .active{
color:@color-inmportant;
}
.noregister{
    color:@color-inmportant;
}
// 页码
.pagination{
    position: absolute;
    bottom: 0;;
    right: 0;
    left: 0;
    padding: 0 30px;
    height: 50px;
    text-align: center;
    }

.el-input{
    margin-bottom:10px;
}

</style>