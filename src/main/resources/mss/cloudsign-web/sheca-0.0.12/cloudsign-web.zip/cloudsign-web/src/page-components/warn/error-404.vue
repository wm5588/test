<template>
    <h1>404 Not Found !</h1>  
</template>

<script>
export default {
    //TODO: 待施工
}
</script>
