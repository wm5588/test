<!-- 实名认证弹框 -->
<template>
	<modal @close-modal='close' width='400px' height = '260px'  top='200px' title='提示'>
		<div class='auth-cont'><span class="to-identify" @click='toIdentify()'>实名认证</span></div>
		<p class="message">注:实名认证通过,<span>免费</span>颁发专有证书</p>
    </modal>
</template>

<script>
	import modal from './modal.vue'
    export default{
    	data:function(){
    		return{
    		}
    	},
		components:{modal},
    	methods:{
    		toIdentify:function(){
    			window.location.href = '/wesign/user/auth/person-auth';
    		},
			close:function(){
				this.$emit('close-modal');
			}
    	}
    }
</script>

<style scoped>
	.auth-cont{
		text-align: center;
		padding: 55px 0;
	}
	.to-identify{
		display: inline-block;
	    cursor: pointer;
	    padding: 10px 50px;
	    color: #fff;
	    background-color: #66a3ff;
	}
	.to-identify:hover{
		background-color: #6198f2;
	}
	.message{
	    border-top: 1px #e9e9ea solid;
	    padding: 25px 10px 22px 10px;
        text-align: center;
        font-size: 0.8em;
	}
	.message > span{
		color: #33cc99;
	}
</style>