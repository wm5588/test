<template>
    <el-dialog style="text-align:center"
            :visible.sync="dialogVisible"
            width="500px">
            <p class="title">没有可用的合同编号规则</p>
            <p v-show="hasPermission" class="content">请移步到“合同编号”页面，添加规则后在此使用</p>
            <p v-show="!hasPermission" class="content">请通知管理员到“合同编号”页面，添加规则后在此使用</p>
            <br/>
            <el-button v-show="hasPermission" type="primary" plain @click="confirm">前往设置</el-button>
    </el-dialog>
</template>
<script>
export default {
    props: {
        hasPermission: {
            type: Boolean,
            default: false
        }
    },
    data(){
        return {
            dialogVisible: false
        }
    },
    methods: {
        open(){
            this.dialogVisible = true
        },
        confirm(){
            this.$router.push({
                name: "contract-number",
            })
        }
    }
}
</script>
<style lang="less" scoped>
@import '~@styles/variable.less';
.title{
    color: #000;
}
p{
    font-size: @font-size-primary;
}
.content{
    margin: 20px 0;
}
</style>

