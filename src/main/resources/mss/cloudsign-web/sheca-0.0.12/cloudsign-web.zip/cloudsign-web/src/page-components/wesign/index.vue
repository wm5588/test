<template>
    <component :is="nowComponent"></component>
</template>

<script>
import userIndex from "./index-user.vue"
import enterpriseIndex from "./index-enterprise.vue"

export default {
    computed: {
        nowComponent(){
            if (this.$store.getters.userEdition === 'p'){
                return 'userIndex'
            } else if (this.$store.getters.userEdition === 'e'){
                return 'enterpriseIndex'
            }
        }
    },
    components: {
        userIndex,
        enterpriseIndex
    }
}
</script>