<!--
    @id        system-choose-seals
    @desc      选择签名/印章组件
    @level     system：系统组件
    @functions 内部提供给外部的驱动函数
        open(): 打开组件
        close():关闭组件
    @author    陈曦源
    @date      2019-09-24 16:21:27
-->
<template>
    <el-dialog title="选择印章" :visible.sync="dialogVisible" :close-on-click-modal="false" width="690px" @close="close">
        <div style="min-height: 300px">
            <el-input v-model="sealSearchKeyword" clearable placeholder="关键字搜索印章..." @input="searchSeals">
                <i slot="prefix" class="el-input__icon el-icon-search"></i>
            </el-input>
            <div v-show="officialSeals.length > 0" v-infinite-scroll="loadMoreSeals" class="seals-container">
                <div v-for="seal in officialSeals" :key="seal.id" class="seal-item" @click="selectedData(seal)">
                    <i class="icon-complete choose"></i>
                    <imgBox class="image" :src="seal.imageData"></imgBox>
                    <div class="name">{{seal.name}}</div>
                </div>
            </div>
            <center v-if="officialSeals.length > 0" style="line-height:20px; height: 20px">
                {{loading ? "加载中..." : ""}}
            </center>
            <center v-else style="line-height:200px; height: 200px">
                {{loading ? "加载中..." : "没有相关印章"}}
            </center>
            <div class="footer">
                <span class="undeline" @click="applySeal">
                    没有可用印章?点击申请或添加
                </span>
            </div>
        </div>
    </el-dialog>
</template>

<script>
import { cm2pt } from "@utils/translate.js"
import debounce from "@utils/debounce.js"

import imgBox from "@components/commons/img-box.vue"

import { getAuthorizeSeals,getGeneralOfficeSeals } from "@interfaces/seals/seals.js"

const REQUEST_LIMIT = 10

export default {
    props: {
        enterpriseUserWsid:{
            type:String,
            required: true
        },
        sealManagePermission:{ //是否具有印章管理权限
            type: Boolean,
            required: false,
            default: false
        },
        customStyles:Object
    },
    data(){
        return {
            dialogVisible: false,

            loading: false,

            officialSeals: [],//公章列表
            numOfTotalSeals: -1,
            sealSearchKeyword: "",

            resolveHandle: null,
            rejectHandle: null,
            canApplySeal:false
        }
    },
    computed:{
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        customStylesInfo(){
            return {
                background:this.customStyles.background
            }
        }
    },
    created(){
        this.loadGeneralSealsInfo()
    },
    methods: {
        async open(types){
            this.officialSeals = []
            this.numOfTotalSeals = -1
            this.sealSearchKeyword = ""
            this.loadSeals().then(_ =>{
                 if(this.numOfTotalSeals === 0){
                    this.$nextTick(_ => {
                        this.applySeal()
                    })
                 } else {
                    this.dialogVisible = true
                 }
            })
            
            return new Promise((resolve, reject) => {
                this.resolveHandle = resolve
                this.rejectHandle = reject
            })
        },
        loadGeneralSealsInfo(){
            getGeneralOfficeSeals({
                enterpriseWsid: this.enterpriseWsid,
                offset: 0,
                limit: 1,
                status: status = `UNAUTHORIZATION`,
                groupWsid: "",
            }).then(res => {
                if(res.data.data.page.totalElements > 0){
                    this.canApplySeal = true
                } else {
                    this.canApplySeal = false
                }
            }).catch(err => {
                console.error(err)
            })
        },
        close(){
            if (this.rejectHandle){
                this.rejectHandle("cancle")
                this.resolveHandle = null
                this.rejectHandle = null
            }
            this.dialogVisible = false
        },
        searchSeals:debounce(function(){
            this.officialSeals = []
            this.numOfTotalSeals = -1
            this.loadSeals()
            this.loadGeneralSealsInfo()
        }, 200),
       loadSeals(){

            if(this.loading) return
            if(this.numOfTotalSeals === this.officialSeals.length) return //加载完成
            this.loading = true

            let offset = this.officialSeals.length
            return getAuthorizeSeals({
                enterprisePersonWsid: this.enterpriseUserWsid,
                filters: `checkStatus=CHECKED,status=NORMAL`,
                offset,
                scope: "name",
                keyword: this.sealSearchKeyword,
                limit: REQUEST_LIMIT,
            }).then(res => {
                let officeSeals = res.data.data.officeSeals
                let seals = officeSeals.map(officeSeal => {
                    let dimension = officeSeal.dimension || {width: 40, height: 40}
                    return {
                        id: officeSeal.officeSealWsid,
                        name: officeSeal.name,
                        imageData: officeSeal.link.href,
                        deadline: officeSeal.deadline ? officeSeal.deadline : "",
                        width: cm2pt(dimension.width),
                        height: cm2pt(dimension.height) || cm2pt(dimension.width)
                    }
                })
                this.officialSeals = this.officialSeals.concat(seals)
                this.numOfTotalSeals = res.data.data.page.totalElements
            }).catch(err => {
                console.error(err)
                this.$message.error("加载获取印章数据失败")
            }).then(_ => {
                this.loading = false
            })
        },
        loadMoreSeals(){
            this.loadSeals()
        },
        selectedData(data){
            data = {
                id: data.id,
                imageData: data.imageData,
                width: data.width,
                height: data.height
            }
            
            if (this.resolveHandle){
                this.resolveHandle(data)
                this.resolveHandle = null
                this.rejectHandle = null
            }
            this.dialogVisible = false
        },
        applySeal(){
            if(this.sealManagePermission){
                this.$confirm("没有可用印章?<br>请前往印章管理页面添加印章", "提示",{
                    type: "warning",
                    dangerouslyUseHTMLString: true,
                    confirmButtonText: "立即前往",
                    cancelButtonText: "稍后处理",
                    callback: action => {
                        if (action === "confirm"){
                            this.dialogVisible = false
                            this.$emit("to-manage-seals")
                        } 
                    }
                })
            }  else if(!this.sealManagePermission && this.canApplySeal) {
                this.$confirm("没有可用印章?<br>向管理员申请用章", "提示",{
                    type: "warning",
                    dangerouslyUseHTMLString: true,
                    confirmButtonText: "立即申请",
                    cancelButtonText: "取消"
                }).then(_ => {
                    this.$emit("apply")
                    this.$nextTick(_ => this.close())
                })
            } else if(!this.sealManagePermission && !this.canApplySeal){
                this.$confirm("没有可用印章?<br>请通知管理员添加印章并授权您印章使用权限", "提示",{
                    type: "warning",
                    dangerouslyUseHTMLString: true,
                    confirmButtonText: "已完成设置",
                    cancelButtonText: "取消"
                }).then(_ => {
                    this.sealSearchKeyword = ""
                    this.searchSeals()
                    this.$emit("chooseOfficialSeal")
                })
            }
                
        },
    },
    components: {
        imgBox
    }
}
</script>

<style lang="less" scoped>
@import '~@styles/variable.less';

.seals-container{
    margin-top: 10px;
    text-align: center;

    overflow: auto;
    max-height: 360px;

    p{
        font-size: @font-size-primary;
    }
}
.customStylesInfo{
    background:#000 !important
}

.seal-item{
    float: left;
    
    cursor: pointer;
    position: relative;
    box-sizing: border-box;
    width: 150px;
    height: 150px;
    padding: 10px;
    margin-right: 10px;
    margin-bottom: 10px;
    border: 1px solid @color-border-segment;

    .image{
        position: absolute;
        top: 10px;
        left: 20px;
        width: 110px;
        height: 110px;
        text-align: center;
    }

    .name{
        position: absolute;
        bottom: 5px;
        left: 10px;
        width: 130px;
        height: 20px;
        line-height: 20px;
        text-align: center;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: 12px;
    }

    .choose{
        display: none;
        position: absolute;
        top: 5px;
        right: 5px;
        font-size: 20px;
        color: @color-success;
    }

    &:hover{
        .choose{
            display: block;
        }
        border: 1px solid @color-main;
    }
}

.footer{
    text-align: center;
    color: @color-info;
    text-decoration-line: underline;
    
    &:hover{
        cursor: pointer;
    }

    .undeline{
        text-decoration: underline;
        cursor: pointer;
         &.active, &:hover{
            color:@color-main
         }
    }
}
</style>