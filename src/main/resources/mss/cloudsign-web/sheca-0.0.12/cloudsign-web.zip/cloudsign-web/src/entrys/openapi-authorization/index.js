import "../common.js"
import "@styles/common.less"
import Vue from "vue"
import Vuex from "vuex"
import VueRouter from "vue-router"
import axios from "@interfaces/axios.js"
import NetworkeWatcher from "@commons/check-networkstatus.js"
// import storeConfig from "@store/openapi-authorization.js"
Vue.use(VueRouter)
Vue.use(Vuex)

// let store = null
// store = new Vuex.Store(storeConfig)
//element-ui 引入
import {
    Row,
    Col,
    Message,
    Input,
    Button,
    Checkbox,
    Loading,
    Dialog,
    Select,
    Option,
    MessageBox,
    Steps,
    Step,
    Form,
    FormItem,
    Radio,
    RadioGroup,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Loading)
Vue.use(Dialog)
Vue.use(Select)
Vue.use(Option)
Vue.use(Steps)
Vue.use(Step)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Radio)
Vue.use(RadioGroup)
Vue.prototype.$loading = Loading.service
Vue.prototype.$msgbox = MessageBox
Vue.prototype.$alert = MessageBox.alert
Vue.prototype.$message = Message

import routerConfig from "@routes/openapi-authorization/router.js"
let router = new VueRouter(routerConfig)

import imagesFullscreenPreview from "@commons/images-fullscreen-preview.js"
Vue.use(imagesFullscreenPreview)

let store = null
import storeConfig from "@store/openapi-authorization/index.js"
store = new Vuex.Store(storeConfig)
// router.push("/")
router.push({
    path: `/${location.search}`
})

let networkWatcher = new NetworkeWatcher({
    onOffline(){
        MessageBox.alert("您的网络存在异常，请检查网络是否正常连接", "掉线了！", {
            confirmButtonText: "我知道了",
            callback: action => {
                networkWatcher.onLine = true
            },
            type: "error"
        })
    },
})

axios.interceptors.response.use(function (config) {
    // store.dispatch("updateUserActive")
    return config
}, function (error) {
    if (error.message === "Network Error"){
        networkWatcher.checkNetwork()
    } else if (error.response && error.response.data){
        let body = error.response.data
        let code = body.code
        if (code === 401){
            // store.dispatch("userNotActive")
        }
    }
    return Promise.reject(error)
})

import App from "@page-components/openapi-authorization/app.vue"
let vm = new Vue(Object.assign(App, {
    router,
    store
}))

vm.$mount("#app")

