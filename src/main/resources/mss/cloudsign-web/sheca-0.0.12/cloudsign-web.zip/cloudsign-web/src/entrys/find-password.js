import "./common.js"
import "@styles/common.less"
import Vue from "vue"
import findPassword from "@page-components/externals/find-password.vue"

//element-ui 引入
import {
    Row,
    Col,
    Message,
    Input,
    Button,
    Checkbox,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Checkbox)
Vue.prototype.$message = Message

new Vue({
    el: "#app",
    template: "<findPassword />",
    components: {
        findPassword
    }
})