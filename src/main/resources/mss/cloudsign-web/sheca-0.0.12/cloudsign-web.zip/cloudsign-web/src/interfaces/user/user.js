import axios from "@interfaces/axios.js"
import SparkMD5 from "spark-md5"

/**
 * ----------------------------------------------------
 * @path   /api/enterprises
 * @method GET
 * @desc   查询用户的所有账户
 * @author 周雪梅,陈曦源
 * @date   2018-02-28 21:25:54
 * ----------------------------------------------------
 */
export function getUserAccounts(obj) {
    let {
        userWsid,
        filters = null,
        offset,
        limit,
        sorts = "+id",
        fields = null
    } = obj

    return axios.get("/api/users/" + userWsid + "/accounts", {
        params: {
            filters,
            offset,
            limit,
            sorts,
            fields
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/accounts/change
 * @method POST
 * @desc   更换session
 * @author 陈曦源
 * @date   2018-02-03 22:01:50
 * ----------------------------------------------------
 */
export function changeSession(obj) {
    let {
        userWsid,
        destinationWsid
    } = obj

    return axios.post(`/api/users/${userWsid}/accounts/change`, {
        destinationWsid
    })
}

/**
 * ----------------------------------------------------
 * @desc  找回密码: 用户找回密码
 * @from  用户中心微服务API-用户 | POST /users/retrieve-password
 * @date  2017-11-16 11:20:32
 * ----------------------------------------------------
 */
export function retrievePassword(obj) {
    let {
        opcode,
        newPassword,
        account
    } = obj

    newPassword = SparkMD5.hash(newPassword)

    return axios.put("/api/users/retrieve-password", {
        opcode,
        newPassword,
        account
    })
}

/**
 * ----------------------------------------------------
 * @desc  修改密码: 用户修改密码
 * @from  用户中心微服务API-用户 | PUT /users/{user-wsid}/reset-password
 * @date  2017-09-02 10:40:11
 * ----------------------------------------------------
 */
export function resetPassword(obj) {
    let {
        userWsid,
        oldPassword,
        newPassword
    } = obj

    oldPassword = SparkMD5.hash(oldPassword)
    newPassword = SparkMD5.hash(newPassword)

    return axios.put(`/api/users/${userWsid}/reset-password`, {
        oldPassword,
        newPassword
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/sign-password
 * @method POST
 * @desc   添加签署密码
 * @author 陈曦源
 * @date   2018-08-22 14:19:21
 * ----------------------------------------------------
 */
export function setSignPassword(obj) {
    let {
        userWsid,
        signPassword
    } = obj

    signPassword = SparkMD5.hash(signPassword)

    return axios.post(`/api/users/${userWsid}/sign-password`, {
        signPassword
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/sign-password
 * @method PUT
 * @desc   修改签署密码
 * @author 陈曦源
 * @date   2018-08-22 14:21:33
 * ----------------------------------------------------
 */
export function resetSignPassword(obj) {
    let {
        userWsid,
        oldSignPassword,
        newSignPassword
    } = obj

    oldSignPassword = SparkMD5.hash(oldSignPassword)
    newSignPassword = SparkMD5.hash(newSignPassword)

    return axios.put(`/api/users/${userWsid}/sign-password`, {
        oldSignPassword,
        newSignPassword
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/sign-password/verify
 * @method POST
 * @desc   验证签署密码
 * @author 陈曦源
 * @date   2018-08-23 15:51:00
 * ----------------------------------------------------
 */
export function verifySignPassword(obj) {
    let {
        userWsid,
        signPassword
    } = obj

    signPassword = SparkMD5.hash(signPassword)

    return axios.post(`/api/users/${userWsid}/sign-password/verify`, {
        signPassword
    })
}
/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/sign-password/retrieve
 * @method PUT
 * @desc   找回签署密码
 * @author 潘维
 * @date   2018-10-23 09:38:05
 ** ----------------------------------------------------
 */
export function retrieveSignPassword(obj) {
    let {
        opcode,
        newPassword,
        account,
        userWsid
    } = obj

    newPassword = SparkMD5.hash(newPassword)

    return axios.put(`/api/users/${userWsid}/sign-password/retrieve`, {
        opcode,
        newPassword,
        account
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid
 * @method GET
 * @desc   获取用户数据
 * @author 陈曦源
 * @date   2018-03-05 16:34:50
 * ----------------------------------------------------
 */
export function getUserData(obj) {
    let {
        userWsid,
        fields
    } = obj

    return axios.get(`/api/users/${userWsid}`, {
        params: {
            fields
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid
 * @method PATCH
 * @desc   更改用户信息
 * @author 周雪梅
 * @date   2018-09-12 09:38:31
 * ----------------------------------------------------
 */
export function modifyUserInfo(obj) {
    let {
        userWsid,
        sex,
        nickname
    } = obj

    return axios.patch(`/api/users/${userWsid}`, {
        sex,
        nickname
    })

}

/**
 * ----------------------------------------------------
 * @desc  用户普通注册。
 * @from  用户中心微服务API-用户 | POST /users
 * @date  2018-02-09 21:33:11
 * ----------------------------------------------------
 */
export function usersRegist(obj) {
    let {
        account,
        password,
        nickname,
        registFrom,
        opcode,
        loginNow
    } = obj

    password = SparkMD5.hash(password)

    return axios.post("/api/users", {
        account,
        password,
        nickname,
        registFrom,
        opcode,
        loginNow
    })

}

/**
 * ----------------------------------------------------
 * @desc  form格式上传用户头像
 * @from  用户中心微服务API-用户 | POST /users/{user-wsid}/avatars/form-upload
 * @date  2017-11-18 11:52:14
 * ----------------------------------------------------
 */
export function avatars_post(obj) {
    let {
        userWsid,
        file
    } = obj

    let formdata = new FormData()
    formdata.append("file", file)

    return axios.post(`/api/users/${userWsid}/avatars/form-upload`, formdata)
}

/**
 * ----------------------------------------------------
 * @path   /api/users/check-account
 * @method POST
 * @desc   校验账户是否已存在
 * @author 陈曦源
 * @date   2018-01-26 19:09:29
 * ----------------------------------------------------
 */
export function checkAccount(obj){
    let {
        account
    } = obj

    return axios.post("/api/users/check-account", {
        account
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/verify-password
 * @method POST
 * @desc   验证登录密码
 * @author 周雪梅
 * @date   2018-01-25 10:32:45
 * ----------------------------------------------------
 */
export function verifyPassword(obj){
    let {
        password
    } = obj

    password = SparkMD5.hash(password)

    return axios.post("/api/users/verify-password", {
        password
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/${userWsid}/bind-contact
 * @method POST
 * @desc   覆盖绑定联系方式
 * @author 周雪梅
 * @date   2018-01-25 10:31:59
 * ----------------------------------------------------
 */
export function bindContact(obj){
    let {
        userWsid,
        contact,
        opcode
    } = obj

    return axios.post(`/api/users/${userWsid}/bind-contact`, {
        contact,
        opcode
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/${userWsid}/unbind-wechat
 * @method DELETE
 * @desc   解绑微信帐号
 * @author 周雪梅
 * @date   2019-02-27 19:37:13
 * ----------------------------------------------------
 */
export function unbindWechat(obj){
    let {
        userWsid,
    } = obj

    return axios.delete(`/api/users/${userWsid}/unbind-wechat`)
}

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/accounts-default
 * @method PUT
 * @desc   设置默认登录账户
 * @author 周雪梅
 * @date   2018-06-13 17:27:08
 * ----------------------------------------------------
 */
export function accountsDefault(obj) {
    let {
        userWsid,
        enterpriseWsid,
        isDefault
    } = obj


    return axios.put(`/api/users/${userWsid}/accounts/default`, {
        enterpriseWsid,
        isDefault
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/search
 * @method POST
 * @desc   添加签署密码
 * @author 陈曦源
 * @date   2018-08-22 14:19:21
 * ----------------------------------------------------
 */
export function userSearch(obj) {
    let {
        filters,
        userWsid
    } = obj


    return axios.post(`/api/users/uersearch`, {
        filters,
        userWsid
    })
}