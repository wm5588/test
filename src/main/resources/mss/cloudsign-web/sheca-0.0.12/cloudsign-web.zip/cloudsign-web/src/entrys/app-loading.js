/* 应用启动入口 */
import "./common.js"
import "@styles/common.less"
import SystemLoading from "@commons/system-loading.js"

SystemLoading.open()
SystemLoading.setLoadingText("加载应用数据...")
require.ensure([], () => {
    require("./pc/common.js")
    require("./pc/app.js")
}, err => {
    console.error(err)
    SystemLoading.setLoadingText("加载应用数据失败...X0X")
}, "async-app")