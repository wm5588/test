const exit = require("$exit")
const askend = require("$HMAC").askend

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid
 * @method GET
 * @desc   获取用户数据
 * @author 陈曦源
 * @date   2018-03-05 16:29:55
 * ----------------------------------------------------
 */
exports.get = function (req, res, next) {
    let {
        userWsid
    } = req.params

    let {
        enterpriseWsid,
        fields
    } = req.query

    askend({
        reqMethod: "get",
        reqURL: `wesign-mss-user://users/${userWsid}`,
        reqQuery: {
            fields
        },
        reqSession: req.cookies.SessionWsid
    }).then(resp => {
        let userInfo = resp.data.userInfo
        if (userInfo.enterprise){ //FIXME:兼容获取MemberWsid
            return askend({
                reqMethod: "get",
                reqURL: `wesign-mss-enterprise://enterprises/${userInfo.enterprise.enterpriseWsid}/members`,
                reqQuery: {
                    filters: `authorWsid=${userWsid}`
                },
                reqSession: req.cookies.SessionWsid
            }).then(resp => { //TODO:更高效的方法
                let enterpriseMembers = resp.data.enterpriseMembers
                let enterpriseMember = enterpriseMembers.find(enterpriseMember => enterpriseMember.authorWsid === userWsid)
                userInfo.enterprise.memberWsid = enterpriseMember.memberWsid
                return userInfo
            })
        }
        return userInfo
    }).then(userInfo => {
        exit(res, {
            userInfo
        })
    }).catch(err => {
        next(err)
    })
}

/**
 * ----------------------------------------------------
 * @desc  用户普通注册
 * @from  用户中心微服务API-用户 | POST /users
 * @date  2017-12-26 11:56:50
 * @author 周雪梅
 * ----------------------------------------------------
 */
exports.post = function (req, res, next) {
    let {
        account,
        password,
        nickname,
        registFrom,
        opcode,
        loginNow
    } = req.body

    if (!account || !password || !nickname || !registFrom || !opcode){
        exit.error4(res, "参数不正确")
        return
    }

    askend({
        reqMethod: "post",
        reqURL: "wesign-mss-user://users",
        reqData: {
            account,
            password,
            nickname,
            registFrom,
            loginNow
        },
        reqOpcode: opcode,
    }).then(resp => {
        let data = resp.data
        if (data.user.session && data.user.session.sessionWsid){
            res.cookie("SessionWsid", data.user.session.sessionWsid, {
                path: "/"
            })
        }
        exit(res, resp.data)
    }).catch(err => {
        /**
         * @description 注册可能出现的错误
         * @code     
         *      100 通用内部错误
         *      101 注册失败
         *      102 操作码错误
         *      103 用户已存在
         */
        let faultCode = 100
        let faultMessage = "通用内部错误"
        if (err.response){
            let status = err.response.status
            if (err.response.data){
                let code = err.response.data.code
                switch (code){
                    case "": //FIXME:后台code码未知
                        faultCode = 102
                        faultMessage = "操作码错误"
                }
            }
            exit.error(res, undefined, faultCode, faultMessage, {status, errorData: err})
        } else {
            next(err)
        }
    })
}

/**
 * ----------------------------------------------------
 * @desc   更新用户基础信息
 * @from   用户中心微服务API-用户 | POST /users
 * @date   2018-09-04 19:16:24
 * @author 周雪梅
 * ----------------------------------------------------
 */
exports.patch = function (req, res, next) {
    let {
        userWsid
    } = req.params

    let {
        sex,
        nickname
    } = req.body
    askend({
        reqMethod: "patch",
        reqURL: `wesign-mss-user://users/${userWsid}`,
        reqData: {
            sex,
            nickname
        },
        reqSession: req.cookies.SessionWsid
    }).then(resp => {
        exit(res, resp.data)
    }).catch(err => {
        next(err)
    })
}