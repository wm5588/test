<template>
    <div class="login-bg">
        <div class="container-fluid">
            <div class="header">
                <div class="header-main">
                    <div class="header-left">
                        <a href="https://web-sign.djqian.com">
                            <img class="logo" :src="logoWhiteURL">
                        </a>
                    </div>
                    <div class="header-right clearfix">
                        <ul>
                            <!-- <li><a href="/">大家签官网</a><span class="line">|</span></li>
                            <li><a href="/log">更新日志</a><span class="line">|</span></li> -->
                            <!--<li><a target="_blank" href="https://signit.kf5.com/hc/">帮助中心</a></li>-->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <img class="logo-pic" style="width:60px;" :src="logoURL"/>
        <div class="container clearfix">
            <div class="row">
                <slot></slot>
            </div>
        </div>
        <!--footer-->
        <div class="login-footer">
            <div class="ui-nologin-copy"> 上海市数字证书认证中心有限公司 Copyright ©<span>1999-{{currentYear}}</span> 版权所有 沪ICP备08100327号-24</div>
        </div>
    </div>
</template>

<script>
import logoURL from "@images/wesign-logo-main.svg"
import logoWhiteURL from "@images/wesign-logo-white.svg"

export default {
    data(){
        return {
            logoURL: logoURL,
            logoWhiteURL: logoWhiteURL,
            showLogo: false,
            currentYear: new Date().getFullYear()
        }
    },
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.login-bg{
    position: absolute;
    bottom: 10*@px;
    top: 0;
    right: 0;
    left: 0;
    min-height:450*@px;
    height: 100%;
    background:@color-background;
    overflow-x:hidden;
    overflow-y:auto;
}

.container-fluid{
    height:60px;
    background: @color-main;

    .header-main{
        height:60px;
        margin:0 auto;
        padding:0 30px;

        .header-left {
            float: left;
            line-height:60px;

            .logo{
                width: 80px;
            }
        }

        .header-right{
            float: right;
            height:60px;
            a:hover{
                text-decoration: underline;
            }
            ul,li{        
                display: inline-block;
                margin:0;
                padding:0;
                a{
                    display: inline-block;
                    color:@color-white;
                    padding:0 10px;
                    width:auto;
                    height:60px;
                    line-height:60px;
                    cursor:pointer;
                    font-size:@font-size-regular;
                    vertical-align: middle;
                }   
            }
        }
    }
}

.container{
    width: 96%;
    max-width:400*@px;
    min-width: 280px;
    height: auto;
    min-height:400*@px;
    position: absolute;
    top:14%;
    left:0;
    right:0;
    margin:0 auto;
    background:@color-white;
    box-shadow:@shadow-default;
    border-radius: 6px;
    z-index:99;
} 

.login-footer{
    position:absolute;
    bottom:10*@px;
    left: 0;
    right: 0;
    height: 30*@px;
    line-height: 20*@px;
    font-size: @font-size-info;
    text-align: center;
    color: @color-font-regular;
    z-index:8
}


.container .row .logo{
    padding-top: 20*@px;
    text-align: center;
}
.pic-title{
    text-align: center;
    font-size: @font-size-title;
    line-height:0;
    margin-top:15*@px;
    color: @color-title;
    font-weight:@font-weight-regular;
}
@media screen and (max-width:768px){
    .logo-pic{
        display:block;
        text-align:center;
        margin:15*@px auto;
    }
    .container-fluid{
        display: none;
    }
    .row .pic-title{
        margin: 0 auto;
        text-align: center;
        padding:30*@px 0 10*@px 0;
    }
}
@media screen and (min-width:768px){
    .logo-pic{
        display:none;
    }
    .container-fluid{
        display: block;
    }
    .row .pic-title{
        margin: 0 auto;
        text-align: center;
        padding:50*@px 0 10*@px 0;
    }
}

@media screen and (max-width:320px){
    .container{
        top: 65*@px !important;
        height:auto
    }
    .row .pic-title{
        padding:30*@px 0 10*@px 0;
    }
}


/*phone*/
@media screen and (min-width:321px) and (max-width:414px){
    .container{
       top: 65*@px;
    }
}

/*横屏样式*/
@media screen and (max-width: 767px) and (orientation:landscape){
    .container{
        top:65*@px !important;
        height:auto
    }
    .ui-nologin-copy{
        margin-top:60*@px;
    }
}

/*平板*/
@media screen and (min-device-width : 768px) and (max-device-width : 1024px){
    .container{
        top:20% !important;
    }
}
</style>