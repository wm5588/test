<template lang="html">
    <li class="label-item">
        <el-popover
            ref="popover"
            placement="right-start"
            width="60"
            trigger="click">
            <ul style="text-align:center">
              <li>
                  <el-button size="mini" @click="edit">编辑</el-button>
              </li>
              <hr>
              <li>
                  <el-button size="mini" type="danger" @click="del">删除</el-button>
              </li>
            </ul>
        </el-popover>
        <span class="label-color" :style="{'background-color': '#' + color}"></span>
        <span class="label-text">{{name}}</span>
        <i class="icon-cog label-operation" v-popover:popover></i>
    </li>
</template>

<script>
export default {
    props:{
        color:{
            type:String,
            required:true
        },
        name:{
            type:String,
            required:true
        }
    },
    methods:{
        edit(){
            this.$emit('e-edit')
        },
        del(){
            this.$emit('e-delete')
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

.label-item{
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;

  display:inline-block;
  line-height:36px;
  width:100%;
  cursor:pointer;
  border-left: 3px #fff solid;
  padding-right: 40px;
  box-sizing: border-box;
}

.label-item.active,
.label-item:hover{
  border-left: 3px @color-main solid;
  background-color:@color-list-choose;

  &:hover .label-operation{
      display: inline-block;
  }
}

.label-color{
  display: inline-block;
  vertical-align: middle;
  width: 12px;
  height: 12px;
  margin:0 10px 0 25px;
}

.label-operation{
    position: absolute;
    right: 20px;
    line-height: 36px;
    display: none;
}

.label-operation:active{
    color: @color-add
}

.min-w{
    min-width: 40px;
}

</style>
