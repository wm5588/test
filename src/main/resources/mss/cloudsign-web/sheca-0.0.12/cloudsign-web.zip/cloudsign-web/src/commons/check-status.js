import { MessageBox } from "element-ui"
import store from '@store/index'
import { startPersonAuthProcess } from '@interfaces/openapi/person-authentication.js'
function personAuthFlow(userContact,userName){
    startPersonAuthProcess({
        authModes:[],
        presetPersonAuthentications: [{
            name: userName,
            phone:userContact
        }],
        returnUrl: ''
    }).then(res =>{
        let actionUrl = res.data.data.actionUrl
        location.href = `${actionUrl}`
    }).catch(err=>{
        console.error(err)
    })
}

const state = store.modules.userdata.state
export function checkAuthStatus(router, userIddtvStatus, cb = () => {}){
    const userContact = state.phone || state.email
    let userName = state.userName
    if (userIddtvStatus !== "PASSED"){
        if (userIddtvStatus === "WAITING"){
            MessageBox.alert("您的实名认证信息正在审核中，暂时不能进行该操作，请耐心等待或者联系客服 021-962600", "提示", {
                confirmButtonText: "我知道了",
                callback: action => { cb() },
                type: "warning"
            })
        } else if (userIddtvStatus === "DENY"){
            MessageBox.alert("您的实名认证信息未通过审核，您可重新提交认证信息", "提示", {
                confirmButtonText: "重新认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        personAuthFlow(userContact, userName)
                    } else {
                        cb()
                    }
                },
                type: "warning"
            })
        } else if (userIddtvStatus === "EXPIRED"){
            MessageBox.alert("您的实名认证信息已过期，将影响功能的正常使用，请重新认证", "提示", {
                confirmButtonText: "重新认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        personAuthFlow(userContact, userName)
                    } else {
                        cb()
                    }
                },
                type: "warning"
            })
        } else {
            MessageBox.alert("您尚未进行实名认证，签署的文件不具备法律效力，暂时不能进行该操作，请完成实名认证", "提示", {
                confirmButtonText: "前往认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        personAuthFlow(userContact, userName)
                    } else {
                        cb()
                    }
                },
                type: "warning"
            })
        }
        return false
    }
    return true
}

export {
    personAuthFlow
}