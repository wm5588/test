import axios from "@interfaces/axios.js"
import SparkMD5 from "spark-md5"

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid
 * @method GET
 * @desc   查询指定企业
 * @author 陈曦源
 * @date   2018-03-05 15:30:33
 * ----------------------------------------------------
 */
export function getEneterpriseData(obj) {
    let {
        enterpriseWsid,
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid
 * @method delete
 * @desc   删除指定企业
 * @author 周雪梅
 * @date   2018-06-02 10:38:57
 * ----------------------------------------------------
 */
export function deleteEneterpriseData(obj) {
    let {
        enterpriseWsid,
    } = obj

    return axios.delete(`/api/enterprises/${enterpriseWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/' + enterpriseWsid + '/members/invite
 * @method GET
 * @desc   邀请企业成员。1，邀请的成员是已经注册的用户，添加用户至成员，状态为申请加入；2.添加的成员是未注册的用户，邀请用户加入，并提前添加用户至成员，状态为未注册。
 * @author 周雪梅
 * @date   2018-08-29 20:56:01
 * ----------------------------------------------------
 */
export function membersInvite(obj) {
    let {
        enterpriseWsid,
        name,
        account,
        departmentWsids
    } = obj

    return axios.post("/api/enterprises/" + enterpriseWsid + "/members/invite", {
        name,
        account,
        departmentWsids
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/' + enterpriseWsid + '/members/confirm
 * @method POST
 * @desc   用户确认加入企业
 * @author 周雪梅
 * @date   2018-08-17 10:29:21
 * ----------------------------------------------------
 */
export function membersConfirm(obj) {
    let {
        enterpriseWsid,
        invitationWsid,
        name,
        account,
        type,
        password,
        opcode
    } = obj

    password = SparkMD5.hash(password)
    
    return axios.post("/api/enterprises/" + enterpriseWsid + "/members/confirm", {
        "invitationWsid": invitationWsid,
        name,
        account,
        type,
        password,
        opcode
    })

}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises
 * @method POST
 * @desc   添加新企业
 * @author 周雪梅
 * @date   2017-09-11 9:23:42
 * ----------------------------------------------------
 */
export function createEnterprise(obj) {
    let {
        name,
        authorWsid
    } = obj

    return axios.post("/api/enterprises", {
        name,
        authorWsid
    })

}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members
 * @method GET
 * @desc   查询企业成员列表
 * @author 潘维,陈曦源
 * @date   2018-02-06 17:06:13
 * ----------------------------------------------------
 */
export function getEneterpriseMember(obj) {
    let {
        enterpriseWsid,
        fields,
        filters,
        offset = 0,
        limit = 10,
        sorts
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/members`, {
        params: {
            fields,
            filters,
            offset,
            limit,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/invitations
 * @method GET
 * @desc   查询指定企业的所有成员邀请信息
 * @author 周雪梅
 * @date   2018-08-11 14:26:44
 * ----------------------------------------------------
 */
export function getEneterpriseInvitations(obj) {
    let {
        enterpriseWsid,
        fields,
        filters,
        offset = 0,
        limit = 20,
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/invitations`, {
        params: {
            fields,
            filters,
            offset,
            limit,
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/invitations/:invitationWsid
 * @method DELETE
 * @desc   删除指定企业的邀请成员记录
 * @author 周雪梅
 * @date   2018-08-11 11:54:05
 * ----------------------------------------------------
 */
export function deleteEneterpriseInvitationsInfo(obj) {
    let {
        enterpriseWsid,
        invitationWsid
    } = obj

    return axios.delete(`/api/enterprises/${enterpriseWsid}/invitations/${invitationWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/invitations/:invitationWsid
 * @method POST
 * @desc   对指定链接进行开关
 * @author 周雪梅
 * @date   2018-08-22 14:54:02
 * ----------------------------------------------------
 */
export function invitationsLinkUrlSwitch (obj) {
    let {
        enterpriseWsid,
        invitationWsid,
        status
    } = obj

    return axios.post(`/api/enterprises/${enterpriseWsid}/invitations/${invitationWsid}`, {
        status
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/handle-application
 * @method GET
 * @desc   管理员审核成员
 * @author 周雪梅
 * @date   2018-08-28 09:24:36
 * ----------------------------------------------------
 */
export function eneterpriseHandleApplication(obj) {
    let {
        enterpriseWsid,
        invitationWsid,
        status,
        name
    } = obj

    return axios.post(`/api/enterprises/${enterpriseWsid}/members/handle-application`, {   
        invitationWsid,
        status,
        name
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/handle-bulk-applications
 * @method POST
 * @desc   管理员批量审核成员申请信息
 * @author 周雪梅
 * @date   2018-08-27 19:28:09
 * ----------------------------------------------------
 */
export function eneterpriseHandBulkApplications(obj) {
    let {
        enterpriseWsid,
        requestBody,
        status
    } = obj

    return axios.post(`/api/enterprises/${enterpriseWsid}/members/handle-bulk-applications`, {
        requestBody,
        status
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/${enterpriseWsid}/generate-ur
 * @method GET
 * @desc   查询指定企业的邀请码邀请链接
 * @author 周雪梅
 * @date   2018-02-06 11:31:55
 * ----------------------------------------------------
 */
export function getInvitationLinkUrl (obj) {
    let {
        enterpriseWsid,
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/generate-url`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/${enterpriseWsid}/generate-ur
 * @method POST
 * @desc   生成邀请链接
 * @author 周雪梅
 * @date   2018-08-22 14:54:24
 * ----------------------------------------------------
 */
export function generateInvitationLinkUrl (obj) {
    let {
        enterpriseWsid,
    } = obj

    return axios.post(`/api/enterprises/${enterpriseWsid}/generate-url`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/transfer
 * @method POST
 * @desc   转移企业多个成员到多个部门中
 * @author 周雪梅
 * @date   2018-08-22 14:53:39
 * ----------------------------------------------------
 */
export function transferMembersToDepartments(obj) {
    let {
        enterpriseWsid,
        members,
        existedDepartments
    } = obj
    
    return axios.post(`/api/enterprises/${enterpriseWsid}/members/transfer`, {
        members,
        existedDepartments
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/batch-export
 * @method POST
 * @desc   企业批量导出成员
 * @author 周雪梅 
 * @date   2018-08-22 14:53:39
 * ----------------------------------------------------
 */
export function batchExportMembers(obj) {
    let {
        enterpriseWsid,
        acceptFormat,
        onDownloadProgress
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/members/batch-export?acceptFormat=${acceptFormat}`, {
        responseType: "blob",
        onDownloadProgress
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/batch-import-template
 * @method POST
 * @desc   企业成员模版下载
 * @author 周雪梅 陈曦源
 * @date   2019-11-14 11:11:25
 * ----------------------------------------------------
 */
export function batchImportTemplate(obj) {
    let {
        enterpriseWsid
    } = obj

    window.open(`/api/enterprises/${enterpriseWsid}/members/batch-import-template?filename=批量数据模板.xls`)

    return Promise.resolve()
}



/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members
 * @method PATCH
 * @desc   批量更新成员信息
 * @author 周雪梅
 * @date   2018-08-22 14:53:39
 * ----------------------------------------------------
 */
export function batchUpdateMemberInfo(obj) {
    let {
        enterpriseWsid,
        membersInfo
    } = obj
    
    return axios.patch(`/api/enterprises/${enterpriseWsid}/members`, membersInfo)
}

/**
 * ----------------------------------------------------
 * @method  GET
 * @path    /api/enterprises/:enterpriseWsid/groups
 * @desc    查询企业的分组信息
 * @date    2019-03-13 21:40:23
 * @author  周雪梅
 * ----------------------------------------------------
 */
export function getEnterpriseGroups(obj) {
    let {
        enterpriseWsid,
        groupWsid,
        filterEnteRoleWsids,
        fields,	
        filters,	
        sorts,	
        type,	
        current,
        scopes,
        keyword
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/groups`, {
        params: {
            groupWsid,
            filterEnteRoleWsids,
            fields,	
            filters,	
            sorts,	
            type,	
            current,
            scopes,
            keyword
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/${enterpriseWsid}/generate-ur
 * @method POST
 * @desc   生成邀请链接
 * @author 周雪梅
 * @date   2018-08-22 14:54:24
 * ----------------------------------------------------
 */
export function enterpriseHandover (obj) {
    let {
        enterpriseWsid,
        srcEuserWsid,
        dstEuserWsid
    } = obj

    return axios.post(`/api/enterprises/${enterpriseWsid}/handover`, {
        srcEuserWsid,
        dstEuserWsid
    })
}