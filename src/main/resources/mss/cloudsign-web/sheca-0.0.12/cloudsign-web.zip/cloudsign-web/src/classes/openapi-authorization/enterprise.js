//认证方式
const AUTH_METHODS = {
    LEGAL_PERSON_AUTH: "LEGAL_PERSON_AUTH",　//企业认证
    AGENT_PERSON_AUTH: "AGENT_PERSON_AUTH",　//授权委托书认证
}

const AUTH_METHOD_INFOS = {
    LEGAL_PERSON_AUTH: {
        title: "法定代表人认证", 
        description: "由法人提交企业工商信息，法人人脸识别认证，全程自动识别校验，认证审核零等待", 
        icon:"icon-legal",
        recommend: "由法人提交企业工商信息，法人人脸识别认证，全程自动识别校验，认证审核零等待",
    },
    AGENT_PERSON_AUTH: {
        title: "授权书认证", 
        description: "申请人完成个人实名认证，上传加盖公章授权书提交后等待系统审核，审核时长2~3天", 
        icon:"icon-authorization",
        recommend: "适用于可提交营业执照的企业，组织，个体工商户等需企业公章，上传认证授权书，系统审核",
    },
}

//认证状态
const AUTH_STATUS = {
    INCOMPLETE: "INCOMPLETE",　//未完善，待用户提交认证资料
    PRIMARY_PASSED: "PRIMARY_PASSED", //初级认证通过
    WAITING: "WAITING",　//认证通过
    PRIMARY_DENY: "PRIMARY_DENY",　//认证不通过
    EXPIRED: "EXPIRED",　//认证超时
    POWER_OF_ATTORNEY_REVISING:"POWER_OF_ATTORNEY_REVISING",//授权书待修改状态
    WAITING_SUM: "WAITING_SUM", //等待打款
    WAITING_SUM_CHECK: "WAITING_SUM_CHECK", //已打款(等待用户汇款信息确认)
    SENIOR_PASSED: "SENIOR_PASSED", //高级认证通过(用户汇款信息确认成功)
    SENIOR_DENY: "SENIOR_DENY", //高级认证未通过（打款失败/汇款验证失败)
}


const PERSON_AUTH_METHODS = {
    PHONE_AUTH: "PHONE_AUTH",　//手机三网认证
    BANK_AUTH: "BANK_AUTH",　//银行卡认证
    FACE_AUTH: "FACE_AUTH", //人身核验
    ZM_AUTH:"ZM_AUTH",
    PHONE_FACE_AUTH:"PHONE_FACE_AUTH",
    MANUAL: "MANUAL",　//人工审核
}

const PERSON_AUTH_METHOD_INFOS = {
    PHONE_AUTH: {
        title: "手机认证", 
        description: "", 
        recommend: "适用于手机号已经在中国移动、电信或联通营业厅实名认证的用户", 
    },
    BANK_AUTH: {
        title: "银行卡四要素认证", 
        description: "", 
        recommend: "适用于持有中国银行卡的用户",
    },
    FACE_AUTH: {
        title: "人脸核验", 
        description: "采用人脸识别技术，需要读出指定数字", 
        recommend: "适用于所有具有大陆身份证的用户",
    },
    ZM_AUTH:{
        title: "支付宝认证", 
        description: "采用阿里云人脸识别技术", 
        recommend: "适用于移动端装有支付宝APP的用户",
    },
    PHONE_FACE_AUTH:{
        title: "手机人脸双重认证", 
        description: "采用人脸识别技术，需要读出指定数字", 
        recommend: "适用于手机号已经在中国移动、电信或联通营业厅实名认证的用户",
    },
    MANUAL: {
        title: "人工审核", 
        description: "上传身份证(或护照等有效证件)正反面照以及本人手持证件照，审核时间较长", 
        recommend: "适用于不能使用其他方式的用户",
    }
}

//认证状态
const PERSON_AUTH_STATUS = {
    INCOMPLETE: "INCOMPLETE",　//未完善，待用户提交认证资料
    WAITING: "WAITING", //认证未通过
    PASSED: "PASSED",　//认证通过
    DENY: "DENY",　//认证不通过
    EXPIRED: "EXPIRED",　//认证超时
}


export {
    AUTH_METHODS,
    AUTH_METHOD_INFOS,
    AUTH_STATUS,
    PERSON_AUTH_METHODS,
    PERSON_AUTH_METHOD_INFOS,
    PERSON_AUTH_STATUS,
}