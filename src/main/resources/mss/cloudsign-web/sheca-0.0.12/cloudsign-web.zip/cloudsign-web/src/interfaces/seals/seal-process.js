import axios from "../axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/seals/public/json-upload-process
 * @method POST
 * @desc   更改印章名称
 * @author 陈曦源
 * @date   2019-03-13 09:28:13
 * ----------------------------------------------------
 */
export function sealJsonUploadProcess(obj) {
    let {
        name = "1",
        base64data,
        autoBackgroundLucency = true,
        autoEdgeCutting = false
    } = obj

    return axios.post("/api/seals/public/json-upload-process", {
        name,
        base64data,
        autoBackgroundLucency,
        autoEdgeCutting
    })
}