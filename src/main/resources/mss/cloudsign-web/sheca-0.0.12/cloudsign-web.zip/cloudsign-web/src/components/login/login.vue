<!--
    @id     sys-login
    @desc   登录组件
            登陆后会将登陆信息注册到LocalStorage中
    @level  system:系统组件
    @events
        loginsuccess    登录成功
    @auther 陈曦源
    @date   2019-07-01 14:52:57
-->
<template lang="html">
    <div>
        <div v-if="activeType === 'PASSWORD'">
            <passwordLogin :account.sync="account" :rememberAccount.sync="rememberAccount" 
                @login-success="loginSuccess" @change-type="changeType"></passwordLogin>
        </div>
        <div v-if="activeType === 'SMS'">
            <smsVerificationCodeLogin :account.sync="account" :rememberAccount.sync="rememberAccount"
                @login-success="loginSuccess" @change-type="changeType"></smsVerificationCodeLogin>
        </div>
    </div>
</template>

<script>
import passwordLogin from "./password-login.vue"
import smsVerificationCodeLogin from "./sms-verification-code-login.vue"
import { checkUserLoginStatusAndAutoChange } from "@commons/login-check.js"
import objectStorage from "@utils/storage.js"
import { getSessionData } from "@interfaces/user/sessions.js"
import { getUserAccounts, getUserData, changeSession } from "@interfaces/user/user.js"

const LOGIN_TYPE_STORAGE_KEY = "LOGIN_TYPE_STORAGE"
const REMEMBER_ACCOUNT_STORAGE_KEY = "REMEMBER_ACCOUNT_STORAGE"
const ACCOUNT_STORAGE_KEY = "ACCOUNT_STORAGE"

export default {
    props: {
        targetURL: {
            type: String,
            default: "/wesign"
        },
        targetUserWsid: {
            type: String,
            required: false
        },
        targetUserContact: {
            type: String,
            required: false
        },
        targetUserEnterpriseName: {
            type: String,
            required: false
        },
        targetUserSessionScopes: {
            type: Array,
            required: false
        }
    },
    data(){
        let storagedLoginType = objectStorage.getItem(LOGIN_TYPE_STORAGE_KEY)
        if (storagedLoginType !== "PASSWORD" && storagedLoginType !== "SMS"){
            storagedLoginType = "PASSWORD"
        }

        let storedRememberAccount = objectStorage.getItem(REMEMBER_ACCOUNT_STORAGE_KEY) || false
        let storedAccount = objectStorage.getItem(ACCOUNT_STORAGE_KEY) || ""

        return {
            account: storedAccount, //账户
            activeType: storagedLoginType, //PASSWORD 账密登录 SMS 短信验证码登录
            rememberAccount: storedRememberAccount, //记住帐号
        }
    },
    watch: {
        activeType(nv){
            objectStorage.setItem(LOGIN_TYPE_STORAGE_KEY, nv)
        },
        rememberAccount(nv){
            objectStorage.setItem(REMEMBER_ACCOUNT_STORAGE_KEY, nv)
        }
    },
    created(){
        this.logining = true
        this.checkUserLoginStatusAndAutoChange().then(_ => {
            this.loginSuccess()
        }).catch(_ => {}).then(_ => {
            this.logining = false
        })
    },
    methods: {
        changeType(type){
            this.activeType = type
        },
        loginSuccess(){
            this.storeAccount()
            location.href = this.targetURL
        },
        storeAccount(){
            if (this.rememberAccount){
                objectStorage.setItem(ACCOUNT_STORAGE_KEY, this.account)
            } else {
                objectStorage.setItem(ACCOUNT_STORAGE_KEY, "")
            }
        },
        async checkUserLoginStatusAndAutoChange(){
            //判断是否匹配，可以自动登录过去
            let ifMatch = false
            let targetURL = this.targetURL
            let targetUserWsid = this.targetUserWsid
            let targetUserContact = this.targetUserContact
            let targetUserEnterpriseName = this.targetUserEnterpriseName
            let targetUserSessionScopes = this.targetUserSessionScopes

            try {
                //检查是否登录
                let session = await getSessionData().then(res => res.data.data.session)
                let currentUserWsid = session.userWsid
                
                //对权限进行判断
                if (targetUserSessionScopes){
                    //含有sessionScopes表示只具有某些权限，如果为空表示具有全部权限
                    if (session.sessionScopes){
                        if (!targetUserSessionScopes.every(scope => session.sessionScopes.indexOf(scope) >= 0)){
                            //缺少权限
                            throw new Error("ERROR_LACK_OF_AUTHORITY")
                        }
                        
                        //免登陆不能切换账户
                        ifCanChange = false
                    }
                } else {
                    //默认要求全部权限,即sessionScopes为空
                    if (session.sessionScopes && session.sessionScopes.length > 0){
                        throw new Error("ERROR_LACK_OF_AUTHORITY")
                    }
                }

                let accounts = await getUserAccounts({
                    userWsid: currentUserWsid,
                    limit: 10000
                }).then(res => {
                    return res.data.data.accounts
                })

                //如果没有指定ID就通过联系方式+企业名称进行判断
                if (!targetUserWsid && targetUserContact){
                    let userData = await getUserData({
                        userWsid: currentUserWsid,
                    }).then(res => res.data.data.userInfo.user)

                    //判断是否为对应的目标
                    if (userData.email === targetUserContact || userData.phone === targetUserContact){
                        if (targetUserEnterpriseName){
                            let enterprise = accounts.find(account => account.enterpriseName === targetUserEnterpriseName)
                            targetUserWsid = enterprise.userWsid
                        } else {
                            let person = accounts.find(account => account.userType === "PERSON")
                            targetUserWsid = person.userWsid
                        }
                    }
                }

                //如果有目标id则切换过去
                if (targetUserWsid && targetUserWsid !== currentUserWsid){
                    //不相等检查账户是否包含
                    if (accounts.some(account => account.userWsid === targetUserWsid)){
                        //账户包含，进行账户切换
                        await changeSession({
                            userWsid: currentUserWsid, 
                            destinationWsid: targetUserWsid
                        })
                        ifMatch = true
                    }
                } else {
                    ifMatch = true
                }
            } catch (e) {
                console.error(e)
                //未登录
            }
            
            if (ifMatch){
                return true
            } else {
                throw new Error("TARGET_USER_NOT_LOGIN")
            }
        }
    },
    components: {
        passwordLogin,
        smsVerificationCodeLogin
    },
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.verify-img{
    cursor: pointer;
    box-sizing: border-box;
    line-height: 42px;
    height: 42px;
    min-width: 42px;
    float:right;
    border: 1px solid black;
}

.info{
    width: 80%;
    margin:0 auto;
    text-align: left;
}

.forgetPwd{
    float:right;
    display:inline-block;
    vertical-align:middle;
}
.view{
    font-size:@font-size-primary;
    display:inline-block;
    cursor:pointer
}
.eye{
    color:@color-main;
}
.detail-box{
    display:flex;
    justify-content: space-between;
}
.placeholder{
    height:20px;
}
.right{
    text-align:right
}
.email,.phone{
    margin-right:3px;
}
</style>