import "./common.js"
import "@styles/common.less"
import Vue from "vue"
import inviteRegister from "@page-components/externals/invite-register.vue"

//element-ui 引入
import {
    Row,
    Col,
    Message,
    Input,
    Button,
    Checkbox,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Checkbox)
Vue.prototype.$message = Message

new Vue({
    el: "#app",
    template: "<inviteRegister />",
    components: {
        inviteRegister
    }
})