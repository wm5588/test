import { cookiesInterface } from "@classes/local-storage-interface.js"
const ENTERPRISEINFOLOCALSTATUS_LOCALSTORAGE_KEY = "wesign-enterprise-info-status"

class EnterpriseInfoLocalStatus extends cookiesInterface {
    constructor(){
        super(ENTERPRISEINFOLOCALSTATUS_LOCALSTORAGE_KEY)
        
        this.isEnterpriseInfo= false
        this.isPowerOfAttorneyAuth = false
        this.isEnterpriseInfoPowerOfAttorney = false
        this.isModifyPowerOfAttorneyAuth = false
        this.isUpdatePowerOfAttorneyAuth = false
        this.loadFromLocal()
    }

    setIsEnterpriseInfo(nv){
        this.isEnterpriseInfo = nv
        this.saveToLocal()
    }
    setIsEnterpriseInfoPowerOfAttorney(nv){
        this.isEnterpriseInfoPowerOfAttorney = nv
        this.saveToLocal()
    }
    
    setIsPowerOfAttorneyAuth(nv){
        this.isPowerOfAttorneyAuth = nv
        this.saveToLocal() 
    }

    setIsUpdatePowerOfAttorneyAuth(nv){
        this.isUpdatePowerOfAttorneyAuth = nv
        this.saveToLocal() 
    }

    setIsModifyPowerOfAttorneyAuth(nv){
        this.isModifyPowerOfAttorneyAuth = nv
        this.saveToLocal()
    }
}

export { EnterpriseInfoLocalStatus }

