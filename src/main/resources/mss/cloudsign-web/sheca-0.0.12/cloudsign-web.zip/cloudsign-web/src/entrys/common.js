import "core-js"
import regeneratorRuntime from "regenerator-runtime/runtime"
window.regeneratorRuntime = regeneratorRuntime

if(/MQQBrowser\/[1-8]\./i.test(navigator.userAgent)
    && /HUAWEI/i.test(navigator.userAgent)){
    document.body.style.position = "absolute"
    document.body.style.top = "0"
    document.body.style.left = "0"
    document.body.style.right = "0"
    document.body.style.bottom = "95px"
    document.body.style.transform = "translate3D(0,0,0)"
}