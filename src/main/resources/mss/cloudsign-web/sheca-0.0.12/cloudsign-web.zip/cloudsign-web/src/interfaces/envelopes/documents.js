import axios from "@interfaces/axios.js"
const FILE_MAX_SIZE = 1024 * 1024 * 2
import uuid from "uuid"

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/documents
 * @method GET
 * @desc   获取信封文档列表
 * @author 陈曦源
 * @date   2018-01-15 21:18:55
 * ----------------------------------------------------
 */
export function getEnvelopeDocuments(obj = {}) {
    let {
        envelopeWsid
    } = obj

    return axios.get(`/api/envelopes/${envelopeWsid}/documents`).then(data => {
        let documents = data.data.data.documents
        if (documents.every(_ => _.sequence)){
            documents.sort((a, b) => a.sequence - b.sequence)
        }
        return data
    })
}

/**
 * ----------------------------------------------------
 * @path   /files/fragment-upload
 * @method POST
 * @desc   上传文档
 * @author 周雪梅
 * @date   2020-09-15 21:36:35
 * ----------------------------------------------------
 */
export function uploadEnvelopeDocument(obj = {}) {
    let {
        envelopeWsid,
        authorWsid,
        file,
        fileName = "",
        isAttached = false,
        fileOwnerPassin,
        fileTagId = null,
        sequence,
        fileType
    } = obj
    //削减文件名
    let filenames = fileName.split(".")
    //后缀
    let dx = filenames.pop()
    filenames = filenames.join(".").substr(0, 40)
    fileName = `${filenames}.${dx}`
    let taskId = uuid.v4()
    let total = Math.ceil(file.size/FILE_MAX_SIZE)
    let arr = []
    let flag = 0
    let maxSum = 3
    let remainArray = [] //剩余
    let startArray = [] //初始
    let errorArray = [] // 失败
    return new Promise((resolve, reject) =>　{
        for(let i=1;i<=total;i++){
            let fileItem =file.slice((i-1)*FILE_MAX_SIZE, (i-1+1)*FILE_MAX_SIZE)
            arr.push({
                file: fileItem,
                size: fileItem.size,
                flag:i,
            })
        }

        startArray = new Set(arr.slice(0, 3))
        remainArray=new Set(arr.slice(3, arr.length))
        if(total<maxSum){
            for(let i=0;i<arr.length;i++){
                sendFile(arr[i])
            }
        } else {
            for(let i=0;i<maxSum;i++){
                sendFile(arr[i])
            }
        }
        
        
        function sendFile(sum){
            let formdata = new FormData()
            formdata.append("file", sum.file)
            formdata.append("fileName", fileName)
            formdata.append("taskId", taskId)
            formdata.append("fileType", dx)
            formdata.append("chunk", sum.flag)
            formdata.append("size", sum.size)
            formdata.append("totalSize", file.size)
            formdata.append("chunkTotal", total)
            // formdata.append("storageUsageType", "ENVELOPE")
            formdata.append("from", "LOCAL")
            uploadFragment(formdata).then(res =>{
                if(res.data.totalUploadComplete ===true){
                    let data = res.data
                    let wsidList =[{
                        fileWsid: data.fileWsid
                    }]
                    uploadEnvelopeDocumentWsid({
                        envelopeWsid:envelopeWsid,
                        wsidList
                    }).then(res =>{
                        resolve(res)
                    }).catch(err =>{
                        reject(err)
                    })
                } else {
                    startArray.delete(sum);
                    if(remainArray.size>0){
                        let item = Array.from(new Set(remainArray))
                        sendRemain(item[0])
                    }
                }
            }).catch(err =>{
                console.log(err)
                if(errorArray.length>0){
                    if(arr.forEach(e => errorArray.indexOf(e)===-1)){
                        errorArray.push({
                            file: sum.file,
                            size: sum.size,
                            flag:sum.flag,
                            count:0
                        })
                    }
                } else {
                    errorArray.push({
                        file: sum.file,
                        size: sum.size,
                        flag:sum.flag,
                        count:0
                    })
                }
                
                
                errorArray.forEach(item => {
                    if(item.flag === sum.flag){
                        item.count ++
                    }
                })
                
                if (errorArray.every(item =>item.count>= maxSum)) {
                    return reject('上传文件失败');
                } else {
                    startArray.delete(sum)
                    remainArray.add(sum)
                    sendFile(sum)
                }
            })
        }

        function sendRemain(sum){
            remainArray.delete(sum)
            startArray.add(sum)
            sendFile(sum)
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /files/fragment-upload
 * @method POST
 * @desc   分片上传
 * @author 周雪梅
 * @date   2020-08-15 18:41:44
 * ----------------------------------------------------
 */
export function uploadFragment(formdata){
    return axios.post(`/files/fragment-upload`,formdata,{
        params:{
            storageUsage:"ENVELOPE"
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/documents/:documentWsid
 * @method DELETE
 * @desc   删除指定信封
 * @author 陈曦源
 * @date   2018-01-16 11:51:19
 * ----------------------------------------------------
 */
export function deleteEnvelopeDocument(obj = {}){
    let {
        envelopeWsid,
        documentWsid
    } = obj

    return axios.delete(`/api/envelopes/${envelopeWsid}/documents/${documentWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/contents/wsid-upload
 * @method POST
 * @desc   上传文档（wsid方式）
 * @author 潘维
 * @date   2018-12-02 16:50:28
 * ----------------------------------------------------
 */
export function uploadEnvelopeDocumentWsid(obj = {}) {
    let {
        envelopeWsid,
        wsidList,
    } = obj
    return axios.post(`/api/envelopes/${envelopeWsid}/contents/wsid-upload`, wsidList)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/documents
 * @method put
 * @desc   批量更新信封文件
 * @author 潘维
 * @date   2019-05-15 15:49:43
 * ----------------------------------------------------
 */
export function updateEnvelopeDocuments(obj = {}) {
    let {
        envelopeWsid,
        contents
    } = obj
    
    return axios.put(`/api/envelopes/${envelopeWsid}/documents`, { contents })
}