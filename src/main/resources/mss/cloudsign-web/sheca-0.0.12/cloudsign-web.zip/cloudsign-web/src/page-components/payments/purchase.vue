<template>
    <div>
        <div class="purchase-container">
            <div class="rcontainer-cont-select">
            <div class="all" @click='dateClick(0)'>{{allValue}}</div>
            <div class="month" @click.stop='dateClick(1)'>
                <span class="month-value">{{monthValue}}月</span>
                <span class="carat"></span>
                <div class="month-options" v-show='monthShow'>
                    <ul>
                        <li v-for='m in maxMonth' @click.stop='monthOptionClick(maxMonth-m+1)'>{{maxMonth-m+1}}月</li>							
                    </ul>
                </div>
            </div>
            <div class="year" @click.stop='dateClick(2)'>
                <span class="year-value">{{yearValue}}年</span>
                <span class="carat"></span>
                <div class="year-options" v-show='yearShow'>
                    <ul>
                        <li @click.stop='yearOptionClick(2017)'>2017年</li>
                        <li @click.stop='yearOptionClick(2016)'>2016年</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="rcontainer-cont-records">
            <p class="p-title">交易总览</p>
            <table class="records-table">
                <thead>
                    <tr class="records-htr">
                        <td class="records-htd td-per5">类型</td>
                        <td class="records-htd td-per5">总额(份)</td>
                    </tr>
                </thead>
                <tbody id="records-tot">
                    <tr class="records-btr" v-if='costs < 0'>
                        <td colspan="2" class="records-btd">暂无记录</td>
                    </tr>
                    <tr class="records-btr" v-else>
                        <td class="records-btd">套餐支付</td>
                        <td class="records-btd">{{costs}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="rcontainer-cont-records">
            <p class="p-title">交易明细</p>
            <table class="records-table">
                <thead>
                    <tr class="records-htr">
                        <td class="records-htd td-per2">订单号</td>
                        <td class="records-htd td-per1">名称</td>
                        <td class="records-htd td-per1">单价</td>
                        <td class="records-htd td-per1">数量(套)</td>
                        <td class="records-htd td-per1">实付款(元)</td>
                        <td class="records-htd td-per1">交易时间</td>
                        <td class="records-htd td-per1">状态</td>
                        <td class="records-htd td-per1">操作</td>
                        <td class="records-htd td-per1">备注</td>
                    </tr>
                </thead>
                <tbody id="records-tot" v-if='total === 0'>
                    <tr class="records-btr">
                        <td colspan="9" class="records-btd">暂无记录</td>
                    </tr>
                </tbody>
                <tbody id="records-tot" v-else>
                    <tr class="records-btr" v-for='p in pays'>
                        <td class="records-btd">{{p.orderId}}</td>
                        <td class="records-btd">{{p.sysComboName}}</td>
                        <td class="records-btd">{{p.perCost}}</td>
                        <td class="records-btd">{{p.period}}</td>
                        <td class="records-btd">{{p.cost}}</td>
                        <td class="records-btd">{{getDate(p.builtDate,'yyyy-MM-dd hh:mm')}}</td>
                        <td class="records-btd state">{{p.payType==='signit'?'赠送成功':'交易成功'}}</td>
                        <td class="records-btd" v-if='p.payType==="signit"'></td>
                        <td class="records-btd re-pay" v-else>
                            <a :href='"#"+p.sysComboId'>再次购买</a>
                        </td>
                        <td class="records-btd">{{getPayType(p.payType)}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        </div>
        
        <div class='pagination'>
            <pagination :nowPage='nowPage' :maxPage='maxPage'></pagination>
        </div>
    </div>
</template>

<script>
    import pagination from '@components/commons/pagination.vue'
    import {get_bill_pay} from '@interfaces/payments/payments.js'
    export default{
        data:function(){
            return {
                nowPage:1,
                maxPage:1,
                pays:[],
                total:0,
                costs:0,
                monthShow:false,
                yearShow:false,
                yearValue: 0,
                monthValue: 0,
                maxMonth:12,
                nowYear:0,
                nowMonth:0,
                allValue:'查看全部'
            }
        },
        components:{
            pagination
        },
        created:function(){
            let date = new Date();
            this.yearValue = date.getFullYear();
            this.nowYear = this.yearValue;
            this.monthValue = date.getMonth() + 1;
            this.maxMonth = this.monthValue;
            this.nowMonth = this.monthValue;
            this.getPays({year:this.yearValue,month:this.monthValue});
        },
        methods:{
            getPays:function(obj){
                let date = {};
                if(obj.year && obj.month){
                    date = this.getQueryDate(obj.year,obj.month);
                }
                get_bill_pay({
                    page:obj.page,
                    fromDate:date.fromDate,
                    toDate:date.toDate
                }).then(data => {
                    this.pays = data.pays;
                    this.nowPage = data.nowPage;
                    this.maxPage = data.totalPage;
                    this.costs = data.costs;
                    this.total = data.total;
                }).catch(err => {
                    console.log(err);
                })
            },
            getDate:function(date,str){
                return FORMATDATE(date,str);
            },
            getPayType:function(type){
                if(type === 'signit')
                    return '系统赠送';
                if(type === 'wxpay')
                    return '微信支付';
                if(type === 'alipay')
                    return '支付宝支付';
                return '无';
            },
            dateClick: function (flag) {
                let me = this;
                if (flag === 0) {
                    if(this.allValue === '查看全部'){
                        this.allValue = '返回搜索';
                        this.getPays({});
                    }
                    else{
                        this.getPays({year:this.yearValue,month:this.monthValue});
                        this.allValue = '查看全部';
                    }
                }
                else if (flag === 1) {
                    this.monthShow = !this.monthShow;
                    if(this.monthShow){
                        function monthDown(){
                            me.monthShow = false;
                            window.removeEventListener('click',monthDown)
                        }
                        window.addEventListener('click',monthDown);
                    }
                    
                }
                else if (flag === 2) {
                    this.yearShow = !this.yearShow;
                    if(this.yearShow){
                        function yearDown(){
                            me.yearShow = false;
                            window.removeEventListener('click',yearDown)
                        }
                    window.addEventListener('click',yearDown);
                    }
                    
                }
            },
            monthOptionClick: function (m) {
                this.monthValue = m;
                this.getPays({year:this.yearValue,month:this.monthValue});
                this.monthShow = false;
            },
            yearOptionClick:function(y){
                this.yearValue = y;
                if(y < this.nowYear){
                    this.maxMonth = 12;
                }
                else{
                    this.maxMonth = this.nowMonth;
                    this.monthValue = this.monthValue > this.nowMonth ? this.nowMonth : this.monthValue;
                }
                this.getPays({year:this.yearValue,month:this.monthValue});
                this.yearShow = false;
            },
            getBills:function(obj){
                let date = {};
                if(obj.year && obj.month){
                    date = this.getQueryDate(obj.year,obj.month);
                }
                get_bill_sign({
                    page:obj.page,
                    fromDate:date.fromDate,
                    toDate:date.toDate
                }).then(data => {
                    this.bills = data.bills;
                    this.nowPage = data.nowPage;
                    this.maxPage = data.totalPage;
                    this.total = data.total;
                }).catch(err => {
                    console.log(err);
                })
            },
            changePage:function(x){
                if(typeof x === 'number'){
                    this.nowPage = x;
                }
                else if(x === '上一页'){
                    this.nowPage-- ;
                }else{
                    this.nowPage++ ;
                }
                getPays({
                    page:this.nowPage,
                    year:this.yearValue,
                    month:this.monthValue
                });
            },
            getQueryDate:function(year,month){
                let monthArr = [31,28,31,30,31,30,31,31,30,31,30,31];
                if(year % 400 === 0 || (year % 4 === 0 && year % 100 !== 0)){
                    monthArr[1] = 29;
                }
                if(month > 9){
                    return {
                        fromDate: year + '-' + month + '-01' + ' 00:00:00',
                        toDate: year + '-' + month + '-' + monthArr[month - 1] + ' 23:59:59'
                    }
                }
                else{
                    return{
                        fromDate: year + '-0' + month + '-01' + ' 00:00:00',
                        toDate: year + '-0' + month + '-' + monthArr[month - 1] + ' 23:59:59'
                    }
                     
                }
            }
        }
    }
</script>

<style lang="less" scoped>
    @import '../../styles/user/payments.less';
    .pagination{
        position:absolute;
        left:0;
        line-height:50px;
        right:0;
        text-align:center;
        bottom:0;
    }
    .purchase-container{
        position:absolute;
        left:0;
        top:0;
        bottom:40px;
        right:0;
        overflow-y:auto;
    }
    .records-btr{
        .state{
            color:#3c9;
        }
        .re-pay a{
            color:#66a3ff;
        }
    }
</style>