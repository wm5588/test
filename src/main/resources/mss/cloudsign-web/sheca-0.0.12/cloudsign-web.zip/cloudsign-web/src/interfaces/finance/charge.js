import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @method  GET
 * @path    /api/finance/charge
 * @desc    查询用户余额
 * @date    2018-04-14 15:56:15
 * @author  陈曦源
 * ----------------------------------------------------
 */
export function getCharge(obj) {
    let {
        filters
    } = obj
    
    return axios.get("/api/finance/charge", {
        params: {
            filters
        }
    })
}

/**
 * ----------------------------------------------------
 * @method  GET
 * @path    /api/finance/charge/available-count
 * @desc    查询用户余额
 * @date    2018-04-24 17:18:46
 * @author  潘维
 * ----------------------------------------------------
 */
export function getChargeCount(obj) {
    let {
        authorWsid
    } = obj
    
    return axios.get("/api/finance/charge/available-count", {
        params: {
            authorWsid
        }
    })
}