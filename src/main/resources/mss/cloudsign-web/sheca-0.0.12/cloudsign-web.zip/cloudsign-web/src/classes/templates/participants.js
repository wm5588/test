class processParticipants {
    constructor() {
        this.id = parseInt(Math.random() * 100000000) //参与者/组ID
        this.name = "", //参与者/组名称
        this.type = "PARTICIPANT" //PARTICIPANT 参与者 GROUP 组
        this.config = "" //参与者/组配置
        this.participants = new Array() //流程参与者ID数组  流程参与者组才需要
    }
}

class processGroupConfigs {
    constructor() {
        this.id = parseInt(Math.random() * 100000000) //组配置ID
        this.name = "" //组配置名称
        this.orderSign = true //默认是否为有序签名
        this.orderSignChangeable = false //是否可以改变信封签名顺序属性
        this.participantsPositionChangeable = false //是否可以改变参与方的顺序
        this.addibleParticipants = new Array() //可添加的参与者配置ID列表
        this.addibleGroups = new Array() //可添加的组配置ID列表
    }
}

class participantConfigs {
    constructor() {
        this.id = parseInt(Math.random() * 100000000) //参与者配置的ID
        this.name = "" //参与者配置名称
        this.type = "ENTERPRISE_MEMBER" //参与者类型 PERSON ENTERPRISE_MEMBER ENTERPRISE_ROLE
        this.optionalParticipantInfos = new Array() //可选参与者配置信息
        this.customizable = true //是否可自定义参与者信息
        this.defaultActionId = "" //默认的行为ID
        this.roleChangeable = "" //是否可以改变行为
        this.optionalActions = new Array() //可选行为Id列表
    }
}

class participantInfoObject {
    constructor() {
        this.id = parseInt(Math.random() * 100000000) //参与者信息配置ID
        this.enterpriseName = "" //企业名称
        this.name = "" //用户姓名
        this.contact = "" // 用户联系方式
    }
}

class actionConfigs {
    constructor() {
        this.id = parseInt(Math.random() * 100000000) //行为ID
        this.name = "签署" //行为名称
        this.envelopeAction = "SIGNER" //SIGNER  签名操作 CHECKER    审核人
        this.infosFormId = "" //需要填写的表单信息ID
    }
    set(name, envelopeAction) {
        this.name = name
        this.envelopeAction = envelopeAction
    }
}

function createProgressParticipants(type) {
    let newProcessParticipants = new processParticipants()
    let newProcessConfigs = null
    switch (type) {
        case "GROUP":
            {
                let newProcessGroupConfigs = new processGroupConfigs()
                newProcessConfigs = newProcessGroupConfigs
                newProcessParticipants.config = newProcessGroupConfigs.id
            }
            break
        case "PARTICIPANT":
        {
            let newProcessParticipantConfig = new participantConfigs()
            newProcessConfigs = newProcessParticipantConfig
            newProcessParticipants.config = newProcessParticipantConfig.id
        }
    }

    newProcessParticipants.type = type
    return {newProcessParticipants, newProcessConfigs}
}

function createActions() {
    let actions = []
    let actionSigner = new actionConfigs()
    actions.push(actionSigner)
    let actionChecker = new actionConfigs()
    actionChecker.set("审核", "CHECKER")
    actions.push(actionChecker)
    // let actionNull = new actionConfigs()
    // actionNull.set("无操作", "NULL")
    // actions.push(actionNull)
    return actions
}
export default {
    processParticipants,
    processGroupConfigs,
    participantConfigs,
    participantInfoObject,
    actionConfigs,
    createProgressParticipants,
    createActions
}

export {
    processParticipants,
    processGroupConfigs,
    participantConfigs,
    participantInfoObject,
    actionConfigs,
    createProgressParticipants,
    createActions
}