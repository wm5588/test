// import { getCharge } from "@interfaces/finance/charge.js"
import { getChargeCount } from "@interfaces/finance/charge.js"

function initData(){
    return {
        totalCharges: 0,
        currentCharges: 0,
        expriseDate: new Date(0)
    }
}

const module_userData = {
    state: initData(),
    getters: {
        totalCharges(state){
            return state.totalCharges
        }
    },
    actions: {
        updateUserCharge({ state, dispatch, getters, commit }){
            let authorWsid = ""
            if (getters.userEdition === "p"){
                authorWsid = getters.puserWsid
            } else {
                authorWsid = getters.enterpriseWsid
            }
            return getChargeCount({
                authorWsid
            }).then(res => {
                let allCharges = res.data.data
                if (allCharges.count){
                    state.totalCharges = allCharges.count || 0
                } else {
                    state.totalCharges = 0
                }
            })
            // return getCharge({
               
            // }).then(res => {
            //     let allCharges = res.data.data.allCharges.find(_ => _.productionWsid === "WSID_PROD_000001626a6ee38c1831bf4e50310001")
            //     if (allCharges){
            //         state.totalCharges = allCharges.sum || 0
            //     } else {
            //         state.totalCharges = 0
            //     }

            //     let currentCharges = res.data.data.currentCharges.find(_ => _.productionWsid === "WSID_PROD_000001626a6ee38c1831bf4e50310001")
            //     if (currentCharges){
            //         state.currentCharges = currentCharges.currentRemain || 0
            //         state.expriseDate = new Date(currentCharges.currentExpiredDatetime)
            //     } else {
            //         state.currentCharges = 0
            //         state.expriseDate = new Date(0)
            //     }
            // })
        }
    }
}

export default module_userData
