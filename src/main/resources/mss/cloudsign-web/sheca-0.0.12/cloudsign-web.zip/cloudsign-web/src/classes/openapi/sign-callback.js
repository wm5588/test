const ACTIONS = {
    SIGNED: "SIGNED", //签署成功
    REJECTED: "REJECTED", //拒绝签署
    PASSED: "PASSED", //审核成功
    NOT_PASSED: "NOT_PASSED", //审核不通过
    CANCEL: "CANCEL", //取消签署
    REVOKED: "REVOKED", //撤销签署
    TRANSFERED: "TRANSFERED", //转签成功
}

function gotoOpenSignatureReturnURL(returnURL, action, options){
    let {
        envelopeWsid,
        participantWsid
    } = options
    
    let url = new URL(returnURL)
    url.searchParams.append("envelopeWsid", envelopeWsid)
    url.searchParams.append("participantWsid", participantWsid)
    url.searchParams.append("action", action)
    location.href = url.toString()
}

export {
    ACTIONS,
    gotoOpenSignatureReturnURL
}

export default {
    ACTIONS,
    gotoOpenSignatureReturnURL
}