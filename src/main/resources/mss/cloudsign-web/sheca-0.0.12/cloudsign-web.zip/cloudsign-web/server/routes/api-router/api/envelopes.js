const request = require("$HMAC")
const exit = require("$exit")

/**
 * ----------------------------------------------------
 * @path  /api/:userWsid/envelops
 * @method GET
 * @desc  获取信封列表
 * @author 陈曦源
 * @date  2018-11-28 20:16:42
 * ----------------------------------------------------
 */
exports.get = function(req, res, next){
    let {
        authorWsid,
        envelopeShownStatus = "ALL",
        participantName,
        fields,
        filters,
        offset = 0,
        limit = 20,
        sorts = "-status_datetime"
    } = req.query

    request({
        reqMethod: "GET",
        reqURL: "wesign-mss-envelope://envelopes/accurate-type",
        reqQuery: {
            author_wsid: authorWsid,
            envelope_shown_status: envelopeShownStatus,
            participantName,
            fields,
            filters,
            offset,
            limit,
            sorts
        },
        reqSession: req.cookies.SessionWsid
    }).then(resp => {
        let data = resp.data
    
        let envelopes = data.envelopes
        envelopes = envelopes.map(envelope => {
            let basicInfo = envelope.basicInfo
    
            return {
                title: basicInfo.title,
                envelopeWsid: basicInfo.envelopeWsid,
                status: basicInfo.status,
                envelopeStatus: basicInfo.envelopeShownStatus,
                statusDatetime: basicInfo.statusDatetime,
                createdDatetime: basicInfo.createdDatetime,
                multisendNum: basicInfo.multisendNum,
                metadata: basicInfo.metadata,
                templateWsid: basicInfo.templateWsid,
                envelopeFlowType:basicInfo.envelopeFlowType,
                sender: {
                    username: basicInfo.senderName,
                    userWsid: basicInfo.senderWsid
                },
            }
        })
    
        exit(res, {
            envelopes: envelopes,
            page: data.page,
        })
    }).catch(err => {
        next(err)
    })
}

/**
 * ----------------------------------------------------
 * @path  /api/envelopes
 * @method POST
 * @desc  创建信封
 * @author 陈曦源
 * @date  2018-01-08 20:02:57
 * ----------------------------------------------------
 */
exports.post = function (req, res, next) {
    let {
        senderWsid,
        tagId = new String(Math.floor(Math.random() * 100000)),
        envelopeType = "ANY",
        envelopeFlag
    } = req.body

    request({
        reqMethod: "post",
        reqURL: "wesign-mss-envelope://envelopes/normal",
        reqHeaders: {
            "X-Http-Client-IP": req.ip
        },
        reqData: {
            senderWsid,
            tagId,
            envelopeType,
            envelopeFlag
        },
        reqSession: req.cookies.SessionWsid
    }).then(resp => {
        let data = resp.data
        exit(res, {
            envelopeBasicInfo: data.envelope.basicInfo
        })
    }).catch(err => {
        next(err)
    })
}