<!--
    @id        page-upload-stamp
    @desc      上传签章页面
    @level     page：页面组件
    @author    陈曦源,潘维
    @date      2019-02-26 09:45:18
-->
<template>
    <div>
        <div class="header">
            上传签章
        </div>
        <div class="main">
            <div class="content">
                <div class="choose-container">
                    <div class="choose-picture" @click='selectFile'>
                        选择图片
                    </div>
                </div>
                <div class="img-demo">
                    <p>上传图片示例</p>
                    <ul>
                        <li><img src="\img\seal\mistake-gf.png"><span>标准</span></li>
                        <li><img src="\img\seal\mistake-bq.png"><span>边框缺失</span></li>
                        <li><img src="\img\seal\mistake-mh.png"><span>照片模糊</span></li>
                        <li><img src="\img\seal\mistake-gg.png"><span>强光闪烈</span></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="show-stamp" v-show='clip'>
            <div class="show-stamp-box">
                <label class="seal-info"><span class="seal-info-title">印章尺寸:</span><el-input type="text" :readonly="true" v-model.trim="selectSealSize">
                        <el-button slot="append" @click="selectSize">选择</el-button>
                    </el-input>
                    <span class="placeholder">&nbsp;mm&nbsp;<i class="question el-icon-question" @click="showSealSizeExplain"></i></span>
                </label>
                <div class="seals-size-info-box" >
                    <div class="seals-size-info">
                        <div class="placeholder"></div>
                        <div class="seal-size-box">
                            <ul class="seal-size-info-box" v-if="showSealsSize">
                                <li class="boom-list" v-for="item in sealsSize" @click="selectSealItem(item)">
                                    {{item.value}}
                                </li>
                            </ul>
                        </div>
                        <div class="placeholder"></div>
                    </div>
                </div>
                <div class="show-seal-area-box">
                    <div class="show-seal-area">
                        <pictureCut ref="cuter" :lockProp="true" class="change-style" :imageSrc="imgSrc" :containerSizeWidth="sealWidth" :containerSizeHeight="sealHeight" @imagePreviewInfoChange="imagePreviewInfoChange"></pictureCut>
                    </div>
                </div>
                <!--<div class="explain-info">
                    <center class="seal-hint public-left">系统已对印章图片进行背景透明化等美化处理</center>
                    <center class="public-left">效果不满意？<span class="color-blue" @click="rehandle(oldImgSrc)">重新处理</span></center>
                </div>-->
                <ul class="btn-group">
                    <li><span class="btn-style" @click='rotate(-90)'><i class="icon icon-left-90"></i></span><p>向左90°</p></li>
                    <li><span class="btn-style" @click='rotate(90)'><i class="icon icon-right-90"></i></span><p>向右90°</p></li>
                    <li><span class="btn-style" @click='rotate(-1)'><i class="icon icon-left-1"></i></span><p>向左1°</p></li>
                    <li><span class="btn-style" @click='rotate(1)'><i class="icon icon-right-1"></i></span><p>向右1°</p></li>
                    <li><span class="btn-style" @click='zoom(1.1)'><i class="icon icon-zoom-out"></i></span><p>放大</p></li>
                    <li><span class="btn-style" @click='zoom(0.9)'><i class="icon icon-zoom-in"></i></span><p>缩小</p></li>
                    <li><span class="btn-style" @click='preview = true'><i class="icon icon-view"></i></span><p>预览</p></li>
                </ul>
            </div>
            <div class="footer">
                <div class="btn reload" @click="selectFile">
                    重传
                </div>
                <div class="btn submit" @click.stop='save'>
                    提交
                </div>
            </div>
            <div class="after-cut" v-show='preview'>
                <div class="after-title">
                    <i class="icon-refuse"  @click='preview = false'></i>
                    图片预览
                </div>
                <div class="preview" :style="boxStyle">
                    <pictureCutPreview v-if="imagePreviewData" :width="sealWidth" :height="sealHeight" :imagePreviewInfo="imagePreviewData"/>
                </div>
            </div>
        </div>
        <div class="upload-success" v-show="uploadSuccess">
            <div class="view">
                <div class="success">
                    <i class="icon-complete"></i>
                </div>
                <span class="text-info">上传印章成功，请在PC端查看印章！</span>
                <p class="text-back btn reload" @click='backToload()'>重新上传</p>
            </div>
        </div>
        <div class="size-explain-box" v-show="sealSizeExplain">
            <div class="after-title">
                标准印章尺寸说明
                <i class="icon-refuse refuse" @click="sealSizeExplain = false"></i>
            </div>
            <div class="size-explain-info">
                <p>国有企业、国营股份制企业的印章（包括公司章、部门章）规格为 42 * 42 mm</p>
                <p>集体所有制所属部门及个体，私企的印章规格为 38 * 38 mm</p>
                <p>业务专用章规格为 40 * 40 mm</p>
                <p>工商企业合同专用章规格为 58 * 58 mm</p>
                <p>有限责任公司印章规格为 40 * 40 mm，专用章和公司部门印章规格为 38 * 38 mm</p>
                <p>股份有限公司印章规格为 42 * 42 mm，专用章和公司部门印章规格为 40 * 40 mm</p>
                <p>中外合资（合作），外商独资经营企业的规格为 45 * 30 mm</p>
            </div>
        </div>
    </div>
</template>

<script>
import { selectFile, ImageDataToFile } from "@commons/util.js"

import { Toast, MessageBox} from "mint-ui"
import pictureCut from "@components/modal/picture-cut.vue"
import pictureCutPreview from "@components/modal/picture-cut-preview.vue"
import {formUploadProcess} from "@interfaces/seals/seals.js" 

import { 
    joinRoom,
    uploadData
} from "@interfaces/web-socket/scan-upload.js"
// const FILE_MAX_SIZE = 1024 * 1024 * 1

export default {
    data(){
        return {
            uploadSuccess: false, //是否上传成功
            clip: false, //是否正在裁剪
            preview: false,

            key: window.location.href.split("key=")[1],
            imgSrc: "",
            imagePreviewData: null,
            fileName: "",
            sealsSize: [
                {value: "公章：40 * 40", width: 40, height: 40},
                {value: "公章：42 * 42", width: 42, height: 42},
                {value: "专用章：38 * 38", width: 38, height: 38},
                {value: "专用章：40 * 40", width: 40, height: 40},
                {value: "专用章：58 * 58", width: 58, height: 58},
                {value: "外企章：45 * 30", width: 45, height: 30},
            ],
            selectSealSize: "公章：40 * 40",
            showSealsSize: false,
            sealWidth: 0,
            sealHeight: 0,
            sealSizeExplain: false
        }
    },
    computed: {
        boxStyle(){
            return {
                width: this.sealWidth + "px",
                height: this.sealHeight + "px"
            }
        }
    },
    created(){
        joinRoom({
            roomkey: this.key
        }, err => {
            if (err){
                console.log(err)
            }
        })

        this.sealHeight = 40 / 25.4 * 96
        this.sealWidth = 40 / 25.4 * 96
    },
    methods: {
        selectFile(){
            selectFile("image/png,image/gif,image/jpg,image/jpeg,image/bmp,image/tiff").then(file => {
                this.chooseFile(file)
                this.fileName = file.name.split(".")[0]
            }).catch(err => {
                alert("选择的文件类型错误，请选择正确的图片文件")
            })
        },
        showSealSizeExplain(){
            this.sealSizeExplain = true
        },
        selectSealItem(item){
            this.selectSealSize = item.value
            this.showSealsSize = !this.showSealsSize
            this.sealHeight = item.height / 25.4 * 96
            this.sealWidth = item.width / 25.4 * 96
        },
        selectSize(){
            this.showSealsSize = !this.showSealsSize
        },
        chooseFile(file){
            let reader = new FileReader()
            let image = new Image()
            let that = this 
            reader.onload = e => {
                let data = e.target.result
                this.clip = true
                this.imgSrc = data
            }
            reader.readAsDataURL(file)
        },
        imagePreviewInfoChange(data) {
            this.imagePreviewData = data
        },
        zoom(scale){
            let cuter = this.$refs.cuter
            cuter.growScale(scale)
        },
        rotate(deg){
            let cuter = this.$refs.cuter
            cuter.growRotate(deg)
        },
        save(){
            let imagedata = this.$refs.cuter.cutImage(200, 200)
            uploadData({
                roomkey: this.key,
                sealData: {
                    name: this.fileName,
                    size: this.selectSealSize,
                    image: imagedata
                }
            }, err => {
                if (err){
                    alert("上传印章失败")
                } else {
                    this.uploadSuccess = true
                    this.clip = false
                }
            })
        },
        backToload(){
            this.clip = true
            this.uploadSuccess = false
            this.selectFile()
        }
    },
    components: {
        pictureCut,
        pictureCutPreview
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

html, body {
    margin: 0;
    padding: 0;
}
.header {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 50*@px;
    line-height: 50*@px;
    background: @color-main;
    color:@color-white;
    font-size: @font-size-title;
    text-align: center;
}

.main{
	position: absolute;
    top: 50*@px;
    bottom: 0*@px;
    left: 0;
    right: 0;
    background: #f3f8fe;
    z-index: 1;
    overflow: auto;
}
.content {
	position: relative;
	top: 0;
	bottom: 0;
	left: 0;
    right: 0;
    background: #f3f8fe;
    height:100%;
}
.img-demo{
    position: absolute;
    bottom: 0;
    height: 150*@px;
    left: 0;
    right: 0;
    text-align: center;
    background:@color-white;

    p{
        text-align:center;
        color:@color-info;
        height:35*@px;
        line-height:35*@px;
        font-size: @font-size-primary
    }
    
    ul{
        position: absolute;
        width: 100%;
        list-style: none;
        left: 0;
        right: 0;
        bottom:0;
        padding:0;
        
        li{
            float:left;
            width:25%;
            text-align:center;

            span{
                display:block;
                color:#545454;
                font-size:@font-size-info;
            }

            img{
                padding:5*@px;
                border:1*@px solid #eeeede;
            }
        }
	}
}

.choose-container{
    position: absolute;
    top: 0;
    bottom: 150*@px;
    left: 0;
    right: 0;

    .choose-picture{
        position: absolute;
        background-color:@color-main;
        width: 300*@px;
        height: 45*@px;
        line-height:45*@px;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color:@color-white;
        text-align: center;
        font-size: @font-size-primary;
    }
}


.show-stamp{
	.main;
    background: #f3f8fe;
    z-index: 1;

    .change-style{
        // position: absolute !important;
        // left: 50%;
        // top: 50%;
        // transform: translate(-50%,-50%);
        margin:20*@px auto;
        background:@color-white;
    }
}
.btn-group{
    text-align: center;
    // left: 0;
    // right: 0;
    list-style: none;
    // bottom: 50*@px;
    margin-top: 15*@px;
    padding: 0;
    display: flex;
    flex-wrap: wrap;

    li{
        float:left;
        width:25%;

        p{
            font-size:@font-size-info;
        }
    }

    .btn-style{
        display: inline-block;
        margin: 0 15*@px;
        width: 32*@px;
        text-align: center;
        line-height: 32*@px;
        border-radius: 16*@px;
        font-size: 20*@px;
    }
}

.after-cut{
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    width: 100%;
    min-height: 200*@px;
    max-height:270*@px;
    background: #fff;
    z-index: 99;

    .after-title{
        width: 100%;
        height:40*@px;
        line-height:40*@px;
        border-bottom:1*@px #eeeede solid;
        text-align:center;
        font-size:@font-size-primary;

        i{
            float: right;
            line-height: 40*@px;
            margin-right: 10*@px;
            color: @color-black;
        }
    }

    .preview{
        position: relative;
        margin: 3*@px auto;
        border: 1*@px solid #ccc;
    }
}


.footer {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 50*@px;
    z-index:99;

    .btn{
        height: 100%;
        width: 50%;
        line-height: 50*@px;
        color: #fff;
        text-align: center;
        font-size: @font-size-primary;
    }

    .reload {
        background: @color-main;
        float: left;
    }

    .submit {
        background: @color-success;
        float: right;
    }
}

.upload-success {
    z-index: 10;
    position: absolute;
    text-align: center;
    background: #fff;
    left: 0;
    right: 0;
    top:50*@px;
    bottom:0;
    padding-top: 100*@px;
    padding-bottom: 100*@px;

    .success{
        font-size: 40*@px;
        margin-bottom: 30*@px;
        i{
            color: @color-success;
        }
    }
    .text-info {
        color: @color-info;
        font-size: @font-size-primary;
    }
    
    .text-back{
        margin-top: 20*@px;
        height: 40*@px;
        width: 50%;
        max-width: 260*@px;
        line-height: 40*@px;
        color: #fff;
        text-align: center;
        font-size: 16*@px;
        background: #0c7ffc;
        margin: 20*@px auto;
        border-radius: 5*@px;
        cursor:pointer;
    }
}
.size-explain-box{
    position: absolute;
    background: #fff;
    left: 0;
    right: 0;
    top:50*@px;
    bottom:0;
    padding: 0*@px 20*@px;
    z-index:99;
}
.seal-info{
    display:flex;
    padding-top:15*@px;
    max-width: 400*@px;
    width: 90%;
    min-width: 300*@px;
    margin: 0 auto;
    align-items:center;
    justify-content: center;
    .seal-info-title{
        display:inline-block;
        width:65*@px;
        font-size:@font-size-regular;
    }
}
.placeholder{
    width:65*@px;
    text-align:center;
    display:inline-block;
}
.seals-size-info-box{
    margin: 0 auto;
    max-width:400*@px;
    width: 90%;
    min-width: 300*@px;
    .seals-size-info{
        display:flex;
        justify-content: center;
    }
}
.seal-size-box{
    margin:0;
    padding: 0;
    position: relative;
    width: 60%;
    max-width:300*@px;
    flex:1;
    z-index:99;
    background:#f3f8fe;
    .seal-size-info-box{
        padding: 0;
        margin:0;
        position:absolute;
        left:0;
        right:0;
        background:#fff;
        z-index:99;
    }
    li{
        padding:5*@px 10*@px;
        cursor:pointer
    }
    li:hover, li:active{
        color:#0c7ffc;
        background:#d8ecff
    }

}
.select-btn{
    margin-left:10*@px;
}
.question{
    font-size:20*@px;
    cursor:pointer;
}
.size-explain-info{
    padding:20*@px;
    p{
        min-height:40*@px;
        line-height:25*@px;
        border-bottom: 1*@px solid #d7dbde;
        font-size:@font-size-regular;
        display: flex;
        align-items: center;
    }
}
.boom-list{
    color: #333;
    font-size: @font-size-primary;
    height: 30*@px;
    line-height: 30*@px;
    border-bottom: 1*@px solid #e5e9ed;
    &:last-child{
        border: none;
    }
}
.after-title{
    width: 100%;
    height:40*@px;
    line-height:40*@px;
    border-bottom:1*@px #eeeede solid;
    text-align:center;
    font-size:@font-size-primary;

    i{
        float: right;
        line-height: 40*@px;
        margin-right: 10*@px;
        color: @color-black;
    }
}
.show-stamp-box{
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 50*@px;
    overflow: auto;
    // padding-bottom:30*@px;
}
@media only screen and (device-width:768px){
    .change-style{
        width: 430*@px;
        height: 430*@px;
    }
    span,p{
        font-size:15*@px;
    }
}
.show-seal-area-box{
    position: relative;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    min-height: 250*@px;
}
.show-seal-area{
    position: absolute;
    top: 50%;
    left: 50%;
    margin-top:10*@px;
    transform: translate(-50%,-50%);
}
.explain-info{
    margin-top:10*@px;
}
.color-blue{
    color:@color-main;
    cursor:pointer;
}
.public-left{
    margin-left:20px;
    line-height:25px;
}
.seal-hint{
    color:#99adce
}
</style>
<style>
.seal-info .el-input{
    width:60% !important;
    max-width:300px;
    flex:1;
}
.mint-msgbox-message{
    font-size:12px;
    line-height:25px;
}
</style>
