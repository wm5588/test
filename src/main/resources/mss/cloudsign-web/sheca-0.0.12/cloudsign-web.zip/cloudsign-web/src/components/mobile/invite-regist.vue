<template>
<div>
    <div class="container clearfix">
        <div class="row">
            <div class="pic">
                <div class="logo">
                  <a href="/wesign"></a>
                </div>
                <p class="min-header">{{inviteUser}}邀请您加入</p>
                <a class="company-name" href="#">{{companyName}}</a>
            </div>
            <div @input="clearError" class="info" v-if="notSuccess">
                <div class="error form-group">
                    <p v-if="errormsg" class="errorWarning"><i class="error-icon icon-no-circle"></i>{{errormsg}}</p>
                    <p v-if="rightmsg" class="errorWarning"><i class="icon-yes-circle"></i>{{rightmsg}}</p>
                </div>
                <div class="form-group">
                    <input type="text" v-model="userNumber" class="info-input" @blur="checkcontact" placeholder="手机号">         
                </div>
                <div class="form-group">
                    <input type="text" name="verifyCode" class="info-input find-code" v-model="verifyCode" placeholder="验证码" @blur="checkverifycode">
                    <a class="getCode" @click="getCode" v-if='time===0'>获取验证码</a>
                    <a class="getCode sub" v-else>重新发送({{time}}s)</a>
                </div>

                <div class="form-group">
                    <input type="text" class="info-input" v-model="userName" @blur="checkusername" placeholder="真实姓名" >    
                </div>
                <div class="form-group" v-show="number">
                    <input type="password" v-model="password" class="info-input" @blur="checkpassword" placeholder="设置登录密码" >         
                </div>
                <div class="form-group" v-show="number">
                    <input type="password" v-model="repassword" class="info-input" @blur="checkrepassword" placeholder="确认密码" @keyup.enter="regist">      
                </div>
                <div class="form-group">
                    <input type="button" class="btn" @click="inviteRegist" value="立即加入">
                </div>
            </div>
            <div @input="clearError" class="info" v-else>
                <div class="form-group icon">
                    <i class="icon-yes-circle"></i>
                </div>
                <p>您的申请已提交，正在等待管理员审核<p>
                <!--<div class="form-group">
                    <a type="button" class="btn downloadbtn" href="/app-download" value="下载大家签">下载大家签</a>
                </div>-->
                <a class="unline" href="/wesign/login">登录大家签查看</a>
            </div>
        </div>
    </div>
</div>
</template>
<script>
import Vue from "vue"
export default {
    data(){
        return {
            inviteUser: "李伟",
            companyName: "泰安科技有限公司",
            errormsg: "",
            userNumber: "",
            number: true,
            password: "",
            repassword: "",
            userName: "",
            verifyCode: "",
            time: 0,
            currentYear: "",
            notSuccess: true
        }
    },
    created: function(){
        let newDate = new Date()
        this.$data.currentYear = newDate.getFullYear()
    },
    methods: {
        //帐号校验
        checkcontact: function(){
            let that = this
            let val = this.$data.userNumber
            if (val.length === 0){
                this.$data.errormsg = "请输入机号"
                return false
            }

            if ( !strcheck.phone(val)){
                this.$data.errormsg = "手机号输入错误"
                return false
            }

            that.$data.rightmsg = "验证中.."
            usercheck({
                userId: val,
                success(data){
                    if (data.success){
                        if (data.data.exist){
                            that.$data.rightmsg = "该帐号已注册"
                            that.$data.number = false
                        } else {
                            that.$data.errormsg = ""
                            that.$data.number = true
                        }
                    } else {
                        console.error(data)
                        that.$data.number = true
                    }
                },
                error(data){
                    console.error(data)
                    that.$data.number = true
                }
            })

        },
        checkusername: function(){
            let val = this.$data.userName
            //中文，字母，数字或其组合的形式
            if (val.length === 0){
                this.$data.errormsg = "请输入您的真实姓名"
                return false
            }

            if (!strcheck.username_english(val) && !strcheck.username_chinese(val)){
                this.$data.errormsg = "姓名输入有误，请重新输入！"
                return false
            }

            this.$data.errormsg = ""
            return true
        },
        //密码校验
        checkpassword: function(){
            let val = this.$data.password
            if (val.length === 0){
                this.$data.errormsg = "请输入密码"
                return false
            }
            if (!strcheck.password_length(val)){
                if (val.length > 50){
                    this.$data.errormsg = "密码长度不能超过50位"
                }
                else {
                    this.$data.errormsg = "密码长度不能低于6位"
                }
                return false
            }

            if (strcheck.password_allabc(val)){
                this.$data.errormsg = "密码不能全为字母"
                return false
            }

            if (strcheck.password_allnumber(val)){
                this.$data.errormsg = "密码不能全为数字"
                return false
            }

            if (strcheck.password_allspecichar(val)){
                this.$data.errormsg = "密码不能全为字符"
                return false
            }

            this.$data.errormsg = ""
            return true
        },
        //确认密码
        checkrepassword: function(){
            let val = this.$data.password,
                preval = this.$data.repassword
            if (val === preval){
                this.$data.errormsg = ""
                return true
            } else {
                this.$data.errormsg = "密码确认错误，请重新输入"
                this.$data.password = ""
                this.$data.repassword = ""
                return false
            }
        },
        //验证码校验
        checkverifycode: function(){		
            let val = this.$data.captcha
            if (/^\d{6}$/.test(val)){
                this.$data.errormsg = ""
                this.vertifyCode()
                return true
            } else {
                this.$data.errormsg = "验证码格式错误，请重新输入！"
                return false
            }
        },
        //获取验证码
        getVerifyCode: function(){
            let me = this.$data
            let val = me.userNumber
            if (this.errormsg == "" || val == ""){
                return 
            }
            /*	if(strcheck.phone(val)){	*/			
            send_newphone({
                body: {
                    sendDest: val
                },
                success: function(json){
                    if (json.success){
                        me.time = json.data.time
                        let t = setInterval(() => {
                            if (me.time === 0){
                                clearInterval(t)
                                return
                            }
                            me.time--
                        }, 1000)
                    }
                    else if (json.data.time){
                        me.time = json.data.time
                        let t = setInterval(() => {
                            if (me.time === 0){
                                clearInterval(t)
                                return
                            }
                            me.time--
                        }, 1000)
                        me.errormsg("请求频繁，请稍候再试！")
                    }
                    else {
                        me.errormsg("验证码获取次数今天已超过限制，请明天再试")
                    }
                },
                error: function(str){
                    console.error(str)
                }
            })
        },
        //验证验证码
        vertifyCode: function(){
            let me = this.$data
            if (me.time != 0 && me.errormsg !== "" && me.userNumber == ""){
                return
            }
            /*if(strcheck.phone(me.userNumber)){*/
            verify_newphone({
                body: {
                    sendDest: me.userNumber,
                    verifyData: me.verifyCode
                },
                success: function(json){
                    if (json.success){
                        me.errormsg = ""
                    }
                    else {
                        console.error(json)
                        me.errormsg = "验证码错误！"
                    }
                },
                error: function(str){
                    console.error(str)
                    me.errormsg = "验证码错误！"
                }
            })
        },
        clearError(){
            this.errormsg = ""
            this.rightmsg = ""
        },
        //邀请注册
        inviteRegist: function(){
            let that = this
            if (this.registing){
                return
            }
            this.registing = true
            if (this.errormsg ||
        this.userNumber == "" ||
        this.userName == "" ||
        this.password == "" ||
        this.repassword == "" ||
        this.captcha == "" ||
        this.verifyCode == ""){
                that.$data.errormsg = "请填写正确的完整信息"
                return 
            }
            let account = this.userNumber
            let type
            if (strcheck.email(account)){
                type = 2
            } else if (strcheck.phone(account)){
                type = 1
            } else {
                this.$data.errormsg = "请填写正确的邮箱或手机格式"
                return 
            }
            this.$data.rightmsg = "注册中..."
            //加密密码
            //提交信息
            //ajax请求post姓名，密码，验证码，
            ajax_regist({
                type: type, //注册类型 手机注册:1,邮箱注册:2
                account: account, //注册帐号名
                username: this.userName, //用户名
                password: this.password, //密码 md5 加密后
                success: function(data){
                    if (data.success){
                        that.$data.errormsg = ""
                        that.$emit("registsuccess")
                        that.notSuccess = false
                        that.$data.headerTitle = "大家签"
                    } else {
                        console.error(data)
                        that.$data.errormsg = data.err.msg
                        if (data.data && data.data.vcode){
                            that.$data.vcode = data.data.vcode
                        }
                    }
                    that.registing = false
                },
                error: function(data){
                    console.error(data)
                    that.$data.errormsg = "请求失败，请重试"
                    that.registing = false
                }
            })
        }
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
    .header {
        top: 0;
        left: 0;
        right: 0;
        height: 15*@px;
        background: #095db1;
        text-align: center;
    }
    @media screen and (max-width:414px){
        .file-header{
            top: 0;
            left: 0;
            right: 0;
            height: 15*@px;
            padding-bottom:20*@px;
            margin-bottom:10*@px;
            background: #095db1;
            text-align: center;
        }
    }
    @media screen and (min-width:414px){
        .filder-header{
            display:none;
        }
    }
    .title {
       /* display: block;
        width: 100%;
        height: 100%;*/
        text-align: center;
        white-space: nowrap;
    }
    .title p{
        font-family: "Microsoft YaHei", sans-serif;
        line-height: 40*@px;
        /*font-size: 1.2*@px;*/
        color: #fff;
        margin: 0;
        display:inline-block;
    }
    
    .container{
        width: 96%;
        min-width: 280px;
        min-height: 580*@px;
        max-height: 600*@px;
        left: 2%;
        margin:0 auto;
        margin-top: 15*@px;
        padding-top: 10*@px;
        background: #ffffff;
        border: 1px solid #e3e8ee;
        border-radius: 6px;
    } 
    .row{
        padding-top: 0;
        margin: 0 auto;
        text-align: center;
        display: block;
    }
    .pic{
        display:block;
    }
    .logo{
        width:90px;
        height:42px;
        padding-top: 0px;
        text-align: center;
        margin:0 auto;
    } 
    .logo a{
        background: url(/home/img/logo3.png) no-repeat center;
        width:90px;
        height:42px;
        display: block; 
        background-size:100%;
    }
    .min-header{
        font-family: "Microsoft YaHei", sans-serif;
        font-size: @font-size-regular;
        margin-top:10*@px;
        width:85%;
    }
    .company-name{
        font-family: "Microsoft YaHei", sans-serif;
        color: #095db1;
        font-size: @font-size-regular;
        text-decoration: none;
        margin: 10*@px;0;
    }
    .info{
        font-family: "Microsoft YaHei", sans-serif;
        font-size:14px;
        width: 96%;
        position: absolute;
        left: 6*@px;
    }
    .error{
        width: 96%;
        max-width: 280*@px;
        margin: 0 auto;
        /*padding: 1px 10px;*/
    }
    .errorWarning{
        display: block;
        /* height: 4*@px; */
        line-height: 25*@px;
        background: #f8f6c6;
        text-indent: 10*@px;
        color: #000000;
        text-align: left;
        margin-top:0;
    }
    .error-icon{
        color:#ff6700;
    }
    .form-group{
         margin-bottom: 10*@px;
         display:block;
    }
    .info-input{
        font-family: "Microsoft YaHei", sans-serif;
        text-indent: 10*@px;
        height: 40*@px;
        line-height: 40*@px;
        font-size: @font-size-regular;
    }
    .info-input, .btn {
        font-family: "Microsoft YaHei", sans-serif;
        font-size:14px;
        width: 96%;
        max-width: 280*@px;
        border: 1px solid #e3e8ee;
        border-radius: 1px;
    }
    .getCode{
        border: 0;
        margin: 13*@px - 80*@px;
        position:absolute;
        vertical-align:middle;
        background:rgba(255,255,255,0);
        font-family: "Microsoft YaHei", sans-serif;
        font-size: @font-size-regular;
        color: #095db1;
        cursor:pointer;
    }
    .sub{
        color:#666;
    }
    .btn{
        display: inline-block;
        background: #095db1;
        color: #ffffff;
        height: 40*@px;
        line-height: 30*@px;
        font-size: 16px;
        cursor: pointer;
    }
    .btn:focus{
        background-color:rgba(100,159,251,0.9);
    }
    .downloadbtn{
        margin-top:20*@px;
    }
    .login-footer{
        max-width: 220*@px;
        top: 620*@px;
        bottom:0;
        left: 0;
        right: 0;
        height: 30*@px;
        line-height: 15*@px;
        font-family: "Microsoft YaHei", sans-serif;
        font-size: @font-size-regular;
        text-align: center;
        color: #878787;
        margin:0 auto;
    }
    .ui-nologin-copy{ 
        font-family: "Microsoft YaHei", sans-serif;
        font-size: @font-size-regular;    
        margin-top: 10*@px;
        text-align:center;
 	}
     /*图标样式*/
     .icon{
        height: 40*@px;
        font-size: 40*@px;
        vertical-align: middle;
        margin-top: 50*@px;
        margin-bottom:20*@px;
     }
     .icon-yes-circle{
         color:#34cc99;
     }
     .unline{
        font-family: "Microsoft YaHei", sans-serif;
        color:#095db1;
        text-decoration: underline;
        font-size: @font-size-regular;
    }
    .unline:hover{
        text-decoration:none;
    }
    .info p{
        font-family: "Microsoft YaHei", sans-serif;
        font-size: @font-size-regular;
    }

</style>