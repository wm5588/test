const express = require("express"),
    http = require("http")

let httpServer

app = express()

require("./routes/global-router.js").setInit(app)
require("./routes/api-router.js").setAPIs(app)
require("./routes/page-router.js").setPages(app)

app.use("/api/*", function(req, res){
    res.status(400).json({
        err: {
            code: "000x400"
        }
    })
})

app.use(function(req, res){
    res.redirect("/error/404")
})

//服务器启动
httpServer = http.createServer(app)

httpServer.listen($config.httpport, function(){
    LOG.info("HTTP服务器启动 http://*:" + $config.httpport)
})