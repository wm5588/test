import "./common.js"
import "@styles/icons/style.css"

import Vue from "vue"
import {
    Row,
    Col,
    Input,
    Button,
    Dialog,
    InputNumber,
    Table,
    TableColumn,
    Checkbox,
    Radio,
    RadioGroup,
    CheckboxGroup,
    Select,
    Option,
    Message,
    MessageBox,
    Notification,
    Transfer,
    Switch,
    Autocomplete,
    Loading,
    Tooltip,
    Checkbox,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Dialog)
Vue.use(InputNumber)
Vue.use(Table)
Vue.use(TableColumn)
Vue.use(Checkbox)
Vue.use(Radio)
Vue.use(RadioGroup)
Vue.use(Select)
Vue.use(Option)
Vue.use(Transfer)
Vue.use(Switch)
Vue.use(Autocomplete)
Vue.use(Loading)
Vue.use(Tooltip)
Vue.use(CheckboxGroup)
Vue.prototype.$message = Message
Vue.prototype.$msgbox = MessageBox
Vue.prototype.$alert = MessageBox.alert
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$prompt = MessageBox.prompt
Vue.prototype.$notify = Notification

import templateEditor from "@page-components/templates/editor.vue"
import showtimeSettingForms from "@page-components/templates/showtime/showtime-setting-forms.vue"

if (/doc-form-setting=true/.test(location.href)){
    window.sourceWindow = null
    window.loaded = false
    window.addEventListener("message", function(e){
        let data = e.data
        try {
            data = JSON.parse(e.data)
        } catch (e){
    
        }
        if (data.code === "DOCCONFIG" && !window.loaded){
            window.sourceWindow = e.source
            window.loaded = true
            let recipients = data.recipients
            let document = data.document
            let forms = data.forms
            new Vue({
                el: "#app",
                data: {
                    recipients,
                    documents: [document],
                    forms
                },
                template: `
                    <div style="position:absolute;left:0;bottom:0;top:0;right:0">
                        <div style="position:absolute;left:0;bottom:0;z-index: 1000;">
                            <el-button type="primary" @click="save">保存并关闭</el-button>
                        </div>
                        <showtimeSettingForms ref="set" :recipients='recipients' :documents='documents' :initForms='forms' />
                    </div>
                `,
                methods: {
                    save(){
                        window.sourceWindow.postMessage(JSON.stringify({
                            code: "FORMS",
                            forms: this.$refs.set.getForms()
                        }), "*")
                        window.close()
                    }
                },
                components: {
                    showtimeSettingForms
                }
            })
        }
    })    
} else {
    new Vue({
        el: "#app",
        template: "<templateEditor />",
        components: {
            templateEditor
        }
    })
}
