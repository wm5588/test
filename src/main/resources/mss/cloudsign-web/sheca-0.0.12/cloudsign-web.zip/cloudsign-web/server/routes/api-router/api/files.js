const proxy = require("express-http-proxy")
const url = require("url")
const exit = require("$exit")
const askend = require("$HMAC").askend

const fileURL = url.parse($config.backend["wesign-mss-file://"])
const host = fileURL.host
const pathname = fileURL.pathname

let proxyFun = proxy(host, {
    parseReqBody: false,
    proxyReqOptDecorator: function(proxyReqOpts, srcReq) {
        proxyReqOpts.headers["X-Requested-Session"] = srcReq.cookies.SessionWsid || srcReq.query.SessionWsid
        return proxyReqOpts
    },
    proxyReqPathResolver: function(req) {
        return `${pathname}files/${req.params.fileId}`
    },
    // userResDecorator: function(proxyRes, proxyResData, userReq, userRes){
    //     return proxyResData
    // }
})

exports.get = function (req, res, next) {
    proxyFun(req, res, next)
}