const INIT_ERROR = {
    TOKEN_INVALID: "TOKEN_INVALID", //token无效
    TOKEN_REQUEST_FAIL: "TOKEN_REQUEST_FAIL", //token信息请求失败
    TOKEN_SCOPES_INVALID: "TOKEN_SCOPES_INVALID", //token作用域错误
    UNKOWN: "UNKOWN", //未知错误
}

export {
    INIT_ERROR
}