<!--
    @desc   该组件为用户头像组件
    @props  
        size:String 控制头像显示的大小 可选参数为middle,large,small,mini
    @auther 陈曦源
    @date   2018-05-30 09:01:44
-->
<template>
    <div class="avatar-box" :class="'avatar-box-' + size"> 
        <avatar :size="size"></avatar>
        <span class="wide-text" ref="name"></span>
        <div class="pic-txt" ref="loadPic" @click="selectImage">
            <i class="icon-camera add-pic"></i>
            <span>上传新头像</span>
        </div>
        <el-dialog title="头像上传" ref='dialog' width="500px" :visible.sync="showDialog" :close-on-click-modal="false" :append-to-body="true">
            <avatarEditUpload v-if="showDialog" :defaultSrc="localImageSrc" @e-commit="closeDialog"></avatarEditUpload>
        </el-dialog>
    </div>
</template>

<script>
import { selectFile } from "@commons/util.js"

import avatar from "@components/commons/avatar.vue"
import avatarEditUpload from "@components/modal/avatar-edit-upload.vue"

export default {
    props: {
        size: {
            type: String,
            default: "small"
        }
    },
    data: function(){
        return {
            localImageSrc: "", //准备用于截取头像的原始图片
            showDialog: false,
        }
    },
    methods: {
        closeDialog() {
            this.showDialog = false
        },
        selectImage() {
            selectFile("image/jpg,image/jpeg,image/png,image/gif,image/bmp,image/tiff").then(file => {
                this.editFile(file)
            }).catch(err => {
                this.$message.error("选择的文件类型错误，请选择正确的图片文件")
            })
        },
        editFile: function(file){
            let imgName = file.name 
            if (/\.(jpg|png|jpeg|gif|bmp|tiff)$/i.test(imgName)){
                if (!window.FileReader){
                    this.$message.error("浏览器不兼容FileReader")
                    return
                }
                else {
                    let reader = new FileReader()
                    reader.readAsDataURL(file)
                    reader.onload = item => {
                        this.showDialog = true
                        this.localImageSrc = item.target.result
                    }
                }
            } else {
                this.$message.info("请选择有效的图片文件")
            }
        },
    },
    components: {
        avatarEditUpload,
        avatar
    },
}
</script>

 
<style lang="less" scoped>
@import "~@styles/variable.less";

.avatar-box{
    position:relative;
    border-radius: 50%;
    overflow: hidden;

    .avatar-box-size(mini,30px);
    .avatar-box-size(small,40px);
    .avatar-box-size(middle,80px);
    .avatar-box-size(large,120px);

    &:hover{
        .wide-text{
            opacity:0.7;
        }

        .pic-txt{
            opacity: 1;
        }
    }
}

.avatar-box-size(@name,@size){
    &.avatar-box-@{name}{
        width:@size;
        height:@size;

        .wide-text{
            width:@size;
            height:@size;
        }

        .pic-txt{
            width:@size;
        }
    }
}

.wide-text{
    position: absolute;
    top:0;
    left:0;
    border-radius:50%;
    background-color:#777;
    opacity:0;
    display: inline-block;
    overflow: hidden; 
    border: solid 1px #fff;
}

.pic-txt{
    cursor: pointer;
    color:#fff;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    opacity:0;
    vertical-align:middle;
    text-align:center;
}

.add-pic{
    display: block;
    font-size: 30px;
    color: #fff;
}
</style>