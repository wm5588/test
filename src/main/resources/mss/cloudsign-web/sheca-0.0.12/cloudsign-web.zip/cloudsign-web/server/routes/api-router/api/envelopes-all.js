const request = require("$HMAC")
const exit = require("$exit")

/**
 * ----------------------------------------------------
 * @path  /api/envelopes/:enterpriseWsid/enterprise
 * @method GET
 * @desc   查看企业所有信封
 * @author 潘维
 * @date  2019-03-13 09:23:01
 * ----------------------------------------------------
 */
exports.get = function(req, res, next){
    let {
        enterpriseWsid
    } = req.params

    let {
        envelopeShownStatus = "ALL",
        participantName,
        fields,
        filters,
        offset = 0,
        limit = 20,
        sorts = "-status_datetime"
    } = req.query

    request({
        reqMethod: "GET",
        reqURL: `wesign-mss-envelope://envelopes/enterprises/${enterpriseWsid}`,
        reqQuery: {
            envelopeShownStatus,
            participantName,
            fields,
            filters,
            offset,
            limit,
            sorts
        },
        reqSession: req.cookies.SessionWsid
    }).then(resp => {
        let data = resp.data
    
        let envelopes = data.envelopes
        envelopes = envelopes.map(envelope => {
            let basicInfo = envelope.basicInfo
    
            return {
                title: basicInfo.title,
                envelopeWsid: basicInfo.envelopeWsid,
                status: basicInfo.status,
                envelopeStatus: basicInfo.envelopeShownStatus,
                statusDatetime: basicInfo.statusDatetime,
                createdDatetime: basicInfo.createdDatetime,
                multisendNum: basicInfo.multisendNum,
                metadata: basicInfo.metadata,
                envelopeFlowType:basicInfo.envelopeFlowType,
                templateWsid: basicInfo.templateWsid,
                sender: {
                    username: basicInfo.senderName,
                    userWsid: basicInfo.senderWsid
                },
            }
        })
    
        exit(res, {
            envelopes: envelopes,
            page: data.page,
        })
    }).catch(err => {
        next(err)
    })
}

/**
 * ----------------------------------------------------
 * @path  /api/envelopes
 * @method POST
 * @desc  创建信封
 * @author 陈曦源
 * @date  2018-01-08 20:02:57
 * ----------------------------------------------------
 */
exports.post = function (req, res, next) {
    let {
        senderWsid,
        tagId = new String(Math.floor(Math.random() * 100000)),
        envelopeType = "ANY",
        envelopeFlag
    } = req.body

    request({
        reqMethod: "post",
        reqURL: "wesign-mss-envelope://envelopes/normal",
        reqData: {
            senderWsid,
            tagId,
            envelopeType,
            envelopeFlag
        },
        reqSession: req.cookies.SessionWsid
    }).then(resp => {
        let data = resp.data
        exit(res, {
            envelopeBasicInfo: data.envelope.basicInfo
        })
    }).catch(err => {
        next(err)
    })
}