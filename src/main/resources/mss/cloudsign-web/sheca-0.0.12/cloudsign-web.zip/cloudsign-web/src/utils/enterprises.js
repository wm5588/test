import { getUserData } from "@interfaces/user/user.js"

async function getCurrentMemberWsid(userWsid){
    return await getUserData({
        userWsid
    }).then(res => {
        let userInfo = res.data.data.userInfo
        return userInfo.enterprise.memberWsid
    })
}

export {
    getCurrentMemberWsid
}