<!--
    @id        ui-code-explain
    @desc      收不到验证码组件
    @level     ui：UI组件
    @author    周雪梅
    @date      2018-12-18 21:38:02
-->
<template>
	<modal @close-modal='close' @close-dialog="close" width='90%' height='260px' :top="top" :title="type === 'UPER' ? '国徽照示例图片': '人像照示例图片'">
		<div class="modal-container">
            <div class="more-sample" v-if="type === 'UPER'">
            <p class="upload-example">澳门上传示例</p>
            <p><imgBox :width="200" :height="100" :src="macaoBg"></imgBox></p>
            <p class="upload-example">台湾上传示例</p>
            <p><imgBox :width="200" :height="100" :src="taiwanBg"></imgBox></p>
        </div>
        <div class="more-sample" v-if="type === 'LOWER'">
            <p class="upload-example">澳门上传示例</p>
            <p><imgBox :width="200" :height="100" :src="macao"></imgBox></p>
            <p class="upload-example">台湾上传示例</p>
            <p><imgBox :width="200" :height="100" :src="taiwan"></imgBox></p>
        </div>
		</div>
    </modal>
</template>

<script>
import imgBox from "@components/commons/img-box.vue"
import modal from "./modal.vue"
import taiwan from "@images/auth/taiwai.png"
import taiwanBg from "@images/auth/taiwanbg.png"
import macaoBg from "@images/auth/macaobg.png"
import macao from "@images/auth/macao.png"
export default{
    props: {
        top: {
            type: String,
            default: "100px"
        },
        type: String
    },
    data(){
        return {
            taiwanBg: taiwanBg,
            taiwan: taiwan,
            macaoBg: macaoBg,
            macao:macao
        }
    },
    methods: {
        close(){
            this.$emit("close-modal")
        }
    },
    components: {modal, imgBox}
}
</script>

<style scoped>
.modal-container{
	text-align:left;
	padding:20px 20px;
}
.upload-example{
    font-size:14px;
    line-height:30px;
    text-align:center;
}
.autoresize-img-box{
    margin:0 auto;
}
</style>