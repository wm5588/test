import { getUserData, setSignPassword, resetSignPassword } from "@interfaces/user/user.js"
import { getUserRoles } from "@interfaces/policy/enterprise-roles.js"
import { USER_EDITION } from "@utils/users.js"

const userDataModule = {
    state: {
        userWsid: "", //用户PUSERID
        idttvStatus: "NO", //认证状态 INCOMPLETE-未完善；PASS-认证通过；WAITING-等待认证；DENY-认证未通过；EXPIRED-过期"
        
        //企业相关
        enterpriseWsid: "", //用户所在企业ID
        enterpriseAuthorWsid: "", //用户所在企业拥有者ID
        /* 企业认证状态：
         * INCOMPLETE-未认证
         * WAITING-等待审核
         * PRIMARY_PASSED-初级认证
         * PRIMARY_DENY-认证未通过
         * WAITING_SUM-等待打款
         * WAITING_SUM_CHECK-确认打款(等待用户汇款信息确认)
         * SENIOR_PASSED-高级认证(用户汇款信息确认成功),
         * SENIOR_DENY-认证未通过(打款失败/汇款验证失败)
         */
        enterpriseIdttvStatus: "",
        memberWsid: "", //用户在企业的Wsid
        enterpriseRoles: [],

        phone: "", //手机号
        email: "", //邮箱
        existSignPassword: false, //是否已经签署密码
    },
    getters: {
        memberWsid(state){
            return state.memberWsid
        },
        enterpriseWsid(state){
            return state.enterpriseWsid
        },
        puserWsid(state){
            return state.userWsid
        },
        isEnterpriseAuthor(state, getters){
            return state.userWsid === state.enterpriseAuthorWsid
        },
        participantEnterpriseRole(state, getters){
            let enterpriseRoles = state.enterpriseRoles
            let participant = getters.currentParticipant
            if (!participant) return null
            let role = enterpriseRoles.find(role => participant.authorWsid === role.wsid)
            return role || null
        },
    },
    mutations: {
        setData(state, userData){
            state.userWsid = userData.user.userWsid
            state.idttvStatus = userData.user.idttvStatus

            state.phone = userData.user.phone
            state.email = userData.user.email
            state.existSignPassword = userData.user.existSignPassword
        },
        setEnterpriseData(state, enterpriseData){
            state.enterpriseWsid = enterpriseData.enterpriseWsid
            state.memberWsid = enterpriseData.memberWsid
            state.enterpriseAuthorWsid = enterpriseData.enterpriseAuthorWsid
            state.enterpriseRoles = enterpriseData.enterpriseRoles
            state.enterpriseIdttvStatus = enterpriseData.enterpriseIdttvStatus
        },
        setSignPasswordSuccess(state){
            state.existSignPassword = true
        }
    },
    actions: {
        async initUserData({ getters, commit }){
            let userWsid = getters.userWsid
            let userEdition = getters.userEdition
            
            let userInfo = await getUserData({ userWsid }).then(res => res.data.data.userInfo)
            commit("setData", userInfo)

            //如果是企业还需要加载角色列表
            if (userEdition === USER_EDITION.ENTERPRISE){
                let enterpriseRoles = await getUserRoles({ authorWsid: userWsid }).then(res => res.data.data.enterpriseRoles)
                commit("setEnterpriseData", {
                    enterpriseWsid: userInfo.enterprise.enterpriseWsid,
                    memberWsid: userInfo.enterprise.memberWsid,
                    enterpriseAuthorWsid: userInfo.enterprise.authorWsid,
                    enterpriseRoles: enterpriseRoles,
                    enterpriseIdttvStatus: userInfo.enterprise.idttvStatus
                })
            }
        },
        updateSignPassword({state, commit}, data){
            let userWsid = state.userWsid
            if (state.existSignPassword){
                return resetSignPassword({
                    userWsid,
                    oldSignPassword: data.oldSignPassword,
                    newSignPassword: data.newSignPassword
                }).then(_ => {
                    commit("setSignPasswordSuccess")
                })
            } else {
                return setSignPassword({
                    userWsid,
                    signPassword: data.newSignPassword
                }).then(_ => {
                    commit("setSignPasswordSuccess")
                })
            }
        }
    }
}

export default userDataModule
