import VueRouter from "vue-router"
import homeLayout from "@page-components/frames/external-frame.vue"
import indexLayout from "@page-components/mobile/index.vue"
let mobileRoutes = new VueRouter({
    mode: "history",
    base: "/wesign",
    routes: [
        {
            path: "/",
            component: indexLayout,
            meta: {
                requireLogin: 1
            },
            children: [
                {
                    path: "/user",
                    alias: ["/"],
                    meta: {
                        title: "未签文档"
                    },
                    component: resolve => {
                        require.ensure([], () => {
                            resolve(require("@components/mobile/index.vue"))
                        }, "user")
                    }
                },
                {
                    path: "/envelopes",
                    name: "envelopes",
                    meta: {
                        title: "我的文件"
                    },
                    component: resolve => {
                        require.ensure([], () => {
                            resolve(require("@components/mobile/envelopes.vue"))
                        }, "envelopes")
                    }
                },
                {
                    path: "/me",
                    meta: {
                        title: "我的信息"
                    },
                    component: resolve => {
                        require.ensure([], () => {
                            resolve(require("@components/mobile/me.vue"))
                        }, "me")
                    }
                }, {
                    path: "/auth-result",
                    meta: {
                        title: "认证结果"
                    },
                    component: resolve => {
                        require.ensure([], () => {
                            resolve(require("@components/mobile/auth/auth-result.vue"))
                        }, "auth-result")
                    }
                }
            ]
        },
        {
            path: "/envelopes/:id/detail",
            name: "envelope-detail",
            meta: {
                title: "文档详情",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@components/mobile/envelopes/envelope-info.vue"))
                }, "mobile-doc-detail") 
            }
        
        },
        {
            path: "/envelopes/:id/signature",
            meta: {
                title: "文档签署",
                requireLogin: 1
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@components/mobile/envelopes/signature.vue"))
                }, "signature")
            }
        },
        {
            path: "/envelopes/:id/check",
            meta: {
                title: "文档审核",
                requireLogin: 1
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@components/mobile/envelopes/envelope-check.vue"))
                }, "signature")
            }
        },
        {
            path: "/envelopes/:id/audit",
            meta: {
                title: "文档审核",
                requireLogin: 1
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@components/mobile/envelopes/envelope-check.vue"))
                }, "signature")
            }
        },
        {
            path: "/envelopes/:id/preview",
            name:"envelpoe-preview",
            meta: {
                title: "文档预览",
                requireLogin: 1,
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@components/mobile/envelopes/envelope-preview.vue"))
                }, "signature")
            }
        },
        //  {
        //     path: '/wesign',
        //     component:homeLayout,
        //      meta:{
        //                 title:"邀请注册"
        //         },
        //     children:[
        //         {
        //             path: '/invite-regist',
        //             component: resolve => {
        //                 require.ensure([], () => {
        //                     resolve(require('@components/mobile/invite-regist.vue'));
        //                 }, 'invite-regist');
        //             }
        //         }
        //     ]
        //  }
        {
            path: "/crated-organizational",
            meta: {
                title: "创建组织",
                name: "auth"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@components/mobile/common/created-organizational.vue"))
                }, "organizational")
            }
        },
        {
            path: "/auth/mobile",
            meta: {
                title: "个人实名认证",
                name: "auth"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@components/mobile/auth/mobile-auth.vue"))
                }, "auth")
            }
        },
        {
            path: "/auth/manual",
            meta: {
                title: "个人实名认证-人工审核",
                name: "auth"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@components/mobile/auth/manual-auth.vue"))
                }, "auth")
            }
        },
        {
            path: "/envelop-openapi-complete",
            meta: {
                title: "操作完成",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/envelope/envelop-openapi-complete.vue"))
                }, "async-envelope")
            }
        }
    ]
    
})

export default mobileRoutes
