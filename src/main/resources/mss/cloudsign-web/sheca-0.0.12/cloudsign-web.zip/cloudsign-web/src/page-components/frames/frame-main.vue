<!--
    @id        frame-main
    @desc      应用页面主框架
    @level     page：页面组件
    @author    陈曦源,周雪梅,潘维,魏正林
    @date      2019-11-12 21:33:58
-->
<template>
    <div>
        <nav class="frame-main-nav">
            <div class="frame-main-nav-account">
                <div class="frame-main-name">{{activeAccount.name}}</div>
                <el-popover
                    v-model="accountPopoverVisible"
                    ref="change-account"
                    placement="top-end"
                    popper-class="wesign-popper-account-list"
                    trigger="click"
                    :visible-arrow="false">
                    <el-input class="search-enterpeise"
                            placeholder="检索您需要切换的公司名称"
                            size="medium"
                            v-model.trim="enterpriseName"
                            prefix-icon="el-icon-search">
                    </el-input>
                    <div class="create-enterprise" @click="openCreateOrganizationDialog">
                        <i class="icon-enlarge"></i>
                        创建新企业
                    </div>
                    <ul class="account-list">
                        <li v-for="account in rearchResult" :key="account.id" class="normal" :class="{active:account.now}" @click="account.now ?null:change(account.id)">
                            <i v-if="account.enterprise" class="icon-home"></i>
                            <i v-else class="icon-user"></i>
                            {{account.name}}
                            <i v-if="account.now" class="active el-icon-check"></i>
                            <!--<i v-if="account.memberStatus=== 'DISABLED'" class="icon-forbid forbid"></i>-->
                        </li>
                        <li class="loading-box" v-loading="accountsLoading">
                        </li>
                    </ul>
                </el-popover>
                <div class="frame-main-btn">
                    <el-button v-popover:change-account class="btn-account-change" type="primary" round>
                    切换<i class="el-icon-arrow-down"></i>
                </el-button>
                </div>
            </div>
            <div class="frame-main-right">
                <!-- <a href="https://help.signit.cn/" target="_blank" class="question"><i class="icon-question1 icon-question"></i>帮助</a> -->
                <div class="frame-main-messages" @click="messagesNotification">
                    <i class="el-icon-bell"></i>
                    <el-badge :max="99" v-if="messagesLength>=1" :value="messagesLength" class="item">
                    </el-badge>
                </div>
                <div class="frame-main-nav-user">
                    <el-popover
                        v-model="infoPopoverVisible"
                        ref="account-info"
                        placement="top-end"
                        popper-class="account-info-popper-class"
                        trigger="click"
                        :visible-arrow="false">
                        <ul class="account-list">
                            <li @click="accountInfo">账户设置</li>
                            <!-- <li>新手指引</li> -->
                            <!-- <li>下载大家签APP</li> -->
                            <li @click="logout">退出登录</li>
                        </ul>
                    </el-popover>
                    <avatar class="user-avatar" v-popover:account-info size="small"></avatar>
                    <div class="user-infos">
                        <div class="user-name">
                            {{userName}}
                            <i v-if="userAuthStatus == 'PASSED'" class="auth icon-auth"></i>
                            <i v-else class="unauth icon-unauth"></i>
                            <p class="member-role" v-if="userEdition === 'e' && isAuthor">管理员</p>
                        </div>
                        <!--<div class="user-status">
                            <authStatusPerson></authStatusPerson>
                        </div>-->
                    </div>
                </div>
            </div>
        </nav>
        <nav class="frame-left-nav">
            <ws-img-box class="frame-logo" @click="$router.push('/')" :src="logoURL"/>
            <el-popover
            ref="popover"
            placement="bottom-start"
            :visible-arrow="false"
            width="160"
            popper-class="envelope-send-type-list"
            trigger="hover">
                <ul style="text-align:center; margin:0;padding:0;">
                    <li @click="createEnvelope('0')">文档签署发起
                    <p style="font-size:12px;padding-top:5px">发送给自己或多人一起签署</p></li>
                    <hr style="height:0">
                    <li @click="createEnvelope('1')">批量发送
                        <p style="font-size:12px;padding-top:5px">发送文档给多个人独立签署</p>
                    </li>
                </ul>
            </el-popover>
            <el-button class="frame-btn-start-sign" size="medium" type="primary" :loading="creating" v-popover:popover>发起签署 <i class="icon el-icon-arrow-down"></i></el-button>
            <div class="nav-container">
                <el-menu :default-active="activeRouter" :unique-opened="true" :collapse="collapse" :router="true" 
                    @select="handleSelect">
                    <el-menu-item class="left-nav-modi" index="/"><i class="icon home icon-home"></i><span slot="title">首页</span></el-menu-item>
                    <el-menu-item class="left-nav-modi" index="/envelopes" v-if="userEdition === 'p'"><i class="icon icon-folder-open"></i><span slot="title">文件</span></el-menu-item>
                    <template v-if="userEdition === 'e'">
                        <el-submenu index="/envelopes">
                            <template slot="title"><i class="icon icon-folder-open"></i><span slot="title">文件</span></template>
                            <el-menu-item index="/envelopes"><i class="icon icon-main-menu-envelope"></i>我的</el-menu-item>
                            <el-menu-item index="/envelopes/all" v-if="permission.PAGE_ENTERPRISE_ENVELOPE_ALL"><i class="icon icon-main-menu-envelope-all"></i>全部</el-menu-item>
                        </el-submenu>
                    </template>
                    <template v-if="userEdition === 'p'">
                        <!-- <el-menu-item index="/person/seals">我的签名</el-menu-item>
                        <el-menu-item index="/person/purchase">买套餐</el-menu-item> -->
                        <el-menu-item class="left-nav-modi" index="/person/orders"><i class="icon tickets el-icon-tickets"></i><span slot="title">我的账单</span></el-menu-item>
                    </template>
                    <template v-if="userEdition === 'e'">
                        <el-menu-item class="left-nav-modi" index="/templates/enable-list" v-if="permission.PAGE_TEMPLATES"><i class="icon el-icon-menu"></i><span slot="title">业务模板</span></el-menu-item> 
                    </template>
                    <template v-if="userEdition === 'e'">
                        <el-submenu index="/enterprise">
                            <template slot="title"><i class="icon company icon-company"></i><span slot="title">企业</span></template>
                            <!-- <el-menu-item index="/enterprise/contact">通讯录</el-menu-item> -->
                            <el-menu-item index="/enterprise/member" v-if="permission.ENTERPRISE_MEMBERS_MANAGEMENT"><i class="icon icon-main-menu-members"></i>成员管理</el-menu-item>
                            <el-menu-item index="/enterprise/member" v-else><i class="icon icon-main-menu-members"></i>企业成员</el-menu-item>
                            <el-menu-item v-if="permission.PAGE_ROLES_MANAGEMENT" index="/enterprise/role-permissions"><i class="icon icon-main-menu-power"></i>权限管理</el-menu-item>
                            <el-menu-item  v-if="permission.PAGE_CONTRACT_NUMBER_SETTING" index="/enterprise/contract-number"><i class="icon icon-main-menu-count"></i>合同编号</el-menu-item>
                            <template v-if="permission.PAGE_APPLICATIONS_MANAGEMENT">
                                <el-menu-item index="/enterprise/open-api"><i class="icon icon-main-menu-application"></i>应用管理</el-menu-item>
                            </template>
                            <el-menu-item  v-if="permission.PAGE_FINANCE_MANAGEMENT" index="/enterprise/finance"><i class="icon icon-main-menu-bill"></i>账单管理</el-menu-item>
                        </el-submenu>
                        <el-submenu index="/enterprise/seals">
                            <template slot="title"><i class="icon seal icon-seal-after"></i><span slot="title">签章管理</span></template>
                            <el-menu-item index="/enterprise/seals/personal"><i class="icon icon-main-menu-person"></i>个人私章</el-menu-item>
                            <el-menu-item index="/enterprise/seals/official"><i class="icon icon-main-menu-enterprise"></i>企业印章</el-menu-item>
                            <el-menu-item v-if="permission.PAGE_SEALS_AUDIT" index="/enterprise/seals/apply"><i class="icon icon-main-menu-seal-apply"></i>印章审批</el-menu-item>
                            <el-menu-item index="/enterprise/seals/record"><i class="icon el-icon-s-order"></i>用印记录</el-menu-item>
                        </el-submenu>
                    </template>
                </el-menu>
            </div>
        </nav>
        <div class="frame-container">
            <div v-if="userEdition === 'p' && userAuthStatus !== 'PASSED'" class="auth-info">
                《中华人民共和国电子签名法》要求签署方身份真实，您还没有完成实名认证，此时签署的文件不具备法律效力，点击
                <span class="go" @click="gotoAuth" v-if="userAuthStatus==='WAITING'" >查看进度</span>
                <span class="go" @click="gotoAuth" v-else>立即认证</span>
            </div>
            <div v-if="userEdition === 'e' && enterpriseAuthStatus !== 'SENIOR_PASSED' && enterpriseAuthStatus !== 'SENIOR_NO_CERT'" class="auth-info">
                <template v-if="enterpriseAuthStatus==='SENIOR_DENY_NAME_REPEAT'">
                    <span>该企业已认证通过，若非本人，请联系相关企业人员加入该企业。若仍然存在问题，请联系人工客服021-962600</span>
                </template>
                <template v-else>
                    《中华人民共和国电子签名法》要求签署方身份真实，
                    <span v-if="enterpriseAuthStatus==='WAITING' || enterpriseAuthStatus==='WAITING_SUM'">您的企业实名认证正在审核中</span>
                    <span v-else>您的企业还没有实名认证</span>，此时签署的文件不具备法律效力，点击
                    <span class="go" @click="gotoAuth" v-if="enterpriseAuthStatus==='WAITING' || enterpriseAuthStatus==='WAITING_SUM'">查看</span>
                    <span class="go" @click="gotoAuth" v-else-if="enterpriseAuthStatus==='WAITING_SUM_CHECK'">确认打款</span>
                    <span class="go" @click="gotoAuth" v-else>立即认证</span>
                </template>
            </div>
            <router-view class="content"></router-view>
        </div>
        <el-dialog title="创建企业" width="500px" :visible.sync="createOrganizationDialog" :close-on-click-modal="false">
            <h5>请确保您输入的企业/组织机构全称是真实有效的，否则将会影响企业/组织机构的后续认证</h5>
            <span class="error">{{organizationNameError}}</span>
            <el-input v-model.trim="creatingOrganizationName" @blur="checkOrganizationNameFormat" :class="organizationNameError ? 'error-border':''">
                <template slot="prepend" placeholder="请输入要创建的企业的全称">企业名称</template>
            </el-input>
            <el-row style="text-align:right;margin-top:20px;">
                <el-button @click="closeCreateOrganizationDialog">取消</el-button>
                <el-button type="primary" :loading="creatingEnvelope" @click="reqCreateOrganization">创建</el-button>
            </el-row>
        </el-dialog>
        <!-- <el-dialog title="通知" class="epidemic-dialog" :visible.sync="epidemicDialog" :close-on-click-modal="false" @close='closeDialog'>
            <div class="dialog-container">
                <p class="epidemic-title">抗击疫情复工申请专项模板</p>
                <div class="dialog-container-info">
                    <div class="dialog-left">
                        <div>
                            大家签免费开放“抗击疫情复工申请专项模板”
                            助力全国企业用户实现复工材料在线快速签署
                        </div>
                    </div>
                    <div class="dialog-right">
                        <img :src="backgroundBg"/>
                    </div>
                </div>
                <div class="dialog-footer">
                    <div class="dialog-left">
                        <el-button type="info" plain @click="closeDialog">我知道了</el-button>
                    </div>
                    <div class="dialog-right">
                        <el-button type="primary" @click="immediateUse">立即使用</el-button>
                    </div>
                </div>
            </div>
            
        </el-dialog> -->
    </div>
</template>

<script>
import logoURL from "@images/wesign-logo-main.svg"
import backgroundBg from "@images/bg.png"
import { isOrganizationName} from "@wesign/check"
import { checkAuthStatus } from "@commons/check-status.js"
import { checkEnterpriseAuthStatus } from "@commons/check-enterprise-status.js"
import avatar from "@components/commons/avatar.vue"
import authStatusPerson from "@components/auth/auth-status-person.vue"

import { createEnvelope } from "@interfaces/envelopes/index.js"
import { createEnterprise } from "@interfaces/enterprise/enterprise.js"
import { getEnterpriseMemberInfo } from "@interfaces/enterprise/members.js"
import {getUserMessages} from "@interfaces/message-pusher/system-message.js"
import { Loading } from "element-ui"
import { getUserRoles } from "@interfaces/policy/enterprise-roles.js"
import { LoginComponentLocalInfo} from "@classes/login/login-info.js"
import { authFlow } from "@interfaces/openapi/enterprise-authentication.js"
import { startPersonAuthProcess } from '@interfaces/openapi/person-authentication.js'
import qs from "qs"

export default {
    data(){
        return {
            logoURL: logoURL,
            backgroundBg: backgroundBg,
            accountPopoverVisible: false,
            infoPopoverVisible: false,
            creating: false,
            
            //创建企业相关
            createOrganizationDialog: false, //创建企业弹框
            creatingOrganizationName: "",
            creatingEnvelope: false, //正在创建企业
            memberRole: "",
            popover: false,
            element: {
                router: true,
                active: ""
            },
            enterpriseName: "",  
            // contractsManager: ""

            collapse: false, //侧边栏模式
            epidemicDialog: false,
            localInfo: new LoginComponentLocalInfo(),
            organizationNameError: ""
        }
    },
    computed: {
        accounts() {
            let activeUserWsid = this.$store.getters.activeUserWsid
            return this.$store.getters.userAccounts.map(account => {
                let name
                let memberStatus

                if (account.enterpriseName) name = account.enterpriseName
                else name = "个人版"

                if (account.memberStatus) memberStatus = account.memberStatus
                let now = false
                if (account.userWsid === activeUserWsid)
                    now = true

                return {
                    name,
                    now,
                    enterprise: !!account.enterpriseName, //是否为企业
                    id: account.userWsid,
                    memberStatus
                }
            })
        },
        accountsLoading(){
            return this.$store.getters.userAccountsLoading
        },
        // accountsDisabled(){
        //     return this.accounts.filter(account => {
        //         if (account.memberStatus === "DISABLED"){
        //             return account
        //         }
        //     })
        // },
        accountJoined(){
            return this.accounts.filter(account => {
                if (account.memberStatus === undefined || account.memberStatus === "JOINED"){
                    return account
                }
            })
        },
        // accountsSort(){
        //     return this.accountJoined.concat(this.accountsDisabled)
        // },
        rearchResult(){
            let reg = this.enterpriseName
            return this.accountJoined.filter(account => account.name.indexOf(reg) !== -1)
        },
        activeAccount() {
            return this.accounts.find(a => a.now)
        },
        userAuthStatus(){
            return this.$store.getters.userIddtvStatus
        },
        enterpriseAuthStatus(){
            return this.$store.getters.enterpriseIddtvStatus
        },
        userName(){
            return this.$store.getters.userName
        },
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        userEdition(){
            return this.$store.getters.userEdition
        },
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        memberWsid(){
            return this.$store.getters.memberWsid
        },
        userWsid(){ 
            return this.$store.getters.userWsid
        },
        enterpriseAuthorWsid(){
            return (this.$store.getters.enterpriseAuthorWsid)
        },
        isAuthor(){
            if (this.enterpriseAuthorWsid === this.userWsid){
                return true
            } else {
                return false
            }
        },
        permission(){
            return this.$store.getters
        },
        // haveEnterprisePermission(){
        //     if (this.permission.ENTERPRISE_MEMBERS_MANAGEMENT || this.permission.PAGE_APPLICATIONS_MANAGEMENT
        //     || this.permission.PAGE_ROLES_MANAGEMENT || this.permission.PAGE_APPLICATIONS_MANAGEMENT){
        //         return true
        //     } else {
        //         return false
        //     }
        // },
        messagesLength(){
            return this.$store.getters.totalElements
        },
        activeRouter(){
            return this.$route.path
        }
    },
    // created(){
    //     this.getShowTemplatesEpidemic()
    // },
    mounted(){
        this.$store.dispatch("updateUserMessage", {
            filters: "isread=false"
        })
        
        window.addEventListener("resize", this.windowResize)

        this.windowResize()

        if (localStorage.getItem("AUTH_AUTO")){
            if (this.userEdition === "p"){
                if (localStorage.getItem("AUTH_PHONE_LOCK")){
                    this.gotoAuth({
                        phone: localStorage.getItem("AUTH_PHONE_LOCK"),
                        phonelock: true,
                        username: localStorage.getItem("AUTH_USERNAME_LOCK")
                    })
                    localStorage.removeItem("AUTH_PHONE_LOCK")
                    localStorage.removeItem("AUTH_USERNAME_LOCK")
                } else {
                    this.gotoAuth()
                }
            }
            localStorage.removeItem("AUTH_AUTO")
        }
    },
    beforeDestroy(){
        window.removeEventListener("resize", this.windowResize)
    },
    methods: {
        // getShowTemplatesEpidemic(){
        //     if (this.localInfo.showTemplatesEpidemic == false && this.userEdition === "e"){
        //         this.epidemicDialog = true
        //     } else {
        //         this.epidemicDialog = false
        //     }
        // },
        windowResize(){
            if (document.documentElement.clientWidth <= 576){
                this.collapse = true
            } else {
                this.collapse = false
            }
        },
        closeDialog(){
            this.epidemicDialog = false
            this.localInfo.setShowTemplatesEpidemic(true)
        },
        change(destinationWsid) {
            let loadingInstance = Loading.service({
                fullscreen: true,
                text: "切换中..."
            })
            
            this.$store.dispatch("changeUserAccount", destinationWsid).then(_ => {
                let oldPath = this.$route.path
                let routeName = this.$route.name
                let userWsid = this.$store.getters.activeUserWsid
                // this.getShowTemplatesEpidemic()
                this.getRoleName()
                if (/^WSID_EUSR/.test(userWsid) && routeName === "person-order"){
                    this.$router.push({
                        name: "enterprise-finance"
                    })
                } else {
                    this.$router.push("/")
                    this.$nextTick(_ => {
                        if (routeName === "envelope-detail"){
                            this.$router.push("/envelopes")
                        } else {
                            this.$router.push(oldPath)
                        }
                    })
                } 
            }).catch(err => {
                this.$message.error("切换失败")
            }).then(_ => {
                this.$nextTick(_ => {
                    loadingInstance.close()
                })
            })
        },
        getRoleName(){
            getUserRoles({
                authorWsid: this.$store.getters.activeUserWsid
            }).then(res => {
                let enterpriseRoles = res.data.data.enterpriseRoles
                // this.contractsManager = enterpriseRoles.find(enterpriseRole => enterpriseRole.name === "合同管理员")
            })
        },
        handleSelect(index, indexPath){
            let enterpriseAuthStatus = this.enterpriseAuthStatus
            if (this.userEdition === "e" && enterpriseAuthStatus && index !== "/"){
                checkEnterpriseAuthStatus(this.$router, enterpriseAuthStatus)
            }
        },
        messagesNotification(){
            this.$router.push({path: "/person/message"})
        },
        accountInfo(){
            this.infoPopoverVisible = false
            this.$router.push({path: "/user/info"})
        },
        logout() {
            this.infoPopoverVisible = false
            this.$store.dispatch("user_logout")
        },
        gotoAuth({
            phone = "",
            phonelock = "",
            username = ""
        } = {}) {
            if (this.userEdition === "p"){
                const userContact = this.$store.getters.userContact
                let query = {
                    userContact,
                    phone,
                    username,
                    phonelock
                }
                startPersonAuthProcess({
                    authModes:[],
                    presetPersonAuthentications: [{
                        name: this.userName,
                        phone:userContact
                    }],
                    returnUrl: ''
                }).then(res =>{
                    let actionUrl = res.data.data.actionUrl
                    location.href = `${actionUrl}&${qs.stringify(query)}`
                }).catch(errcon=>{

                })
            } else {
                authFlow({
                    returnUrl: `${location.origin}/wesign`
                }).then(res => {
                    let actionUrl = res.data.data.actionUrl
                    this.authActionUrl = actionUrl
                    location.href = actionUrl
                }).catch(err => {
                    if (err.response){
                        let code = err.response.data.code
                        if (code === 101){
                            this.$alert("该企业已认证通过，请勿重复操作", "提示", {
                                confirmButtonText: "知道了",
                                type: "success",
                                callback: action => {
                                    this.$store.dispatch("updateModule")
                                },
                            })
                        } else if (code === 102){
                            let developerMessage = err.response.data.data.msg
                            let erorInfo 
                            if (developerMessage.indexOf("该企业已经注册认证") != -1){
                                erorInfo = `若是本人，请检查自己账号下是否已有该企业。若非本人，请联系相关企业人员加入该企业。若仍然存在问题，请联系人工客服021-962600。`
                            } else {
                                erorInfo = ""
                            }
                            this.$alert(`<p>${developerMessage}${erorInfo}</p>`, "提示", {
                                confirmButtonText: "知道了",
                                dangerouslyUseHTMLString: true,
                                type: "warning",
                            }).then(() => {}, () => {})
                        }
                    } else {
                        this.$message.error("网络开小差了，请检查您的网络是否正或刷新页面重试")
                    }
                    console.error(err)
                })
            }
        },
        // gotoHelp(){
        //     window.open("", "_blank")
        //     // location.href=""
        // },
        async createEnvelope(envelopeFlag){
            let userIddtvStatus = this.$store.getters.userIddtvStatus
            let enterpriseAuthStatus = this.enterpriseAuthStatus
            let userWsid = this.$store.getters.activeUserWsid
            if (this.userEdition === "e" && !await checkEnterpriseAuthStatus(this.$router, enterpriseAuthStatus) || !await checkAuthStatus(this.$router, userIddtvStatus)){
                return 
            } 
            if (this.userEdition === "p" && !await checkAuthStatus(this.$router, userIddtvStatus)){
                return 
            }

            if (this.$store.getters.totalCharges === 0){
                this.$confirm("签署余额不足，请前往充值", "提示", {
                    confirmButtonText: "立即前往充值",
                    cancelButtonText: "取消",
                    callback: action => {
                        if (action === "confirm"){
                            if (this.userEdition === "p"){
                                this.$router.push({
                                    name: "person-purchase"
                                })
                            } else {
                                this.$router.push({
                                    name: "enterprise-purchase"
                                })
                            }
                        }
                    },
                    type: "warning"
                })
                return
            }

            this.creating = true
            createEnvelope({
                senderWsid: userWsid,
                envelopeFlag
            }).then(res => {
                let id = res.data.data.envelopeBasicInfo.envelopeWsid
                if (envelopeFlag === "0"){ //普通创建信封
                    this.$router.push({
                        name: "envelope-editor",
                        params: {
                            envelopeId: id
                        }
                    })
                } else { //批量发送
                    this.$router.push({
                        name: "envelope-bulk-editor",
                        params: {
                            envelopeId: id
                        }
                    })
                }
            }).catch(err => {
                this.$message.error("创建文件失败")
            }).then(_ => {
                this.creating = false
            })
        },
        openCreateOrganizationDialog() {
            let userIddtvStatus = this.$store.getters.userIddtvStatus
            checkAuthStatus(this.$router, userIddtvStatus)
            if (userIddtvStatus == "PASSED"){
                this.createOrganizationDialog = true
            } 
        },
        closeCreateOrganizationDialog() {
            this.creatingOrganizationName = ""
            this.createOrganizationDialog = false
        },
        reqCreateOrganization() {
            this.checkOrganizationNameFormat(true)

            if (this.organizationNameError){
                return
            }

            let userWsid = this.$store.getters.userWsid
            let reg = this.creatingOrganizationName
            let isEnterpriseName = this.accountJoined.find(account => account.name === this.creatingOrganizationName)
            if (this.creatingOrganizationName === ""){
                this.$message.warning("请输入完整的企业名称")
                return
            } else if (isEnterpriseName){
                this.$message.warning("你的帐号下已有该企业，请不要重复创建")
                return
            }

            this.creatingEnvelope = true
            let organizationName = this.creatingOrganizationName
            let enterpriseWsid = ""
            createEnterprise({
                name: this.creatingOrganizationName,
                authorWsid: userWsid
            }).then(res => {
                enterpriseWsid = res.data.data.enterprise.enterpriseWsid
                this.$store.dispatch("updateUserAccounts").then(_ => {
                    this.$confirm(`您成功的创建了企业${organizationName}，进入企业页面进行实名认证后，才能正常使用企业相关功能`, "提示", {
                        confirmButtonText: "立即前往认证",
                        cancelButtonText: "不了,稍后再去",
                        type: "success"
                    }).then(_ => {
                        let target = this.$store.getters.userAccounts.find(account => account.enterpriseWsid === enterpriseWsid)
                        let euser = target.userWsid
                        return this.$store.dispatch("changeUserAccount", target.userWsid)
                    }).then(_ => {
                        return this.gotoAuth()
                    }, _ => {}).then(_ => {
                        this.creatingEnvelope = false
                        this.closeCreateOrganizationDialog()
                    })
                })
            }).catch(err => {
                //TODO: 后台不支持同账户下去重
                this.creatingEnvelope = false
                if (err.response){
                    let code = err.response.data.code
                    if (code === 101){
                        this.$alert("该企业已认证，如果需要加入企业，请联系您所在企业的管理员", "提醒", {
                            type: "warning",
                            confirmButtonText: "确定",
                        }).then(_ => {
                        })
                    } else if (code === 102){
                        this.$alert("你的帐号下已有该企业，请不要重复创建", "提醒", {
                            type: "warning",
                            confirmButtonText: "我知道了",
                        }).then(_ => {
                        })
                    }
                } else {
                    this.$message.error("创建企业请求失败")
                }
                console.error(err)
            })
        },
        immediateUse(){
            this.closeDialog()
            this.$router.push("/templates/epidemic-list")
        },
        checkOrganizationNameFormat(checkNull = false){
            let organizationName = this.creatingOrganizationName
            if (organizationName === "" && !checkNull) {
                this.organizationNameError = ""
                return true
            }
            let out = isOrganizationName(organizationName)
            switch (out.code){
                case 100: this.organizationNameError = "";break
                case 101: this.organizationNameError = "请输入组织机构名称";break
                case 501: this.organizationNameError = "组织机构名称含有其他字符或含有空格";break
                case 502: this.organizationNameError = "组织机构名称长度不得小于2";break
                case 503: this.organizationNameError = "组织机构名称长度不得大于50";break 
            }
            return out.result 
        },
    },
    components: {
        avatar,
        authStatusPerson
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

@left-nav-width: 64px;
@left-nav-width-sm: 100px;
@left-nav-width-md: 150px;
@left-nav-width-lg: 200px;

@left-word-margin: 25px;
@left-word-margin-sm: 5px;
@left-word-margin-md: 10px;
@left-word-margin-lg: 20px;

@padding-sm: 0px;
@user-width: 100px;
@user-width-sm: 80px;

@user-nav-width: 150px;
@user-nav-width-sm: 130px;

@btn-sign-width: 100%;
@btn-sign-width-sm: 100%;
@btn-sign-width-md: 120px;
@btn-sign-width-lg: 160px;

@btn-sign-height: 40px;
@btn-sign-height-sm: 50px;

@btn-padding-left: 30px;
@btn-padding-left-xs: 2px;
@btn-padding-left-md: 20px;
@left-nav-padding-sm: 12px;

@left-nav-padding: 20px;
@left-sub-item-padding:40px;
@left-sub-item-padding-xs:33px;

// .left-nav-modi{
//     padding-left: @left-nav-padding !important;

//     .xs-devices({
//         padding-left: @left-nav-padding-sm !important;
//     });

//     .md-devices({
//         padding-left: @left-nav-padding !important;
//     });
// }

// .el-submenu__title{
//     padding-left: @left-nav-padding !important;

//     .xs-devices({
//         padding-left: @left-nav-padding-sm !important;
//     });
//         .md-devices({
//         padding-left: @left-nav-padding !important;
//     });
// }

.el-submenu .el-menu-item {
    min-width: 100px;
    padding-left: @left-sub-item-padding;
    .xs-devices({
        padding-left: @left-sub-item-padding-xs !important;
    });
        .md-devices({
        padding-left:@left-sub-item-padding !important;
    });
        .lg-devices({
        padding-left: @left-sub-item-padding !important;
    });
}

.auth{
    color:@color-success;
    font-size:18px;
    vertical-align:middle;
}
.unauth{
    color:@color-danger;
    font-size:18px;
}
.gray{
    background:#dcdbdb;
    position:relative;
    &:hover{
        background:#dcdbdb;
        cursor:not-allowed
    }
}
.forbid{
    position:absolute;
    top:12px;
    right:10px;
    color:#81878e;

}

.frame-main-nav{
    display: flex;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 60px;
    padding-left: @left-nav-width;
    background: @color-nav-background;
    box-shadow: @shadow-default;
    z-index: 9;

    .sm-devices({
        padding-left: @left-nav-width-sm;
    });

    .md-devices({
        padding-left: @left-nav-width-md;
    });

    .lg-devices({
        padding-left: @left-nav-width-lg;
    });

    .frame-main-nav-account{
        flex:1;
        font-size: @font-size-primary;
        display: flex;
        line-height: 60px;
        text-align: left;
        padding-left:40px;
        overflow: hidden;
        .xs-devices({
            padding-left: @left-word-margin-sm;
            font-size: @font-size-regular;
        });

        .md-devices({
            padding-left: @left-word-margin-md;
            font-size: @font-size-regular;
        });

        .lg-devices({
            padding-left: @left-word-margin-lg;
            font-size: @font-size-primary;
        });
        .frame-main-name{
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    }

    .frame-main-right{
        display: flex;
        right: 0;
        top: 0;
        align-items: center;
    }
    .icon-question{
        font-size:20px;
        vertical-align: middle;
        margin-right:3px;
    }
    .frame-main-nav-user{
        width: 150px;
        line-height: 60px;

        .sm-devices({
            width: @user-nav-width-sm;
        });
        .xs-devices({
            width: @user-nav-width-sm;
        });
        .lg-devices({
            width: @user-nav-width;
        });
        .md-devices({
            width: @user-nav-width;
        });

        .user-avatar{
            cursor: pointer;
            transition: background .3s;

            &:hover{
                opacity:.5
            }
        }

        .user-infos{
            position: absolute;
            right: 0;
            top:0;
            width: 100px;
            height: 60px;
            display:flex;
            align-items:center;

            .sm-devices({
                width: @user-width-sm;
            });
            .xs-devices({
                width: @user-width-sm;
            });
            .md-devices({
                width: @user-width;
            });
            .lg-devices({
                width: @user-width;
            });
            
            .user-name{
                padding: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                line-height: @font-size-primary;
                font-size: @font-size-primary;
                .member-role{
                    padding: 2px 5px;
                    margin-top:5px;
                    display:inline-block;
                    color:@color-main;
                    font-size: 12px;
                    line-height:18px;
                    border-radius:5px;
                    border:1px solid @color-main;
                }
            }

            .user-status{
                padding: 0;
                margin-top: 5px;
                line-height: @font-size-primary;
                font-size: @font-size-primary;
            }
        }
    }

    .frame-main-messages{
        position: relative;
        cursor: pointer;
        width: 60px;
        padding-right: 35px;
        height: 60px;
        line-height: 60px;
        color:@color-main;
        font-size:@font-size-primary;
        .sm-devices({
            padding-right: @padding-sm;
        });
        .xs-devices({
            padding-right: @padding-sm;
        });

        i{
            vertical-align: middle;
            font-size:30px;
            line-height: 60px;
        }
        .item{
            position:absolute;
            right:48px;
            top:0;
        }
    }
}

.frame-left-nav{
    z-index:10;
    position: absolute;
    top:0;
    bottom: 0;
    width: @left-nav-width;
    background: @color-nav-background;
    box-shadow: @shadow-default;
    border-right: solid 1px #e6e6e6;

    display: flex;
    flex-direction: column;

    .sm-devices({
        width: @left-nav-width-sm;
    });

    .md-devices({
        width: @left-nav-width-md;
    });

    .lg-devices({
        width: @left-nav-width-lg;
    });

    .frame-logo{
        cursor: pointer;
        display: block;
        margin: auto;
        width: 50px;
        height: 60px;

        .sm-devices({
            width: 60px;
        });

        .md-devices({
            width: 80px;
        });
    }

    .frame-btn-start-sign{
        display: block;
        width: @btn-sign-width;
        height: @btn-sign-height;
        margin: 20px auto;
        font-size: 12px;
        border-radius: 0;
        text-align: center;
        padding: 0;

        .sm-devices({
            width: @btn-sign-width-sm;
            height: @btn-sign-height-sm;
        });

        .md-devices({
            width: @btn-sign-width-md;
            font-size: @font-size-primary;
            border-radius: 8px;
        });

        .lg-devices({
            width: @btn-sign-width-lg;
        });

        .icon{
            display: inline !important;
        }
    }

    .icon{
        padding-right:10px;
    }

    .nav-container{
        flex: 1;
        overflow: auto;
    }
}

.frame-container{
    position: absolute;
    display:flex;
    flex-direction: column;
    top:60px;
    left: @left-nav-width;
    right: 0;
    bottom: 0;
    overflow-y: auto;
    overflow-x:hidden;
    
    .sm-devices({
        left: @left-nav-width-sm;
    });

    .md-devices({
        left: @left-nav-width-md;
    });

    .lg-devices({
        left: @left-nav-width-lg;
    });

    .auth-info{
        text-align: center;
        line-height: 25px;
        padding: 10px 40px;
        padding: 8px 40px;
        color:@color-danger;
        background: #fef0f0;

        .go{
            cursor: pointer;
            color: @color-main;
        }
    }

    .content{
        position: relative;
        flex:1;
        padding: 0 40px;
    }
}

.btn-account-change{
    margin-left: 25px;
    height: 20px;
    padding: 1px 10px;
    font-size: @font-size-regular;
    
    .xs-devices({
        margin-left: @left-word-margin-sm;
        });
    .sm-devices({
        margin-left: @left-word-margin-sm;
        });
    .md-devices({
        margin-left: @left-word-margin-md;
    });

    .lg-devices({
        margin-left: @left-word-margin-lg;
    });

    i{
        margin-left: 5px;
    }
}

</style>

<style lang="less">
@import "~@styles/variable.less";

@notice-padding: 0;
@notice-padding-sm: 20px;
@notice-padding-lg: 40px;
@notice-padding-md: 40px;

@left-nav-padding-sm: 12px;
@left-nav-padding: 20px;

@icon-padding: 10px;

.wesign-popper-account-list{
    position: relative;
    padding:0;
    min-width: 200px;
    width: initial !important;

    .create-enterprise{
        color: @color-success;
        cursor:pointer;
        padding: 10px 40px 10px 20px;
        line-height: 24px;
        font-size:@font-size-primary;
        border-bottom: 1px solid @color-border-segment;

        &:hover{
            background: @color-success;
            color: white;
        }
    }
    .loading-box{
        padding: 10px 40px 10px 20px;
        line-height: 24px;
    }
    ul.account-list{
        max-height: 400px;
        overflow-y: auto;
        list-style: none;
        padding:0;
        margin:0;

        li{
            cursor:pointer;
            padding: 10px 40px 10px 20px;
            line-height: 24px;
            font-size:@font-size-primary;
            border-bottom: 1px solid @color-border-segment;
            position:relative;
            &:last-child{
                border:none;
            }

            i.active{
                position: absolute;
                top:12px;
                right:10px;
            }

        }
        .normal{
            &.active{
                color: @color-main;
            }

            &:hover, &.active:hover{
                background: @color-main;
                color: white;
            }
        }
    }
}

.account-info-popper-class{
    padding:0;
    min-width: 200px;
    width: initial !important;
    transform: translate(30px, -17px);

    ul.account-list{
        list-style: none;
        padding:0;
        margin:0;

        li{
            cursor:pointer;
            padding: 10px 40px 10px 20px;
            line-height: 24px;
            font-size:@font-size-primary;;

            &:hover{
                background: #0c7ffc;
                color: white;
            }
            
            i{
                position: absolute;
                right:10px;
            }

        }
    }
}
.frame-left-nav .el-menu{
    border-right:0;
    background:@color-nav-background;
}
.default-account{
    position:absolute;
    top:2px;
    font-size:@font-size-info;
    border-radius:15px;
    padding:0 2px;
}
.envelope-send-type-list ul li{
    cursor:pointer;
}
.search-enterpeise{
    left: 5%;
    width: 90%;
    position: relative;
    margin: 10px 0;
}
.question{
    cursor:pointer;
    padding: 18px 40px;

    .sm-devices({
        padding-right: @notice-padding-md;
        padding-left: @notice-padding;
    });
    .xs-devices({
        padding-right: @notice-padding-sm;
        padding-left: @notice-padding;
    });
    .md-devices({
        padding-right: @notice-padding-md;
        padding-left: @notice-padding;
    });
    .lg-devices({
        padding-right: @notice-padding-lg;
        padding-left: @notice-padding;
    });

    &:hover,&:active{
        color:@color-main
    }
} 

// .el-submenu__title{
//     padding-left: @left-nav-padding !important;
//     .xs-devices({
//         padding-left: @left-nav-padding-sm !important;
//     });
//     .md-devices({
//         padding-left: @left-nav-padding !important;
//     });
// }

.frame-left-nav .icon{
    padding-right: @icon-padding;
    display: inline;
    
    .sm-devices({
        padding-right: @icon-padding !important;
        display: none;
    });

    .md-devices({
        padding-right: @icon-padding !important;
        display: inline;
    });
}
.epidemic-title{
    font-size:30*@px;
    text-align:center;
    color:#000;
    font-weight: bold;
}
.dialog-container{
    img{
        width: 100%;
    }
    .dialog-container-info{
        display: flex;
        justify-content: space-between;
        margin:30px auto 0 auto;
        .dialog-left{
            flex: 1;
            max-width:330px;
            font-size: 16px;
            text-indent: 30px;
            line-height: 25px;
        }
        .dialog-right{
            flex: 1;
        }
    }
    .dialog-footer{
        display: flex;
        justify-content: space-between;
        margin:30px auto 0 auto;
        .dialog-left{
            flex: 1;
            max-width:330px;
            text-align: center;
            button{
                width: 200px
            }
        }
        .dialog-right{
            flex: 1;
            text-align: center;
            button{
                width: 200px
            }
        }
    }
}
.error{
    color:@color-danger;
    display: inline-block;
    line-height: 25px;
}
</style>
<style lang="less">
@import "~@styles/variable.less";
.error-border .el-input__inner{
    border-color:@color-danger;
}
.envelope-send-type-list{
    min-width:80px !important;
    margin-left:4px !important;
    margin-right:0 !important;
    outline:none;
}
.envelope-send-type-list.el-popper{
    margin-top:0px !important;
    margin-left:0px !important;
    padding:6px 0;
}
.envelope-send-type-list.el-popper ul li{
    padding:5px;
    color:#323c47;
    font-weight:bold
}
.envelope-send-type-list.el-popper ul li p{
    color:#81878e;
    font-weight:normal;
}
.envelope-send-type-list.el-popper ul li:hover, .envelope-send-type-list.el-popper ul li:active{
    background:#e7f2ff;
}
.el-menu-item.is-active {
    background:#d8ecff;
    
}
.el-menu--popup{
    .icon{
        padding-right:10px;
    }
}
.epidemic-dialog .el-dialog{
    width: 740px;

}
.epidemic-dialog .el-dialog__body{
    padding: 0 20px 30px 20px!important;
}
</style>
