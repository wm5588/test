<!--
    @id        page-person-auth
    @desc      个人实名认证主页
    @level     page：页面组件
    @author    周雪梅
    @date      2019-02-27 14:20:51
-->
<template>
    <div class="wrap">
        <div class="main-container">
            <h2 class="authentication-title">企业认证</h2>
            <div class="authentication-container" v-if="authenticationEnterprise">
                <div class="authentication-center-box">
                    <p class="authentication-resulut-title">认证结果</p>
                    <p><i class="icon-notice wait icon"></i></p>
                    <p class="await-title">签约方信息验证不一致</p>
                    <div @click="cancel" class="underline">取消</div>
                </div>
                <div class="authentication-error-box">
                    <div class="contact-info-box">
                        <p>签约方名称：{{this.$store.state.enterpriseName}}</p>
                        <p>统一社会信用代码：{{this.$store.state.unifiedSocialCode}}</p>
                        <p class="hint">注：统一社会信用代码是多证合一的</p>
                    </div>
                    <p class="bold">签约方信息验证不一致怎么办？</p>
                    <div class="authentication-error-list-box">
                        <p class="item">请检查本次提交的企业名称和“统一社会信用代码”与在工商登记的是否一致</p>
                    </div>
                </div>
            </div>
            <div class="authentication-container" v-if="!authenticationEnterprise">
                <div class="authentication-center-error-box">
                    <p class="authentication-resulut-title">认证结果</p>
                    <p><i class="icon-refuse2 icon error"></i></p>
                    <p class="auth-await-title error">认证失败</p>
                    <p class="reason">原因:签约方信息验证不一致，统一社会信用代码不一致</p>
                    <p class="hint">请返回重新认证</p>
                    <el-button type="primary" class="auth-result-btn" @click="goBack">返回</el-button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import querystring from "querystring"
export default {
    data(){
        return {
            returnUrl: "",
            authenticationEnterprise: true
        }
    },
    created(){
        let query = location.search.slice(1)
        query = querystring.parse(query)

        this.returnUrl =  decodeURIComponent(query.returnUrl) || "DEFAULT"
    },
    methods:{
        goBack(){
            if(this.returnUrl && this.returnUrl!=="DEFAULT"){
                location.href = `${this.returnUrl}`
            } else {
                window.location.href="about:blank";
                window.close()
            }
        },
        cancel(){
            this.authenticationEnterprise = false
        },    
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
@media screen and (max-width: 780px){
    .main-container{
        top:0px !important;
    }
}
.main-container{
    max-width:600px;
    position:relative;
    top:70px;
    margin:0 auto;
    overflow-x:hidden;
    .authentication-title{
        text-align:center;
    }

    .authentication-container{
        .info-block-default;
        max-width:600px;
        min-height: 400px;
        margin:0 auto;
        padding:15px;
        text-align:center;
    }
}
.icon{
    font-size:@font-size-largger
}
.await{
    color:@color-info;
}
.wait{
    color:@color-warning
}
.await-title{
    font-size:@font-size-regular !important;
    line-height:25px;
}
.authentication-result-btn{
    width:100%;
    max-width:300px;
    margin:40px 0;
    cursor:pointer;
}

.authentication-resulut-title{
    font-size:@font-size-large !important;
}
.hint{
    color:@color-font-regular;
    font-size:@font-size-info;
    span{
        padding-top:8px;
        display:inline-block;
    }
}
.authentication-center-box{
    text-align:center;
    padding-bottom:15px;
    p{
        padding-top:15px;
    }
    border-bottom:1px solid #ccc
}

.authentication-center-error-box{
    text-align:center;
    padding-bottom:15px;
    p{
        padding-top:15px;
    }
    .error{
        color:@color-danger;
    }
    .reason{
        font-size:@font-size-info!important;
    }
}
.authentication-error-box{
    width:90%;
    max-width:450px;
    min-width:300px;
    margin:0 auto;
    text-align: left;
    padding-bottom:15px;
}
.contact-info-box{
    padding-top:15px;
    font-size:12px;
    p{
        line-height:20px;
    }
}
.bold{
    font-weight:bold;
    padding:15px 0
}
.underline{
    text-decoration:underline;
    height:40px;
    line-height:40px;
    cursor:pointer;
}
.underline:hover,.underline:active{
    color:@color-main
}
.authentication-error-list-box{
    font-size:@font-size-info;
    line-height:20px;
}
.authentication-title{
    padding: 20px 0;
}
</style>
