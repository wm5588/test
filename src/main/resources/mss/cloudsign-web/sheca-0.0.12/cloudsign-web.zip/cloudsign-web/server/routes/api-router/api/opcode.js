const exit = require("$exit")
let askend = require('$HMAC').askend

/**
 * ----------------------------------------------------
 * @path   /api/opcode
 * @method POST
 * @desc   获取业务操作码
 * @author 周雪梅,陈曦源
 * @date   2018-02-03 22:01:02
 * ----------------------------------------------------
 */
exports.post = function (req, res, next) {
    let {
        captcha,
        contact,
        service
    } = req.body

    askend({
        reqMethod: 'post',
        reqURL: 'wesign-mss-identity://opcode',
        reqData: {
            captcha,
            contact,
            service
        }
    }).then(resp => {
        exit(res, resp.data)
    }).catch(err => {
        /**
         * @description 业务操作码可能出现的错误
         * @code     
         *      100 通用内部错误
         *      101 验证码错误
         *      102 获取验证码繁忙
         */
        let faultCode = 100
        let faultMessage = "通用内部错误"
        if (err.response){
            let status = err.response.status
            if (err.response.data){
                let code = err.response.data.code
                switch (code){
                    case "100220101"://后台为验证码不存在
                        faultCode = 101
                        faultMessage = "验证码错误"
                        break
                    case "100220102": 
                        faultCode = 102
                        faultMessage = "验证码错误"
                        break
                }
            }
            exit.error(res, undefined, faultCode, faultMessage, {status, errorData: err})
        } else {
            next(err)
        }
    })
}
