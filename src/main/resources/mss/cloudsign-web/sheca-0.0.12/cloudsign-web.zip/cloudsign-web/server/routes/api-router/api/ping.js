const exit = require("$exit")
const askend = require("$HMAC").askend

/**
 * ----------------------------------------------------
 * @path   /api/ping
 * @method GET
 * @desc   ping，用于检测网络是否存活
 * @author 陈曦源
 * @date   2018-07-20 09:56:17
 * ----------------------------------------------------
 */
exports.get = function (req, res, next) {
    res.send(200)
}
