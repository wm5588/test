import loadingPage from "@page-components/openapi-authorization/loading.vue"
import phoneAuth from "@components/openapi-authorization-auth/person/person-phone.vue"
import faceAuth from "@components/openapi-authorization-auth/person/person-face.vue"
import phoneFaceAuth from "@components/openapi-authorization-auth/person/person-phone-face.vue"
import zhimaAuth from "@components/openapi-authorization-auth/person/person-zhima.vue"
import manualAuth from "@components/openapi-authorization-auth/person/person-manuall-check.vue"
import authResult from "@components/openapi-authorization-auth/verifications/auth-result.vue"

let routerConfig = {
    mode: "history",
    base: "/openapi-authorization",
    routes: [
        {
            path: "/",
            meta: {
                title: ""
            },
            component: loadingPage
        },
        {
            path: "/verification",
            name: "verification",
            meta: {
                title: "注册"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/openapi-authorization/verification.vue"))
                }, "async-verification")
            }
        },
        {
            path: "/authentication",
            name: "authentication",
            meta: {
                title: "身份验证"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/openapi-authorization/authentication.vue"))
                }, "async-authentication")
            }
        },
        {
            path: "/enterprise-authentication",
            name: "enterprise-authentication",
            meta: {
                title: "身份验证"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/openapi-authorization/enterprise-authentication.vue"))
                }, "async-enterprise-authentication")
            }
        },
        {
            path: "/person",
            name: "person-auth",
            meta: {
                title: "个人实名认证",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/openapi-authorization/person-auth-nav.vue"))
                }, "person-auth")
            },
            children: [
                {
                    path: "",
                    name:"phone-auth",
                    redirect: "/person/phone-auth",
                },
                {
                    path: "phone-auth",
                    name:"phone-auth",
                    component: phoneAuth,
                },
                {
                    path: "zhima-auth",
                    name:"zhima-auth",
                    component: zhimaAuth,
                },
                {
                    path: "face-auth",
                    name:"face-auth",
                    component: faceAuth,
                },
                {
                    path: "phone-face-auth",
                    name:"phone-face-auth",
                    component: phoneFaceAuth,
                },
                {
                    path: "manual-auth",
                    name:"manual-auth",
                    component: manualAuth,
                },
            ]
        },
        {
            path: "/result",
            component: authResult,
        },
        {
            path: "/enterprise",
            name: "enterprise-auth",
            meta: {
                title: "企业实名认证",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/openapi-authorization/enterprise-auth.vue"))
                }, "async-enterprise-auth")
            } 
        },
    ]
}

export default routerConfig