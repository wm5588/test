import { getTemplateDate, updateTemplate} from "@interfaces/templates/bsts.js"
function initData(){
    return {
        templateConfig: null,
        templateId: "",
        templateName: ""
    }
}

const module_TemplateData = {
    state: initData(),
    actions: {
        async getTemplateData({state, dispatch}, templateId){
            // await dispatch("clearTemplateData", templateId)
            return getTemplateDate({
                bstWsid: templateId
            }).then(res => {
                let bst = res.data.data.bst
                let templateConfig = JSON.parse(bst.configContent)
                state.templateConfig = templateConfig
                state.templateId = templateId
                state.templateName = bst.name
            })
        },
        updateTemplateData({state}, params){
            return updateTemplate({
                bstWsid: params.templateId,
                configContent: params.configContent
            }).then(res => {
                let bst = res.data.data.bst
                let templateConfig = JSON.parse(bst.configContent)
                state.templateConfig = templateConfig
                state.templateId = params.templateId
            })
        },
        // clearTemplateData({state}, templateId){
        //     if (templateId != state.templateId){
        //         state.templateConfig = new templateConfig()
        //     }
        // }
    }
}

export default module_TemplateData
