let localStorage = window.localStorage
let TEST_KEY = "__test__"

try {
    localStorage.setItem(TEST_KEY, "test")
    let data = localStorage.getItem(TEST_KEY)
    if (data !== "test"){
        needLocalStorage()
    }
} catch (e){
    needLocalStorage()
}

function needLocalStorage(){
    alert("本应用暂不支持无痕模式，请关闭无痕模式后访问")
}