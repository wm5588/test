const errors = [
    //通用错误
    {code: 100, name: "UNKNOWN", message: "未知错误"},
    {code: 101, name: "TIMEOUT", message: "请求超时"},
    //短信验证码
    {code: 100500205, name: "SMS_PHONE_IN_BLACKLIST", message: "手机号码在黑名单中"},
    {code: 100500207, name: "SMS_SEND_FAIL", message: "发送失败"},
    {code: 100500208, name: "SMS_FREQUENTLY", message: "短信验证码发送频繁"},
    {code: 100500210, name: "SMS_IDENTIFY_AMOUNT_OUT_LIMIT", message: "验证码今日超过数目"},
    {code: 100500213, name: "SMS_FREQUENTLY_DIY", message: "后台控制的发送频繁"},
    {code: 100500706, name: "VOICE_IDENTIFY_AMOUNT_OUT_LIMIT ", message: "验证码今日超过数目 "},
    {code: 100500707, name: "VOICE_PHONE_IN_BLACKLIST", message: "手机号码在黑名单中"}
]

//错误code码
const ERROR_CODES = {}
const ERROR_CODE_MAP = {}
errors.forEach(e => {
    ERROR_CODES[e.name] = e.code
    ERROR_CODE_MAP[e.code] = e
})

class CodeError extends Error{
    constructor(code, message, data){
        super(message)
        this.code = code
        this.data = data
    }
}

function createErrorByCode(code, data = null){
    let e = ERROR_CODE_MAP[code]
    if (!e) e = ERROR_CODE_MAP[ERROR_CODES.UNKNOWN]
    return new CodeError(e.code, e.message, data)
}

export default CodeError
export {
    ERROR_CODES,
    createErrorByCode,
    CodeError,
}