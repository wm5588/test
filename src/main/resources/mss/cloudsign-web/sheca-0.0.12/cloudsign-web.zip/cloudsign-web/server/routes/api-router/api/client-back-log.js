const log4js = require("log4js")
const exit = require("$exit")

/**
 * ----------------------------------------------------
 * @path   /api/client-back-log
 * @method GET
 * @desc   前端日志回传,用于收集埋点数据,分析错误根源
 * @author 陈曦源
 * @date   2019-09-21 14:06:03
 * ----------------------------------------------------
 */
exports.post = function (req, res, next) {
    let body = req.body
    log4js.getLogger("clientBack").info(`[${req.cookies.DeviceId}] ${body.type} - - ${JSON.stringify(body.content)}`)
    exit(res)
}