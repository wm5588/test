let otherPages = []

window.addEventListener("message", e => {
    //判断类型是否正确
    try {
        if (!e.data.type) return
    } catch (e){
        return
    }

    let type = e.data.type

    if (type === "REGISTER"){
        if (otherPages.indexOf(e.source) < 0){
            otherPages.push(e.source)
        }
    }
}, false)

function operationComplete(operation){
    /**
     * type: 完成的操作
     * REVOKE          撤销签署
     * 
     * SIGN    签署完成
     * REJECTE         拒绝签署
     * 
     * AUDIT_PASS       审核通过
     * AUDIT_NOTPASS    审核不通过
     */
    if (operation === "REVOKE"
        || operation === "SIGN"
        || operation === "REJECTE"
        || operation === "AUDIT_PASS"
        || operation === "AUDIT_NOTPASS"){
        otherPages.forEach(w => {
            w.postMessage({type: "OPERATION_COMPLETE", operation}, "*")
        })
    }
}

export default {
    operationComplete
}

export {
    operationComplete
}