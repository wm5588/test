function testFileType(type, file){
    let typesArray = type.split(",").map(type => type.trim()).filter(type => type).map(type => {
        if (/^\./.test(type)){ //为后缀
            return {
                target: "name", //检查名称
                regExp: new RegExp(`${type.replace(".", "\\.")}$`, "i")
            }
        } else { //为MIME类型
            if (/\/\*$/){ //泛匹配
                return {
                    target: "type", //检查名称
                    regExp: new RegExp(`^${type.replace("*", "\\S+")}$`, "i")
                }
            } else {
                return {
                    target: "type", //检查名称
                    regExp: new RegExp(`^${type}$`, "i")
                }
            }
        }
    })

    return typesArray.some(test => {
        return test.regExp.test(file[test.target])
    })
}

function testSize(size, file){
    return file.size < size
}

export default {
    install(Vue, options){
        Vue.directive("file-drop", {
            bind(el, options){
                el.addEventListener("dragenter", function(e){
                    e.preventDefault()
                }, false)
                el.addEventListener("dragover", function(e){
                    e.preventDefault()
                }, false)

                el.addEventListener("drop", function(e){
                    e.stopPropagation()
                    e.preventDefault()

                    let size = options.value.size 
                    let type = options.value.type
                    let handle = options.value.handle

                    let err = ""
                    let files = Array.from(e.dataTransfer.files).filter(file => {
                        if (type && !testFileType(type, file)){
                            if (!err) err = "ERROR_TYPE"
                            return false
                        } else if (size && !testSize(size, file)){
                            if (!err) err = "ERROR_SIZE"
                            return false
                        } else {
                            return true
                        }
                    })
                    if (files.length > 0) err = ""
                    handle(err, files)
                }, false)
            },
            unbind(el, options){
                el.removeEventListener("drop", options.value)
            }
        })
    }
}
