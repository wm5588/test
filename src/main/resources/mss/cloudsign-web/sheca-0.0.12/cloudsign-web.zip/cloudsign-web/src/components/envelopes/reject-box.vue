<template lang="html">
  <el-dialog 
	  title="拒签" 
	  size="tiny"
	  :visible.sync="dialogRejectVisible"
	  :modal-append-to-body="false"
    @close="cancel">
        <div class="message-cont">
          <p v-if="retitle">{{retitle}}</p>
        </div>
        <el-input
          type="textarea"
          :rows="4"
          size = "small"
          resize= "none"
          :placeholder="placeholder" 
          v-model="message">
        </el-input>
        <span slot="footer" class="dialog-footer">
          <el-button @click="cancel">取 消</el-button>
          <el-button type="primary" @click="submit">确 定</el-button>
        </span>
	</el-dialog>
    <!--<modal @close-modal='close' :title='recipienttitle' width='400px' height='300px'>
        <div class="message-cont">
           <p v-if="retitle">{{retitle}}</p>
            <textarea resizeable="false" :placeholder="placeholder"  v-model="message"></textarea>
        </div>
        <div class="btn-cont">
            <span v-if="cancelbtn" class='btn cancel' @click='cancel'>取消</span>
            <span v-if="submitbtn" class='btn ok' @click='verify'>确认</span>
        </div>

    </modal>-->
</template>

<script>
import { envelope_reject } from '@interfaces/envelopes/reject.js';
import modal from '../modal/modal.vue'
export default{
  props:{
    envelopeId:{
      type:String,
      required:true
    },
    recipientId:{
      type:Number,
      required:true
    },
    dialogRejectVisible:{
      default:false
    },
   
    retitle:{
      type:String
    },
    placeholder:{
        type:String,
        default:'请输入拒签理由'
      },
    
  },
  data(){
    return {
      message: '合同有误，拒绝签署此合同'
    }
  },
 
  methods:{
     close(){
        this.$emit('cancel');
      },
      cancel(){
        this.$emit('cancel');
      },
      submit(){
        this.$emit('submit',this.message);
      }
    
  },
  components:{
    modal
  }

}
</script>

<style scoped>
  .message-cont{
        text-align: center;
        padding: 10px 0;
        margin-top: -20px;
    }

    .message-cont .title{
      text-align:center;
      font-size:18px;
    }

    .message-cont p{
        text-wrap:wrap;
        text-align:left;
        font-size:14px;
        
    }

    /*.message-cont textarea{
        resize: none;
        height: 90px;
        width: 90%;
        text-align:left;
        font-size:14px;
        margin-top:12px;
    }

    .btn-cont{
        position: absolute;
        border-top:1px #e9e9ea solid;
        bottom: 0;
        left: 0;
        right: 0;
        padding:15px;
        text-align:center;
    }
    .btn{
        padding: 10px 30px;
        cursor: pointer;
        font-size: 16px;
        display:inline-block;
    }
    .cancel{
        border: 1px #c1c7d4 solid;
        color: #91969d;
        margin-right:25px;
    }
    .cancel:hover{
        background-color: #c1c7d4;
        color: #505255;
    }
    .ok{
        color: #fff;
        background-color: #ff6700;
    }*/
</style>
