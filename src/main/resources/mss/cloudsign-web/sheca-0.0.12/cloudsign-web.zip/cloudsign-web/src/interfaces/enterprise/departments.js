import axios from "@interfaces/axios.js"
import SparkMD5 from "spark-md5"

/**
 * ----------------------------------------------------
 * @path   api/enterprises/:enterpriseWsid/departments
 * @method GET
 * @desc   查询企业部门列表
 * @author 周雪梅
 * @date   2018-05-08 10:20:04
 * ----------------------------------------------------
 */
export function getDepartments(obj) {
    let {
        enterpriseWsid,
        fields,
        filters,
        offset = 0,
        limit = 1000,
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/departments`, {
        params: {
            fields,
            filters,
            offset,
            limit,
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/departments
 * @method POST
 * @desc   创建一个企业部门
 * @author 周雪梅
 * @date   2018-05-08 10:20:08
 * ----------------------------------------------------
 */
export function createDepartments(obj) {
    let {
        enterpriseWsid,
        name,
        parentWsid,
        avatarFileWsid,
        description
    } = obj

    return axios.post(`/api/enterprises/${enterpriseWsid}/departments`, {
        name,
        parentWsid,
        avatarFileWsid,
        description
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/departments/:departmentWsid
 * @method PATCH
 * @desc   修改指定企业部门
 * @author 周雪梅
 * @date   2018-05-08 10:20:13
 * ----------------------------------------------------
 */
export function modifyDepartemt(obj){
    let {
        enterpriseWsid,
        departmentWsid,
        name,
        description,
        avatarFileWsid
    } = obj

    return axios.patch(`/api/enterprises/${enterpriseWsid}/departments/${departmentWsid}`, {
        name,
        description,
        avatarFileWsid
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/departments/:departmentWsid
 * @method PATCH
 * @desc   删除指定企业部门
 * @author 周雪梅
 * @date   2018-05-08 10:20:18
 * ----------------------------------------------------
 */
export function deleteDepartemt(obj){
    let {
        enterpriseWsid,
        departmentWsid,
    } = obj

    return axios.delete(`/api/enterprises/${enterpriseWsid}/departments/${departmentWsid}`)
}


/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/departments/:departmentWsid/members/:memberWsid
 * @method PATCH
 * @desc   修改企业某个部门中某个成员的详细信息
 * @author 周雪梅
 * @date   2018-05-08 10:20:23
 * ----------------------------------------------------
 */
export function modifyDepartemtMemberDetails(obj){
    let {
        enterpriseWsid,
        departmentWsid,
        memberWsid,
        staffNo,
        status
    } = obj

    return axios.patch(`/api/enterprises/${enterpriseWsid}/departments/${departmentWsid}/members/${memberWsid}`, {
        staffNo,
        status
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/departments/:departmentWsid/members/:memberWsid
 * @method GET
 * @desc   查询企业某个部门中某个成员的详细信息
 * @author 周雪梅
 * @date   2018-05-08 10:20:27
 * ----------------------------------------------------
 */
export function getDepartemtMemberDetails(obj){
    let {
        enterpriseWsid,
        departmentWsid,
        memberWsid
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/departments/${departmentWsid}/members/${memberWsid}`)
}


/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/departments/:departmentWsid/members
 * @method GET
 * @desc   查询指定企业部门下成员列表
 * @author 周雪梅
 * @date   2018-05-08 10:20:31
 * ----------------------------------------------------
 */
export function getDepartemtMemberList(obj){
    let {
        enterpriseWsid,
        departmentWsid,
        fields = null,
        filters = null,
        offset = 0,
        limit = 20
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/departments/${departmentWsid}/members`, {
        params: {
            fields,
            filters,
            offset,
            limit,
        }
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/departments/:departmentWsid/members
 * @method PATCH
 * @desc   创建一个企业部门成员
 * @author 周雪梅
 * @date   2018-05-08 10:20:37
 * ----------------------------------------------------
 */
export function createdDepartemtMember(obj){
    let {
        enterpriseWsid,
        departmentWsid,
        name,
        account,
        password
    } = obj
    password = SparkMD5.hash(password)
    return axios.post(`/api/enterprises/${enterpriseWsid}/departments/${departmentWsid}/members`, {
        name,
        account,
        password
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/departments/:departmentWsid/members/:memberWsid/transfer
 * @method POST
 * @desc   转移企业某个部门的某个成员到其他部门
 * @author 周雪梅
 * @date   2018-08-28 21:15:55
 * ----------------------------------------------------
 */
export function memberTransfer(obj) {
    let {
        enterpriseWsid,
        departmentWsid,
        memberWsid,
        existedDepartments
    } = obj
    
    return axios.post(`/api/enterprises/${enterpriseWsid}/departments/${departmentWsid}/members/${memberWsid}/transfer`, {
        existedDepartments
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/departments/:departmentWsid/members/transfer
 * @method POST
 * @desc   转移企业多个成员到某个部门中
 * @author 周雪梅
 * @date   2018-08-22 14:53:33
 * ----------------------------------------------------
 */
export function transferMembersToDepartment(obj) {
    let {
        enterpriseWsid,
        departmentWsid,
        members
    } = obj
    
    return axios.post(`/api/enterprises/${enterpriseWsid}/departments/${departmentWsid}/members/transfer`, {
        members
    })
}