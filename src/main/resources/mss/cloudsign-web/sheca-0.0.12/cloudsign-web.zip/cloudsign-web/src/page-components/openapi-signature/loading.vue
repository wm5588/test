<template>
    <div></div>
</template>

<script>
import { getSessionData, getSessionBySecurityToken } from "@interfaces/user/sessions.js"
import { getUserAccounts, changeSession, getUserData } from "@interfaces/user/user.js"

export default {
    data(){
        return {
            loading: true,
            //判断是否有用户登录,且可以切换过来
            isLogin: false,
            accounts: []
        }
    },
    computed: {
        stateData(){
            return this.$store.state
        },
    },
    mounted(){
        this.$store.commit("loadURLData", this.$route.query)

        let loading = this.$loading({
            lock: true,
            text: "加载数据中",
            spinner: "el-icon-loading",
            background: "rgba(0, 0, 0, 0.3)"
        })

        //没有签署，前往短信登录页面
        this.checkUserIfLogin().then(_ => {
            //切换
            if (!this.isLogin){
                return this.checkCouldFreeLogin()
            }
        }).then(_ => {
            //已登录，前往干事情的页面
            if (this.isLogin){
                let envelopeWsid = this.$store.state.envelopeWsid
                let pageCallback = decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")
                let selectedAuthTypes = this.$route.query.selectedAuthTypes
                let enableNoAppearance = this.$route.query.enableNoAppearance
                let enableSimpleDisplay =  this.$route.query.enableSimpleDisplay
                let appId = this.$route.query.appId
                if (this.$store.state.type === "SIGN"){
                    location.href = `/to-signature?envelopeWsid=${envelopeWsid}&action=SIGN&enableNoAppearance=${enableNoAppearance}&enableSimpleDisplay=${enableSimpleDisplay}&selectedAuthTypes=${selectedAuthTypes}&appId=${appId}&username=${this.stateData.username}&phone=${this.$route.query.phone}&pageCallback=${pageCallback}`
                } else if (this.$store.state.type === "CHECK"){
                    location.href = `/to-signature?envelopeWsid=${envelopeWsid}&action=CHECK&enableNoAppearance=${enableNoAppearance}&enableSimpleDisplay=${enableSimpleDisplay}&selectedAuthTypes=${selectedAuthTypes}&appId=${appId}&username=${this.stateData.username}&phone=${this.$route.query.phone}&pageCallback=${pageCallback}`
                }
            } else {
                this.$router.push({
                    name: "login",
                    query: this.$route.query
                })
            }
            loading.close()
        })
    },
    methods: {
        async checkUserIfLogin(){
            //测试数据
            let targetUserId = this.$store.state.targetUserWsid //目标用户数据
            
            try {
                let session = await getSessionData().then(res => res.data.data.session)
                let ifCanChange = true //是否可切换
                if (session.sessionScopes){
                    //OPEN_PARTICIPANT_HANDLING 才能用
                    if (!session.sessionScopes.find(_ => _ === "OPEN_PARTICIPANT_HANDLING")){
                        throw new Error("ERROR_NEED_OPEN_PARTICIPANT_HANDLING")
                    }
                    
                    //免登陆不能切换账户
                    ifCanChange = false
                }

                let userId = session.userWsid
                await getUserAccounts({
                    userWsid: userId,
                    limit: 10000
                }).then(res => {
                    let accounts = res.data.data.accounts
                    this.accounts = accounts
                })

                //检测联系方式是否正确
                let userInfo = await getUserData({
                    userWsid: userId,
                }).then(res => {
                    return res.data.data.userInfo.user
                })

                if (userInfo.phone === this.$store.state.account
                    || userInfo.email === this.$store.state.account){
                    let enterpriseName = this.stateData.enterpriseName

                    if (/WSID_EMEM_/.test(targetUserId)){
                    //如果为memberWsid,寻找EUSER
                        let account = this.accounts.find(account => account.enterpriseName === enterpriseName && account.idttvStatus === "SENIOR_PASSED")
                        if (account){
                            targetUserId = account.userWsid
                        }
                    }
                    
                    //没有设置目标用户ID就需要登录
                    if (!targetUserId){
                        let account = this.accounts.find(account => account.enterpriseName === enterpriseName && account.idttvStatus === "SENIOR_PASSED")
                        if (account){
                            targetUserId = account.userWsid
                        } else {
                            targetUserId = userId
                        }
                    }
                }

                //检查是否登录
                if (targetUserId === userId){
                    this.isLogin = true
                    
                } else if (ifCanChange && this.accounts.some(accout => accout.userWsid === targetUserId)){
                    //账户包含，进行账户切换
                    await changeSession({
                        userWsid: userId, 
                        destinationWsid: targetUserId
                    })
                    this.isLogin = true
                }
            } catch (e) {
                console.error(e)
                //未登录
            }

            //判断签署还是审核
            // let envelopeWsid = this.$store.state.envelopeWsid
            // let pageCallback = decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")

            // if (this.$store.state.type === "SIGN"){
            //     location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/signature?pageCallback=${decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")}`
            // } else if (this.$store.state.type === "CHECK"){
            //     location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/audit?pageCallback=${decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")}`
            // } else if (this.$store.state.type === "VIEW"){
            //     location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/detail`
            // }
        },
        async checkCouldFreeLogin(){
            let freeLoginToken = this.$route.query.freeLoginToken
            if (!freeLoginToken) return

            try {
                let session = await getSessionBySecurityToken({
                    securityToken: freeLoginToken,
                    loginType: "WEB"
                }).then(res => res.data.data.session)
                
                //没有表示全状态
                if (session.sessionScopes){
                    //OPEN_PARTICIPANT_HANDLING 才能用
                    if (!session.sessionScopes.find(_ => _ === "OPEN_PARTICIPANT_HANDLING")){
                        throw new Error("ERROR_NEED_OPEN_PARTICIPANT_HANDLING")
                    }
                }

                this.isLogin = true
            } catch (err){
                //免登陆失败
                console.log("免登陆失败")
            }
        }
    }
}
</script>

