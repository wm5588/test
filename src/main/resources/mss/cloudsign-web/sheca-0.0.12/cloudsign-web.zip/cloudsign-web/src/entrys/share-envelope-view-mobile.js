import "core-js"
import "regenerator-runtime/runtime"

import "@styles/common.less"
import Vue from "vue"
import Vuex from "vuex"
// import storeConfig from "@store/mobile-index.js"
import shareEnvelopeView from "@page-components/mobile/share-envelope-view.vue"
Vue.use(Vuex)

const autoComputeZoom = _ => {
    let screenWidth = document.documentElement.clientWidth
    let screenHeight = document.documentElement.clientHeight
    let remPx = 100
    if (screenHeight > screenWidth){ //竖屏
        document.documentElement.style.fontSize = screenWidth / 375 * remPx + "px"
    } else { //横屏
        document.documentElement.style.fontSize = screenHeight / 375 * remPx + "px"
    }
}


window.addEventListener("load", autoComputeZoom)
window.addEventListener("resize", autoComputeZoom)

import Mint from "mint-ui"
import "mint-ui/lib/style.css"
Vue.use(Mint)

//element-ui 引入
import {
    Row,
    Col,
    Message,
    Input,
    InputNumber,
    Button,
    Checkbox,
    Select,
    Option,
    Loading
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(InputNumber)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Select)
Vue.use(Option)
Vue.use(Loading.directive)
Vue.prototype.$message = Message
Vue.prototype.$loading = Loading.service

new Vue({
    el: "#mobile",
    template: "<shareEnvelopeView />",
    components: {
        shareEnvelopeView
    }
})
