import Vue from "vue"
import Vuex from "vuex"
import VueRouterTitle from "vue-router-title"
import router from "@routes/routes-mobile.js"
import storeConfig from "@store/mobile-index.js"
import axios from "@interfaces/axios.js"
import Loading from "@components/modal/loading/loading.vue"
import SystemLoading from "@commons/system-loading.js"
Vue.use(Loading)

const store = new Vuex.Store(storeConfig)

VueRouterTitle({
    router,
    store,
    beforeEach(title, to, {store, router}){
        return `大家签 | ${title}`
    }
})

axios.interceptors.response.use(function (response) {
    store.commit("update_user_active")
    return response
}, function (error) {
    return Promise.reject(error)
})

SystemLoading.open()
SystemLoading.setLoadingText("加载应用数据...")

let timeCount = 0
let handle = setInterval(_ => {
    timeCount++
    if (timeCount === 1){
        SystemLoading.setLoadingText("加载中，请耐心等待...")
    } else if (timeCount === 2){
        SystemLoading.setLoadingText("稍等，网络有点慢，正在努力加载...")
    }
}, 5000)

store.dispatch("init").then(_ => {
    clearInterval(handle)
    SystemLoading.close()

    new Vue({
        el: "#mobile",
        router,
        store,
        template: "<router-view></router-view>"
    })
}).catch(err => {
    console.error(err)
    SystemLoading.setLoadingText("网络请求不给力，请稍候再试...")
})

