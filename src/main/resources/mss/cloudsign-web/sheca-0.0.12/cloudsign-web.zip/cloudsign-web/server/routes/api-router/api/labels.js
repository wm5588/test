let error = require('$error')
let askend = require('$HMAC').askend

/**
 * ----------------------------------------------------
 * @desc  获取标签列表: 获取所有标签列表
 * @from  标签管理微服务-获取标签 | GET /labels
 * @date  2017-07-31 15:48:52
 * ----------------------------------------------------
 */
exports.get = function (req, res, next) {
    askend({
        reqMethod: 'get',
        reqURL: '6471/labels',
        reqSession: req.cookies.SessionWsid,
        reqQuery: req.query,
        reqSuccess: function (body) {
            res.json(body)
        },
        reqError: function (err) {
            error.senderror(res, "000x000", { err })
        }
    })
}

/**
 * ----------------------------------------------------
 * @desc  创建单个标签: 创建一个标签
 * @from  标签管理微服务-创建标签 | POST /labels
 * @date  2017-07-31 15:49:27
 * ----------------------------------------------------
 */
exports.post = function (req, res, next) {
    askend({
        reqMethod: 'post',
        reqURL: '6471/labels',
        reqSession: req.cookies.SessionWsid,
        reqData: req.body,
        reqSuccess: function (body) {
            res.json(body)
        },
        reqError: function (err) {
            error.senderror(res, "000x000", { err })
        }
    })
}