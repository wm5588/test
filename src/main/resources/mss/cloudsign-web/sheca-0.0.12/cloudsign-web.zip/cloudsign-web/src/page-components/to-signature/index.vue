<template>
    <div v-loading="pageLoading" element-loading-text="页面加载中" class="page-container"></div>
</template>

<script>
import { getSessionData } from "@interfaces/user/sessions.js"
import { getUserData } from "@interfaces/user/user.js"
import { checkAuthStatus } from "@commons/check-status.js"
import { getCustomStyles } from "@interfaces/open-platform/developer.js"

export default {
    data(){
        return {
            pageLoading: true,
            themeColor: "",
            circleAngle:-1
        }
    },
    created(){
        this.init()
        if (localStorage){
            localStorage.setItem(`pageCallback:${this.$route.query.envelopeWsid}`, this.$route.query.pageCallback)
        }

        let appId = this.$route.query.appId
        if(appId && appId!=="undefined"){
            getCustomStyles({
                appId: appId,
            }).then(res => {
                let customStylesInfo = res.data.data.customStylesInfo
                if(customStylesInfo){
                    this.themeColor = customStylesInfo.themeColor
                    this.circleAngle = parseInt(customStylesInfo.circleAngle)
                }   
            }).catch(err => {
                console.error(err)
            })
        }
    },
    methods: {
        init(){
            this.check().then(_ => {
                let action = this.$route.query.action
                let envelopeWsid = this.$route.query.envelopeWsid
                let pageCallback = this.$route.query.pageCallback
                let selectedAuthTypes = this.$route.query.selectedAuthTypes
                let enableNoAppearance = this.$route.query.enableNoAppearance
                let enableSimpleDisplay =  this.$route.query.enableSimpleDisplay
                let appId = this.$route.query.appId
                if (action === "SIGN"){
                    this.$router.replace({
                        path: "/sign",
                        query: {
                            envelopeWsid,
                            action,
                            selectedAuthTypes,
                            enableNoAppearance,
                            enableSimpleDisplay,
                            appId,
                            pageCallback,
                            circleAngle:this.circleAngle,
                            themeColor:this.themeColor
                        }
                    })
                } else {
                    this.$router.replace({
                        path: "/check",
                        query: {
                            envelopeWsid,
                            action,
                            selectedAuthTypes,
                            enableNoAppearance,
                            enableSimpleDisplay,
                            appId,
                            pageCallback,
                            circleAngle:this.circleAngle,
                            themeColor:this.themeColor
                        }
                    })
                }
            }).catch(err => {
                console.error(err)
                switch (err.message){
                    case "ERROR_NOT_LOGIN":
                        this.$alert("未登录，请先登录", "提示", {
                            type: "error",
                            confirmButtonText: "登录"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = `/login?targetURL=${encodeURIComponent(location.href)}`
                        })
                        break
                    case "ERROR_INCOMPLETE_LINK_PARAMETERS":
                        this.$alert("参数不完整，请输入完整的链接!", "提示", {
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    case "ERROR_UNSUPPORTED_OPERATIONS":
                        this.$alert("不支持的操作方式!", "提示", {
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    case "ERROR_AUTHENTICATION_IS_WAITING_REVIEW":
                        this.$alert("您的实名认证信息正在审核中，暂时不能进行该操作，请耐心等待或者联系客服 021-962600", "提示", {
                            confirmButtonText: "我知道了",
                            type: "warning"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_AUTHENTICATION_HAS_BEEN_REJECTED":
                        this.$alert("您的实名认证信息未通过审核，您可重新提交认证信息", "提示", {
                            confirmButtonText: "前往登录认证",
                            type: "warning"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_AUTHENTICATION_INFORMATION_IS_EXPIRED":
                        this.$alert("您的实名认证信息已过期，将影响功能的正常使用，请重新认证", "提示", {
                            confirmButtonText: "前往登录认证",
                            type: "warning"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_AUTHENTICATION_INFORMATION_IS_NULL":
                        this.$alert("您尚未进行实名认证，签署的文件不具备法律效力，暂时不能进行该操作，请完成实名认证", "提示", {
                            confirmButtonText: "前往登录认证",
                            type: "warning"
                        }).then(_ => {}, _ => {}).then(_ => {
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ENTERPRISE_AUTHENTICATION_IS_ERROR":
                        this.$alert("您当前的企业未完成实名认证，签署的文件不具备法律效力，暂时不能进行该操作，请完成企业的实名认证", "提示", {
                            confirmButtonText: "前往登录认证",
                            type: "warning"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_WAITING_JOIN_ENTERPRISE":
                        this.$alert("您不是企业成员，请先加入企业", "提示", {
                            confirmButtonText: "退出",
                            type: "warning"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_NOT_IN_ENVELOPE_FLOW":
                        this.$alert("您不是签署方，无权限访问", "提示", {
                            confirmButtonText: "返回",
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_NOT_A_SIGNER":
                        this.$alert("您不是签署方，无法进行签署操作", "提示", {
                            confirmButtonText: "返回",
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_NEED_WAIT_OTHER":
                        this.$confirm("未轮到您处理请耐心等待", "提示", {
                            confirmButtonText: "退出",
                            type: "warning"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ALREADY_DONE":
                        this.$confirm("您已完成签署任务，请勿重复操作", "提示", {
                            confirmButtonText: "退出",
                            type: "warning"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_NOT_A_CHECKER":
                        this.$alert("您不是审核方，无法进行签署操作", "提示", {
                            confirmButtonText: "退出",
                            type: "warning"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ENVELOPE_STATUS_IS_NOT_MATCH":
                        this.$confirm("系统繁忙请稍后再试", "提示", {
                            confirmButtonText: "刷新",
                            cancelButtonText: "退出",
                            type: "warning"
                        }).then(_ => {
                            location.reload()
                        }).catch(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ENVELOPE_HAD_BEEN_REVOKED":
                        this.$alert("对不起,该文档已被撤销,您目前不能进行操作", "提示", {
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ENVELOPE_HAD_BEEN_ED_FAIL_EXPIRED":
                        this.$alert("对不起,该文档已过期,您目前不能进行操作", "提示", {
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ENVELOPE_HAD_BEEN_REJECTED":
                        this.$alert("对不起,该文档已被拒签,您目前不能进行操作", "提示", {
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    default:
                        this.$alert("对不起,遇到了未知的错误", "提示", {
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                }
            }).then(_ => {
                this.pageLoading = false
            })
        },
        async check(){
            //开始做判断
            let query = this.$route.query

            //必须传入的参数数据
            //信封ID
            let envelopeWsid = query.envelopeWsid
            //操作
            let action = query.action

            if (!envelopeWsid || !action){
                throw new Error("ERROR_INCOMPLETE_LINK_PARAMETERS")
            }

            if (action !== "SIGN" && action !== "CHECK"){
                throw new Error("ERROR_UNSUPPORTED_OPERATIONS")
            }

            //检测是否登录
            try {
                await getSessionData().then(res => res.data.data.session)
            } catch (err){
                throw new Error("ERROR_NOT_LOGIN")
            }

            //初始化相关数据
            await this.$store.dispatch("init", { envelopeWsid })


            //认证状态判断
            let userIddtvStatus = this.$store.state.userData.idttvStatus
            let enterpriseIdttvStatus = this.$store.state.userData.enterpriseIdttvStatus
            try {
                this.checkIddtvStatus(userIddtvStatus, enterpriseIdttvStatus)
            } catch (err){
                throw err
            }
            
            //初始化信封数据
            await this.$store.dispatch("initEnvelopeData")

            //获取当前应该签署的参与者
            try {
                let participant = await this.getCurrentActionParticipant()
                this.$store.commit("setCurrentParticipant", participant)
            } catch (err){
                throw err
            }
        },
        getCurrentActionParticipant(){
            let query = this.$route.query
            let action = query.action

            let participants = this.$store.state.envelopeData.participants
            let userAuthorWsidInEnvelope = this.$store.getters.userAuthorWsidInEnvelope
            let enterpriseRoles = this.$store.state.userData.enterpriseRoles
            let currentSequence = this.$store.state.envelopeData.basicInfo.currentSequence
            let envelopeShownStatus = this.$store.state.envelopeData.basicInfo.envelopeShownStatus
            let actionType = action === "SIGN" ? "SIGNER" : "CHECKER"
            //逾期未签
            if (envelopeShownStatus === "ED_FAIL_EXPIRED"){
                throw new Error("ERROR_ENVELOPE_HAD_BEEN_ED_FAIL_EXPIRED")
            }

            //未加入企业的情况
            if (envelopeShownStatus === "WAITING_JOIN_ENTERPRISE"){
                throw new Error("ERROR_WAITING_JOIN_ENTERPRISE")
            }
            //撤销
            if (envelopeShownStatus === "REVOKE"){
                throw new Error("ERROR_ENVELOPE_HAD_BEEN_REVOKED")
            }

            //拒签
            if (envelopeShownStatus === "REJECT"){
                throw new Error("ERROR_ENVELOPE_HAD_BEEN_REJECTED")
            }

            //获取当前用户的签名参与者
            let userParticipants = participants.filter(participant => participant.authorWsid === userAuthorWsidInEnvelope 
                || enterpriseRoles.find(role => participant.authorWsid === role.wsid))
            
            //当前用户不在信封流程
            if (userParticipants.length === 0)
                throw new Error("ERROR_NOT_IN_ENVELOPE_FLOW")
            
            //为当前阶段的
            let nowUserParticipants = userParticipants.filter(participant => participant.sequence === currentSequence 
                && participant.status === "ING_WAIT")

            //当前阶段没人
            if (nowUserParticipants.length === 0){
                if (userParticipants.filter(participant => participant.sequence > currentSequence).length > 0){
                    throw new Error("ERROR_NEED_WAIT_OTHER")
                } else {
                    throw new Error("ERROR_ALREADY_DONE")
                }
            }

            let nowActionParticipants = nowUserParticipants.filter(participant => participant.actionType === actionType)
            
            //当前用户可以操作但是操作类型不对
            if (nowActionParticipants.length === 0){
                if (action === "SIGN"){
                    throw new Error("ERROR_NOT_A_SIGNER")
                } else {
                    throw new Error("ERROR_NOT_A_CHECKER")
                }
            }

            //信封状态不匹配
            if (action === "SIGN" && envelopeShownStatus !== "WAITING_ME_SIGN"
                || action === "CHECK" && envelopeShownStatus !== "WAITING_ME_CHECK")
                throw new Error("ERROR_ENVELOPE_STATUS_IS_NOT_MATCH")
            
            return nowActionParticipants[0]
        },
        checkIddtvStatus(userIddtvStatus, enterpriseIdttvStatus){
            if (userIddtvStatus !== "PASSED"){
                if (userIddtvStatus === "WAITING"){
                    throw new Error("ERROR_AUTHENTICATION_IS_WAITING_REVIEW")
                } else if (userIddtvStatus === "DENY"){
                    throw new Error("ERROR_AUTHENTICATION_HAS_BEEN_REJECTED")
                } else if (userIddtvStatus === "EXPIRED"){
                    throw new Error("ERROR_AUTHENTICATION_INFORMATION_IS_EXPIRED")
                } else {
                    throw new Error("ERROR_AUTHENTICATION_INFORMATION_IS_NULL")
                }
            }

            if (enterpriseIdttvStatus){
                if (enterpriseIdttvStatus !== "SENIOR_PASSED"){
                    throw new Error("ERROR_ENTERPRISE_AUTHENTICATION_IS_ERROR")
                }
            }

            return true
        }
    }
}
</script>
<style lang="less" scoped>
.page-container{
    position: absolute;
    top:0;
    left: 0;
    bottom: 0;
    right: 0;
}
</style>
