const path = require("path")

module.exports = {
    presets: [
        [
            "@babel/preset-env",
            {
                useBuiltIns: "entry",
                corejs: 3
            }
        ]
    ],
    plugins: [
        [
            path.resolve(__dirname, "./easy-import.js"), 
            {
                libraryName: "element-ui",
                default: "index",
                base: [
                    "@styles/element-ui/outputs/base.css"
                ],
                changers: [
                    name => `element-ui/lib/${name}`,
                    name => `@styles/element-ui/outputs/${name}.css`,
                ]
            }
        ],
        "transform-vue-jsx",
        "@babel/plugin-syntax-dynamic-import",
        "@babel/plugin-proposal-class-properties",
        "@babel/plugin-proposal-optional-chaining",
        "@babel/plugin-transform-regenerator"
    ]
}
