import {checkContractNumber} from "@interfaces/enterprise/contract-number.js"
function initData(){
    return {
        enterpriseWsid: "", //企业全局唯一ID"
        authorWsid: "", //企业拥有者ID
        memberWsid: "", //当前用户企业成员ID
        name: "", //企业全称
        websiteMetadata: "", //企业域名
        avatarHref: { //企业头像
            rel: "",
            href: ""
        },
        idttvWsid: "", //认证ID
        /* 企业认证状态：
         * INCOMPLETE-未认证
         * WAITING-等待审核
         * PRIMARY_PASSED-初级认证
         * PRIMARY_DENY-认证未通过
         * WAITING_SUM-等待打款
         * WAITING_SUM_CHECK-确认打款(等待用户汇款信息确认)
         * SENIOR_PASSED-高级认证(用户汇款信息确认成功),
         * SENIOR_DENY-认证未通过(打款失败/汇款验证失败)
         */
        idttvStatus: "INCOMPLETE",
        userEnterpriseWsid: "",
        contractNumberWsid: "",
        contractNumberStutas: ""
    }
}

const module_userEnterprise = {
    state: initData(),
    getters: {
        enterpriseName(state) {
            return state.name
        },
        enterpriseWsid(state) {
            return state.enterpriseWsid
        },
        memberWsid(state){
            return state.memberWsid
        },
        enterpriseIddtvStatus(state) {
            if (state.idttvStatus === "SENIOR_NO_CERT"){
                return "SENIOR_PASSED"
            } else {
                return state.idttvStatus
            }   
        },
        enterpriseNeedAuth(state) {
            if (state.idttvStatus === "PASSED"
                || state.idttvStatus === "WAITING"){
                return false
            } else {
                return true
            }
        },
        enterpriseAuthorWsid(state){
            return state.authorWsid
        },
        enterpriseEuserAuthorWsid(state){
            return state.userEnterpriseWsid
        },
        contractNumberWsid(state){
            return state.contractNumberWsid
        },
        contractNumberStutas(state){
            return state.contractNumberStutas
        },
    },
    mutations: {
        setEnterpriseData(state, enterpriseData){ //由userData设置进入
            Object.assign(state, initData(), enterpriseData.enterprise, enterpriseData)
        },
        updateContractNumberData(state, data){
            state.contractNumberWsid = data.wsid || ""
            state.contractNumberStutas = data.status || ""
        }
    },
    actions: {
        getEnterpriseContractNumberStutas({dispatch, commit, getters, state }){
            if (getters.enterpriseWsid){
                checkContractNumber({enterpriseWsid: getters.enterpriseWsid}).then(res => {
                    let data = res.data.data.abandon
                    state.contractNumberWsid = data.wsid || ""
                    state.contractNumberStutas = data.status
                }).catch(err => {
                    console.error(err)
                })
            }
        }
    }
}

export default module_userEnterprise