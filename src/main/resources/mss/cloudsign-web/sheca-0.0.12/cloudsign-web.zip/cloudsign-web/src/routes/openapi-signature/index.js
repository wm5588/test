import loadingPage from "@page-components/openapi-signature/loading.vue"
import loginPage from "@page-components/openapi-signature/login.vue"

let routerConfig = {
    mode: "history",
    base: "/openapi-signature",
    routes: [
        {
            path: "/",
            meta: {
                title: "加载中"
            },
            component: loadingPage
        },
        {
            path: "/login",
            name: "login",
            meta: {
                title: "验证"
            },
            component: loginPage
        }
    ]
}

export default routerConfig
