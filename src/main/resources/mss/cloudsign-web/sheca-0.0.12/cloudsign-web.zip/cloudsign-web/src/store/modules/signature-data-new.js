import { translateParticipantDatasFromEnd } from "@classes/envelopes/participants.js"
import { USER_EDITION } from "@utils/users.js"
import { cm2pt } from "@utils/translate.js"
import { FormsManager } from "@components/envelopes/envelop-signature/utils/forms.js"

import { getEnvelopeDocuments } from "@interfaces/envelopes/documents.js"
import { getEnvelopeData } from "@interfaces/envelopes/index.js"
import { getPersonSeals, getAuthorizeSeals } from "@interfaces/seals/seals.js"
import { getUserRoles } from "@interfaces/policy/enterprise-roles.js"
import { getEnvelopeParticipants } from "@interfaces/envelopes/participants.js"

import Vue from "vue"

const CSS_UNITS = 96.0 / 72.0

function initData(){
    return {
        /**
         * place-normal-form 放置签署表单项
         * goto-document    前往某个文档
         * goto-page    前往某页
         */
        eventBus: new Vue(),
        envelopeWsid: "", //信封WSID
        activeUserWsid: "", //当前签署的人的ID
        userAuthorWsid: "", //当前用户作为信封拥有者的ID

        //企业内才要==========
        enterpriseWsid: "", //当前企业ID
        isAuthor: false, //是否未当前企业的人
        //==================
        
        //信封相关数据========
        envelopeData: null,
        documents: [],
        documentsData: [], //文档渲染加载完成返回的数据
        participant: null, //当前的签署人
        participantEnterpriseRole: null, //当前签署人被设置的在企业里的角色
        formsManager: new FormsManager(),
        //==================

        //签章相关数据========
        personalSeal: null, //个人印章
        officeSealsAmount: 0, //可用印章总数
        //==================

        //页面展示的状态======
        scale: 1 * CSS_UNITS, //页面缩放比例
        activeDocumentId: "", //活跃的文档ID
        activePage: 1, //活跃文档页数
        //==================

        //页面状态===========
        settingPagingSeal: false, //骑缝章模式是否启动
        //=================
    }
}

const moduleSignatureData = {
    namespaced: true,
    state: initData(),
    getters: {
        userEdition(state){
            return USER_EDITION.getUserEditionByUserWsid(state.activeUserWsid)
        },
        forms(state){
            return state.formsManager.getForms()
        },
        pagingSeals(state){
            return state.formsManager.getPagingSeals()
        },
        activeDocumentData(state){
            let index = state.documents.findIndex(doc => doc.id === state.activeDocumentId)
            if (state.documentsData[index]){
                return {
                    ...state.documentsData[index],
                    ...state.documents[index]
                }
            } else {
                return {
                    pagesCount: 0
                }
            }
        },
        isSender(state){
            if (state.envelopeData){
                return state.userAuthorWsid === state.envelopeData.senderWsid
            } else {
                return false
            }
        }
    },
    mutations: {
        //初始化签署的数据
        initSignatureData(state, {envelopeWsid, activeUserWsid, enterpriseWsid, isAuthor}){
            Object.assign(state, initData())
            state.envelopeWsid = envelopeWsid
            state.activeUserWsid = activeUserWsid
            state.enterpriseWsid = enterpriseWsid || ""
            state.isAuthor = isAuthor || false
        },
        //设置个人签章
        setPeronalSeal(state, seal){
            state.personalSeal = seal
        },
        setOfficeSealsAmount(state, data){
            state.officeSealsAmount = data
        },
        //设置信息信息
        setEnvelopeData(state, data){
            state.envelopeData = data
        },
        setParticipant(state, participant){
            state.participant = participant
        },
        setParticipantEnterpriseRole(state, role){
            state.participantEnterpriseRole = role
        },
        flipSettingPagingSeal(state){
            state.settingPagingSeal = !state.settingPagingSeal
        },
        setSettingPagingSeal(state, settingPagingSeal){
            state.settingPagingSeal = settingPagingSeal
        },
        setScale(state, scale){
            state.scale = scale
        },
        setDocuments(state, documents){
            state.documents = documents
        },
        setActiveDocumentId(state, docId){
            state.activeDocumentId = docId
        },
        setActivePage(state, page){
            state.activePage = page
        },
        setDocumentsData(state, data){
            state.documentsData = data
        },
        userAuthorWsid(state, userAuthorWsid){
            state.userAuthorWsid = userAuthorWsid
        },
        appendForm(state, form){
            state.formsManager.appendForm(form)
        },
        deleteForm(state, formRandom){
            state.formsManager.deleteForm(formRandom)
        }
    },
    actions: {
        async init({commit, state, getters, rootGetters, dispatch}, { envelopeWsid }){
            let activeUserWsid = rootGetters.activeUserWsid
            let enterpriseWsid = rootGetters.enterpriseWsid
            let isAuthor = rootGetters.enterpriseAuthorWsid === rootGetters.userWsid

            commit("initSignatureData", {
                envelopeWsid,
                activeUserWsid,
                enterpriseWsid,
                isAuthor
            })
            
            //先获取信封信息
            try {
                await dispatch("loadEnvelopeData")
            } catch (err){
                if (err.response && err.response.data.code === 101){
                    throw new Error("ERROR_NOT_IN_ENVELOPE_FLOW")
                } else {
                    throw err
                }
            }

            //判断信封状态是否未待我签署
            let envelopeData = state.envelopeData
            let envelopeShownStatus = envelopeData.envelopeShownStatus


            //拉取信封相关信息然后，判断当前的人是否可以进行签署操作
            let userEdition = getters.userEdition
            let userAuthorWsid = rootGetters.activeUserWsid
            let currentSequence = envelopeData.currentSequence
            if (userEdition === USER_EDITION.ENTERPRISE){
                userAuthorWsid = rootGetters.memberWsid
            }
            commit("userAuthorWsid", userAuthorWsid)

            //获取当前企业的角色
            let enterpriseRoles = []
            if (userEdition === USER_EDITION.ENTERPRISE){
                await getUserRoles({
                    authorWsid: activeUserWsid
                }).then(res => {
                    enterpriseRoles = res.data.data.enterpriseRoles
                })
            }
            
            //获取当前用户在信封中的签署身份
            let participants = await getEnvelopeParticipants({
                envelopeWsid: envelopeWsid
            }).then(res => {
                return translateParticipantDatasFromEnd(res.data.data.participants)
            })

            //未加入企业的情况
            if (envelopeShownStatus === "WAITING_JOIN_ENTERPRISE"){
                throw new Error("ERROR_WAITING_JOIN_ENTERPRISE")
            }

            //逾期未签
            if (envelopeShownStatus === "ED_FAIL_EXPIRED"){
                throw new Error("ERROR_ENVELOPE_HAD_BEEN_ED_FAIL_EXPIRED")
            }

            //获取当前用户的签名参与者
            let userParticipants = participants.filter(participant => participant.authorWsid === userAuthorWsid 
                || enterpriseRoles.find(role => participant.authorWsid === role.wsid))
            
            //当前用户不在信封流程
            if (userParticipants.length === 0) 
                throw new Error("ERROR_NOT_IN_ENVELOPE_FLOW")
            
            let userSignerParticipants = userParticipants.filter(participant => participant.actionType === "SIGNER")
            
            //当前用户在信封中不能审核
            if (userSignerParticipants.length === 0) 
                throw new Error("ERROR_NOT_A_SIGNER")
            
            //为当前阶段的
            let nowUserParticipants = userSignerParticipants.filter(participant => participant.sequence === currentSequence 
                && participant.status === "ING_WAIT")

            //当前阶段没人
            if (nowUserParticipants.length === 0){
                if (userParticipants.filter(participant => participant.sequence > currentSequence).length > 0){
                    throw new Error("ERROR_NEED_WAIT_OTHER")
                } else {
                    throw new Error("ERROR_ALREADY_SIGNED")
                }
            }

            //信封状态不匹配
            if (envelopeShownStatus !== "WAITING_ME_SIGN")
                throw new Error("ERROR_ENVELOPE_STATUS_IS_NOT_MATCH")
            
            let participant = nowUserParticipants[0]
            commit("setParticipant", {
                name: participant.name,
                type: participant.type,
                participantWsid: participant.participantWsid
            })
            
            let role = enterpriseRoles.find(role => participant.authorWsid === role.wsid)
            commit("setParticipantEnterpriseRole", role)

            if (userEdition === USER_EDITION.ENTERPRISE){
                await dispatch("loadOfficialSeals")
            }

            //加载进行操作需要的周边数据
            await Promise.all([
                dispatch("loadDocuments"),
                dispatch("loadPersonalSeal"),
                state.formsManager.load(envelopeWsid, state.participant.participantWsid)
            ])
        },
        loadEnvelopeData({state, commit}){
            let envelopeWsid = state.envelopeWsid

            return getEnvelopeData({
                envelopeWsid: envelopeWsid
            }).then(res => {
                let envelope = res.data.data.envelope
                commit("setEnvelopeData", envelope.basicInfo)
            })
        },
        loadPersonalSeal({state, commit}){
            let activeUserWsid = state.activeUserWsid
            return getPersonSeals({
                authorWsid: activeUserWsid
            }).then(res => {
                let personSeals = res.data.data.personSeals
                let personSeal = personSeals[personSeals.length - 1]
                if (personSeal){
                    commit("setPeronalSeal", {
                        id: personSeal.personSealWsid,
                        imageData: personSeal.link.href
                    })
                }
            })
        },
        loadDocuments({state, commit}){
            let envelopeWsid = state.envelopeWsid

            return getEnvelopeDocuments({
                envelopeWsid: envelopeWsid
            }).then(res => {
                let documents = res.data.data.documents
                documents = documents.map(document => {
                    let metadata = {}
                    if (document.fileTagId){
                        metadata = JSON.parse(document.fileTagId)
                    }
                    return {
                        id: document.fileWsid,
                        pdfSrc: document.fileHref.href,
                        name: document.fileName,
                        sequece: metadata.sequece != undefined ? metadata.sequece : null,
                        fileType: document.fileType
                    }
                })
                if (documents.every(_ => _.sequece != null)){
                    documents.sort((a, b) => a.sequece - b.sequece)
                }

                commit("setActiveDocumentId", documents[0].id)
                commit("setActivePage", 1)
                commit("setDocuments", documents)
            })
        },
        loadOfficialSeals({state, commit}){
            return getAuthorizeSeals({
                enterprisePersonWsid: state.activeUserWsid,
                filters: `checkStatus=CHECKED,status=NORMAL`,
                limit: 1,
            }).then(res => {
                commit("setOfficeSealsAmount", res.data.data.page.totalElements)
            })
        },
        saveData({state}){
            return state.formsManager.uploadFormsData()
        }
    }
}

export default moduleSignatureData