<template>
    <transition name="fade">
        <slot></slot>
    </transition>
</template>

<script>
export default {
    
}
</script>

<style lang="less" scoped>
.fade-enter-active {
    transition: all 0.3s;
}
.fade-leave-active {
    transition: all 0.3s;
}
.fade-enter, .fade-leave-to{
    opacity: 0;
}
</style>
