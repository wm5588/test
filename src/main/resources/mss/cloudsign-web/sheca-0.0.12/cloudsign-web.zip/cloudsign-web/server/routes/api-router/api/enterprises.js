const exit = require("$exit")
const error = require("$error")
const askend = require("$HMAC").askend

/**
 * ----------------------------------------------------
 * @path   /api/enterprises
 * @method POST
 * @desc   添加新企业
 * @author 周雪梅,陈曦源
 * @date   2018-02-28 21:25:54
 * ----------------------------------------------------
 */
exports.post = function (req, res, next) {
    let {
        name,
        authorWsid
    } = req.body

    askend({
        reqMethod: "post",
        reqURL: "wesign-mss-enterprise://enterprises",
        reqSession: req.cookies.SessionWsid,
        reqData: {
            name,
            authorWsid
        }
    }).then(resp => {
        exit(res, {
            enterprise: resp.data.enterprise
        })
    }).catch(err => {
        /**
         * @description 创建企业可能出现的错误
         * @code     
         *      100 通用内部错误
         *      101 禁止创建同名企业
         */
        let faultCode = 100
        let faultMessage = "通用内部错误"
        if (err.response){
            let status = err.response.status
            if (err.response.data){
                let code = err.response.data.code
                switch (code){
                    case "100350104":
                        faultCode = 101
                        faultMessage = "企业名称已被实名认证"
                        break
                    case "100350105":
                        faultCode = 102
                        faultMessage = "该用户已经创建了同名企业"
                        break
                }
            }
            exit.error(res, undefined, faultCode, faultMessage, {status, errorData: err})
        } else {
            next(err)
        }
    })
}