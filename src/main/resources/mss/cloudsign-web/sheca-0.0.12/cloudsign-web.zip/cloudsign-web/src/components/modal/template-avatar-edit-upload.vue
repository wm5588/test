<!--
    @desc   模板头像编辑上传组件
    @props
        defaultSrc:String   初始编辑的图片数据
    @events
        e-commit(imageDate) 头像更新完成
    @auther 陈曦源
    @date   2018-08-04 16:34:51
-->
<template>
    <div class="edit-box">
        <div class="edit-imgcut">
            <div class="edit-cut">
                <pictureCut ref="cuter" :imageSrc="imgSrc" @imagePreviewInfoChange="imagePreviewInfoChange"></pictureCut>
                <!--放大、缩小、旋转-->
                <div class='edit-oper'>
                    <span @click='rotate(-90)'><i class="icon-left-90"></i></span>
                    <span @click='rotate(90)'><i class="icon-right-90"></i></span>
                    <span @click='zoom(1.1)'><i class="icon-zoom-out"></i></span>
                    <span @click='zoom(0.9)'><i class="icon-zoom-in"></i></span>
                </div>
            </div>
            <div v-if="imagePreviewData" class="edit-preview">
                <p class='preview-title'>头像预览</p>
                <div class="preview-avatar" style="width:120px;height:120px;">
                    <pictureCutPreview :width="120" :height="120" :imagePreviewInfo="imagePreviewData" />
                </div>
            </div>
        </div> 
        <div class="clip-btn">
            <el-button type="default" @click="selectImage">重新上传</el-button>
            <el-button type="primary" @click="uploadImage">完成</el-button>
        </div>
    </div>
</template>

<script>
import { selectFile, ImageDataToFile } from "@commons/util.js"

import pictureCut from "@components/modal/picture-cut.vue"
import pictureCutPreview from "@components/modal/picture-cut-preview.vue"
import { template_avatars_post } from "@interfaces/templates/bsts.js"

export default {
    props: {
        defaultSrc: {
            type: String,
            default: ""
        },
        templateWsid: {
            type: String,
        }
    },
    data() {
        return {
            imgSrc: "",
            imagePreviewData: null
        }
    },
    mounted() {
        this.imgSrc = this.defaultSrc
    },
    methods: {
        selectImage() {
            selectFile("image/jpg,image/jpeg,image/png,image/gif,image/bmp,image/tiff").then(file => {
                this.editFile(file)
            }).catch(err => {
                this.$message.error("选择的文件类型错误，请选择正确的图片文件")
            })
        },
        editFile(file){ //头像剪裁
            let imgName = file.name 
            if (/\.(jpg|png|jpeg|gif|bmp|tiff)$/i.test(imgName)){
                if (!window.FileReader){
                    this.$message.error("浏览器不兼容FileReader")
                    return
                }
                else {
                    let reader = new FileReader()
                    reader.readAsDataURL(file)
                    reader.onload = item => {
                        this.haveImg = true
                        this.imgSrc = item.target.result
                    }
                }
            } else {
                this.$message.info("请选择有效的图片文件")
                this.$refs.inputImg.value = ""
            }
        },
        imagePreviewInfoChange(data) {
            this.imagePreviewData = data
        },
        zoom: function(scale){
            let cuter = this.$refs.cuter
            cuter.growScale(scale)
        },
        rotate: function(deg){
            let cuter = this.$refs.cuter
            cuter.growRotate(deg)
        },
        uploadImage() {
            let imagedata = this.$refs.cuter.cutImage(200, 200)
            let file = ImageDataToFile(imagedata)
            template_avatars_post({
                file: file,
                bstWsid: this.templateWsid
            }).then(_ => {
                this.$message.success("上传模板图标成功")
                this.$emit("e-commit")
            }).catch(err => {
                this.$message.error("上传模板图标失败")
            })
        }
    },
    components: {
        pictureCut,
        pictureCutPreview,
    }
}
</script>
 
<style lang="less" scoped>
@import "~@styles/variable.less";

.edit-box{
    position:relative;
}

.edit-imgcut{
    position: relative;
    overflow: hidden;

    .edit-cut, .edit-preview{
        float: left;
        margin: 0 15px;
    }

    .edit-oper{
        position:relative;
        margin-top: 15px;
        text-align:center;

        span{
            display:inline-block;
            cursor:pointer;
            margin:0 10px;
            width:30px;
            line-height:30px;
            text-align:center;
            border-radius:50%;
            background:#7c7c7c;
            color:#fff;
            font-size:20px;

            &:hover{
                background:#3c4651;
            }
        }
    }

    .preview-title{
        text-align: left;
    }

    .preview-avatar{
        position: relative;
        border: 1px solid #7c7c7c;
        margin: 10px 0;
        overflow: hidden;
    }
}

.clip-btn{
    text-align:right;
    margin:20px 50px 10px 0px;
}
</style>