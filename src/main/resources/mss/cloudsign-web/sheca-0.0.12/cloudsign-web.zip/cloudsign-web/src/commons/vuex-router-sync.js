export default function sync(store, router){
    store.registerModule("$router", {
        namespaced: true,
        state: {},
        getters: {
            router(){
                return router
            },
            route(){
                return router.currentRoute
            }
        }
    })
}