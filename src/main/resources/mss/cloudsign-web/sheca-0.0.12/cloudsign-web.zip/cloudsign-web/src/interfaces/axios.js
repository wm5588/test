import axios from "axios"

let instance = axios.create()
instance.defaults.withCredentials = true
// 兼容IE下会莫名其妙的自动缓存GET问题
instance.interceptors.request.use(function (config) {
    if (/^get$/i.test(config.method)){
        if (!config.params) config.params = {}
        config.params.flag = Date.now()
    }
    return config
}, function (error) {
    return Promise.reject(error)
})

export default instance