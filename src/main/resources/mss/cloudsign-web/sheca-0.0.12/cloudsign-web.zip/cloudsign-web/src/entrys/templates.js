import "./common.js"
import "@styles/icons/style.css"
import {
    Row,
    Col,
    Input,
    Button,
    Dialog,
    Pagination,
    Message,
    MessageBox,
    Notification,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Dialog)
Vue.use(Pagination)
Vue.prototype.$message = Message
Vue.prototype.$msgbox = MessageBox
Vue.prototype.$alert = MessageBox.alert
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$prompt = MessageBox.prompt
Vue.prototype.$notify = Notification

import Vue from "vue"

import templates from "@page-components/templates/templates.vue"
new Vue({
    el: "#app",
    template: "<templates />",
    components: {
        templates
    }
})
