<template lang="html">
    <externalFrame>
        <div style="padding: 20px">
            <el-form>
                <p class="public-height info-name-box">
                    <span class="info-name">{{senderName}}</span>
                </p>
                <p class="center tip">向您发来签署邀请</p>
                <p class="center tip-info">请按照页面提示验证您的身份</p>
                <el-alert class="form-item" v-if="errorInfo" type="error">{{errorInfo}}</el-alert>
                <el-alert class="form-item" v-if="successInfo" type="success">{{successInfo}}</el-alert>
                <el-form-item :error="accountError">
                    <el-input v-model.trim="account" size="large" @input="accountCheck = false" placeholder="请输入您提供给发起方的联系方式"></el-input>
                </el-form-item>
                <el-row>
                    <el-col :span="13">
                        <el-form-item prop="code" :error="verificationCodeError">
                            <el-input size="large" v-model.trim="verificationCode" :placeholder="codeSended ? '请输入验证码' : '请点击右侧获取验证码'"
                                @blur="checkVerificationCode"/>
                        </el-form-item>
                    </el-col>
                    <el-col :span="10" :offset="1">
                        <captchaButton  size="large" style="width:100%" :contact="account" :service="accountExisted?'LOGIN':'REGIST'" :type="verifyCodeType" :disabled="!accountCheck"
                            @error="sendVerifyCodeError" @sendsuccess="sendSuccess"></captchaButton>
                    </el-col>
                </el-row>
                <div v-show="!accountExisted">
                    <el-form-item :error="usernameError">
                        <el-input size="large" type="text" v-model.trim="username" auto-complete="name" placeholder="请输入姓名(汉字或字母)" @blur="checkUsernameFormat()"/>  
                    </el-form-item>
                    <el-form-item :error="passwordError">
                        <el-input size="large" :type="passwordVisiable ?  'text': 'password'" v-model.trim="password" 
                            auto-complete="new-password" placeholder="设置登录密码(至少6位数字、字母和字符的组合)" value="" @blur="checkPasswordFormat()"> 
                        <i slot="append" class="view" :class="passwordVisiable ? 'icon-eye-blocked' : 'icon-eye eye' " @click="passwordVisiable = !passwordVisiable"></i>
                        </el-input>
                    </el-form-item>
                </div>
                <div class="form-item">
                    <el-button size="large" style="width:100%;" type="primary" :loading="logining" @click.prevent="login">下一步</el-button>
                </div>
            </el-form>
            <!-- <shareLogin :targetURL="targetURL" @loginsuccess="loginsuccess"></shareLogin> -->
        </div>
    </externalFrame>
</template>

<script>
import { LoginLocalStatus, LoginComponentLocalInfo } from "@classes/login/login-info.js"
import externalFrame from "@page-components/frames/external-frame.vue"
import captchaButton from "@components/buttons/captcha-button.vue"
import { isPhone, isEmail,isPassword } from "@wesign/check"
import { verificationCodeSession } from "@interfaces/user/sessions.js"
import { getSessionData } from "@interfaces/user/sessions.js"
import objectStorage from "@utils/storage.js"
import { getUserRoles } from "@interfaces/policy/enterprise-roles.js"
import {
  getShareEnvelope
} from "@interfaces/envelopes/share/index"
import { usersRegist, 
    getUserAccounts,
    getUserData,
    checkAccount,
    changeSession } from "@interfaces/user/user.js"
import { opcode_post } from "@interfaces/auth/captcha.js"
import querystring from "querystring"
const ACCOUNT_STORAGE_KEY = "ACCOUNT_STORAGE"

export default {
    data(){
        let storedAccount = objectStorage.getItem(ACCOUNT_STORAGE_KEY) || ""
        return {
            senderName: "",
            successInfo:"",
            account:storedAccount,
            username:"",
            password:"",
            verificationCode:"",
            codeSended: false, //是否发送了验证码
            verifyCodeType: "SMS", //默认为短信验证码,
            logining:false,
            accountCheck:false,
            passwordVisiable: false, //账户密码是否可见
            accountExisted:true,
            loginLocalStatus: new LoginLocalStatus(),

            verificationCodeError:"",
            usernameError:"",
            passwordError:"",
            accountError:"",
            errorInfo:"",
            opcode:"",
            envelopeWsid:"",
            participants:[],
            userId:"",
            currentSequence:-1,
            envelopeShownStatus:"",
            accounts:[],
            activeUserParticipantWsid:""
        }
    },
    watch:{
        account(oldVal,newVal) {
            if(oldVal.length>0){
                if(!isEmail(oldVal).result && !isPhone(oldVal).result){
                    this.accountCheck = false
                } else {
                    if(oldVal!== newVal){
                        return this.checkAccountExist().then(exist => {
                                    this.accountCheck = true
                                    this.accountExisted = exist
                                })
                    }
                }
            }
        }
    },
    created(){
        let query = location.search.slice(1)
        query = querystring.parse(query)
        this.senderName = query.senderName.replace(",", "-")
        this.envelopeWsid = query.envelopeWsid
        this.linkKey = query.linkKey
        this.getEnvelopData()
        this.checkUserIfLogin()
        this.checkAccountExist().then(exist => {
            this.accountCheck = true
            this.accountExisted = exist
        })
    },
    methods: {
        async getEnvelopData(){
            await getShareEnvelope({
                envelopeWsid: this.envelopeWsid,
                linkKey:this.linkKey
            }).then(res => {
                let envelope = res.data.data.envelope
                this.envelopeData = envelope.basicInfo
                this.currentSequence = envelope.basicInfo.currentSequence
                this.participants = envelope.participants
                this.envelopeShownStatus = envelope.basicInfo.envelopeShownStatus
            }).catch(err => {
                console.error(err)
            })
        },
          async checkUserIfLogin(){
            try {
                let session = await getSessionData().then(res => res.data.data.session)
                if (session.sessionScopes && session.sessionScopes.length > 0){
                    return false
                }

                let userId = session.userWsid

                let accounts = await getUserAccounts({
                    userWsid: userId,
                    limit: 10000
                }).then(res => {
                    this.accounts = res.data.data.accounts
                    return res.data.data.accounts
                })

                //检测联系方式是否正确
                let userInfo = await getUserData({
                    userWsid: userId,
                }).then(res => {
                    return res.data.data.userInfo.user
                })
                this.getCurrentActionParticipant().then(res =>{
                    location.href = `/wesign/envelopes/${this.envelopeWsid}/detail`
                }).catch(err =>{
                    console.error(err)
                    if (err.message === "ERROR_NOT_IN_ENVELOPE_FLOW"){
                         this.$alert("您不是该文件的签署者，无访问权限。", "提示", {
                            confirmButtonText: "查看其他文件",
                            cancelButtonText: "取消",
                            showCancelButton:true,
                            callback: action => {
                                if (action === "confirm"){
                                    location.href ="/wesign/envelopes"
                                }
                            },
                            type: "warning"
                        })
                    }
                })
            } catch (e) {
                console.error(e)
                //未登录
            }

            return false
        },
        sendVerifyCodeError(msg){
            switch (msg){
                case "ERROR_CONTACT": 
                    this.accountError = "请输入有效的手机号"
                    break
                case "ERROR_SEND_BUSY": 
                    this.errorInfo = "发送太频繁，请倒计时结束后再点击"
                    break
                case "ERROR_TIMEOUT":
                    this.errorInfo = "请求发送验证码超时"
                    break
                case "ERROR_FREQUENTLY":
                    this.errorInfo = "请求发送验证码过于频繁"
                    break
                case "ERROR_AMOUNT_OUT_LIMIT":
                    this.errorInfo = "今日可接收验证码已达到上限"
                    break
                default:
                    this.errorInfo = "发送失败"
            }
        },
        sendSuccess(){
            this.clearInfo()
            this.successInfo = "验证码发送成功"
        },
        clearInfo(){
            this.successInfo = ""
            this.errorInfo = ""
        },
        checkAccountFormat(checkNull = false) { //检测帐号格式
            let val = this.account
            if (val.length === 0){
                if (!checkNull){
                    this.accountError = ""
                    return true
                } else {
                    this.accountError = "请输入手机号或邮箱地址"
                    return false
                }
            } else if (!isEmail(val).result && !isPhone(val).result){
                this.accountError = "请输入有效的手机号或邮箱地址"
                return false
            }
            this.accountError = ""
            return true
        },
        checkAccountExist(checkNull = false) { //检测帐号是否存在
            if (!this.checkAccountFormat(checkNull)){
                return 
            } 
            let val = this.account
            if (!val) return

            return checkAccount({
                account: val
            }).then(res => {
                let body = res.data
                return body.data.existed
            }).catch(err => {
                this.clearInfo()
                if (err.response.data){
                    let code = err.response.data.code
                    if (code == 403) {
                        this.errorInfo = "发送请求过于频繁"
                    } else {
                        this.errorInfo = "网络不稳定，请稍候再试"
                    }
                 }
                this.accountCheck = false
                return false
            })
        },
        checkVerificationCode(){
            let verificationCode = this.verificationCode
            if (verificationCode === "") {
                this.verificationCodeError = "请输入接收到的验证码"
                return false
            } else if (!/^\d{6}$/.test(verificationCode)){
                this.verificationCodeError = "请输入有效的六位数字验证码"
                return false
            } else {
                this.verificationCodeError = ""
                return true
            }
        },
         //用户名校验
        checkUsernameFormat(){
            let val = this.username
            //中文，字母，数字或其组合的形式
            let out = isUserName(val)
            switch (out.code) {
                case 100: this.usernameError = "";break
                case 101: this.usernameError = "请输入您的姓名";break
                default: this.usernameError = "请输入有效的姓名"
            }
            return out.result
        },
        checkPasswordFormat(){ //密码校验
            let val = this.password
            let out = isPassword(val)
            switch (out.code){
                case 100: this.passwordError = "";break
                case 101: this.passwordError = "请初始化登录密码";break
                case 201: this.passwordError = "密码不能包含空格";break
                case 204: this.passwordError = "密码长度不能低于6位";break
                case 205: this.passwordError = "密码长度不能超过32位";break
                case 202: this.passwordError = "密码不能全为数字";break
                case 203: this.passwordError = "密码不能全为字符";break
                case 206: this.passwordError = "密码不能全为字母";break
                default: this.passwordError = "密码格式错误"
            }
            return out.result
        },
        async login(){
           if (!(await this.checkAccountExist(true))){
                return 
            }

            this.checkVerificationCode()
            if(this.verificationCodeError|| this.accountError){
                return
            }
           
            this.logining = true
            let opcode =  await opcode_post({
                captcha: this.verificationCode,
                contact: this.account,
                service: this.accountExisted ? "LOGIN" : "REGIST"
            }).then(res => {
                return res.data.data.operationCodeInfo.opcode
            }).catch( err => {
                this.verificationCodeError = "验证码校验未通过"
                this.logining = false
            })

            if(!opcode){
                return 
            }
             if (this.accountExisted){
                await verificationCodeSession({
                    contact: this.account,
                    opcode
                }).then(async res => {
                    let session = res.data.data.session
                    let loginLocalStatus = this.loginLocalStatus
                    
                    loginLocalStatus.setLogin(true)
                    loginLocalStatus.setUserWsid(session.userWsid)
                    loginLocalStatus.setActiveUserWsid(session.userWsid)
                    this.userId = session.userWsid
                    
                }).catch(err => {
                    this.clearInfo()
                    this.errorInfo = "登录失败"
                    this.logining = false
                    console.error(err)
                })
                let accounts = await getUserAccounts({
                        userWsid:this.userId,
                        limit: 10000
                    }).then(res => {
                        this.accounts = res.data.data.accounts
                        return res.data.data.accounts
                    }).catch(err => {
                        console.error(err)
                        this.logining = false
                    })
                    this.getCurrentActionParticipant().then(res => {
                        this.logining = false
                        location.href = `/wesign/envelopes/${this.envelopeWsid}/detail`
                    }).catch(err => {
                        this.logining = false
                        console.error(err)
                        if (err.message === "ERROR_NOT_IN_ENVELOPE_FLOW"){
                            this.$alert("您不是该文件的签署者，无访问权限。", "提示", {
                                confirmButtonText: "查看其他文件",
                                cancelButtonText: "取消",
                                showCancelButton:true,
                                callback: action => {
                                    if (action === "confirm"){
                                        location.href ="/wesign/envelopes"
                                    }
                                },
                                type: "warning"
                            })
                        }
                    })
            } else {
                await usersRegist({
                    nickname: this.account, //用户名
                    account: this.account, //联系方式
                    password: this.password,
                    registFrom: "WEB", //来源  当然是默认WEB啦~~~
                    loginNow: true,
                    opcode //操作码
                }).then(res => {
                    let session = res.data.data.user.session
                    let loginLocalStatus = this.loginLocalStatus
                    this.logining = false
                    loginLocalStatus.setLogin(true)
                    loginLocalStatus.setUserWsid(session.userWsid)
                    loginLocalStatus.setActiveUserWsid(session.userWsid)
                    location.href = `/wesign/envelopes`
                }).catch(err => {
                    this.clearInfo()
                    this.errorInfo = "注册失败"
                    this.logining = false
                })
            }
        },
        async getCurrentActionParticipant(){
            let loginLocalStatus = this.loginLocalStatus
            
            let accountParticipants =this.accounts.map(account =>{
                let participantWsid 
                if (account.enterpriseMemberWsid){
                    participantWsid = account.enterpriseMemberWsid
                } else {
                    participantWsid = account.userWsid
                } 
                return {
                    participantWsid,
                    userWsid:account.userWsid,
                }
            })

            let currentSequence = this.currentSequence
            let envelopeShownStatus = this.envelopeShownStatus
            let targetUserWsid 
            let userParticipants = this.participants.filter(item => accountParticipants.some(ele => item.authorWsid === ele.participantWsid))
            //当前用户不在信封流程
            if (userParticipants.length === 0){
                throw new Error("ERROR_NOT_IN_ENVELOPE_FLOW")
            }
            
            //为当前阶段的
            let nowUserParticipants = userParticipants.filter(participant => participant.assignedSequence === currentSequence 
                && participant.status === "ING_WAIT")
          
            // //当前阶段没人
            if (nowUserParticipants.length === 0){
                if (userParticipants.filter(participant => participant.assignedSequence > currentSequence).length > 0){
                    let targetUserMeberWsid = userParticipants.filter(participant => participant.assignedSequence > currentSequence)[0].authorWsid
                    if (/WSID_EMEM_/.test(targetUserMeberWsid)){
                        targetUserWsid = accountParticipants.find(account=>account.participantWsid ===targetUserMeberWsid).userWsid
                    } else {
                        targetUserWsid = targetUserMeberWsid
                    }
                } 
            } else {
                let targetUserMeberWsid = nowUserParticipants[0].authorWsid 
                if (/WSID_EMEM_/.test(targetUserMeberWsid)){
                    targetUserWsid = accountParticipants.find(account=>account.participantWsid ===nowUserParticipants[0].authorWsid).userWsid
                } else {
                    targetUserWsid = nowUserParticipants[0].authorWsid
                }
            }

            if(targetUserWsid){
                await changeSession({
                    userWsid: loginLocalStatus.activeUserWsid,
                    destinationWsid: targetUserWsid 
                }).then(_ => {
                    loginLocalStatus.setActiveUserWsid(targetUserWsid)
                })
            } else {
                return location.href = `/wesign/envelopes/${this.envelopeWsid}/detail`
            }
        }
    },
    components: { captchaButton, externalFrame }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.form-item{
    margin-bottom: 10px;
}
.public-height{
    text-align:center;
    margin: 10px auto
}
.bottom{
    margin-bottom: 10px;
}
.info-name{
    color:@color-main;
}
.tip{
    margin-bottom:20px;
}
.center{
    text-align: center;
    line-height: 25px;
    color:@color-font-regular
}
.tip-info{
    margin-bottom: 5px;
}
</style>