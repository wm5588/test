class MemeryStorage{
    
    constructor(){
        this.map = new Map()
    }

    get length(){
        return this.map.size
    }

    key(index){
        return this.map.keys()[index]
    }

    getItem(key){
        if (typeof key !== "string") throw new TypeError("key must be a string")
        return this.map.get(key)
    }

    setItem(key, value){
        if (typeof key !== "string") throw new TypeError("key must be a string")
        this.map.set(key, value)
    }

    removeItem(key){
        if (typeof key !== "string") throw new TypeError("key must be a string")
        this.map.delete(key)
    }

    clear(){
        this.map = new Map()
    }

}

class ObjectStorage{
    constructor(){
        this.core = ObjectStorage.getStorage()
    }

    static localStorage = window.localStorage
    static sessionStorage = window.sessionStorage
    static memeryStorage = new MemeryStorage()

    static getStorage(){
        if (localStorage){
            return localStorage
        } else if (sessionStorage){
            return sessionStorage
        } else {
            return memeryStorage
        }
    }

    get length(){
        return this.core.length
    }

    key(index){
        return this.core.key(index)
    }

    getItem(key){
        let obj = this.core.getItem(key)
        try {
            obj = JSON.parse(obj)
        } catch(e) {
            return null
        }
        return obj
    }

    setItem(key, obj){
        try {
            obj = JSON.stringify(obj)
        } catch(e) {
            return
        }
        this.core.setItem(key, obj)
    }

    removeItem(key){
        this.core.removeItem(key)
    }

    clear(){
        this.core.clear()
    }
}

let objectStorage = new ObjectStorage()

export default objectStorage