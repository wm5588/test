import axios from "@interfaces/axios.js"

function imgcaptcha(obj) {
    let {
        type = "default" //请求获取验证码的类型
    } = obj

    return axios.get("/api/common/imgcaptcha", {
        params: {
            type
        }
    })
}

export default imgcaptcha
