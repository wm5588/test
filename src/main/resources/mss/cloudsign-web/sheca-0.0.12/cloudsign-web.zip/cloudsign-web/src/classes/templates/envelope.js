/*主要用于模板使用时信封数据的转化*/
import {FrontParticipant} from "@classes/envelopes/participants.js"
import { EnvelopeBaseForm } from "@classes/envelopes/forms"

function buildEnvelopeInfoData(infoConfig){ //构建基础信封表单数据
    let envelopInfoData = []
    infoConfig.forEach(infoConfig => {
        let info = {
            value: infoConfig.type === "CHECKBOX" ? [] : 0,
            infoId: infoConfig.infoId,
        }
        if (infoConfig.type === "SELECT" || infoConfig.type === "SINGLE_CHECKBOX"){
            let options = infoConfig.options.filter(_ => _.default)
            if (options.length > 0){
                info.value = options[0].optionId
            } else {
                info.value = 0
            }
        } else if (infoConfig.type === "CHECKBOX"){
            let options = infoConfig.options.filter(_ => _.default)
            if (options.length > 0){
                options.forEach(item => {
                    info.value.push(item.optionId)
                })
            } else {
                info.value = []
            }
        } else {
            info.value = infoConfig.default
        }
        envelopInfoData.push(info)
    })
    return envelopInfoData
}

function translateParticipantFromConfig(templateConfig){ //解析模板参与者配置
    let actionConfigs = templateConfig.actionConfigs
    let participantConfigs = templateConfig.participantConfigs
    let processGroupConfigs = templateConfig.processGroupConfigs
    let processParticipants = templateConfig.processParticipants
    let mainProcessParticipant = findMainProcessParticipant(templateConfig)
    let participantsIdArray = mainProcessParticipant.participants
    let participants = []
    participants = participantsIdArray.map(id => {
        let processParticipant = processParticipants.find(_ => _.id === id)
        let configId = processParticipant.config
        let participantConfig = participantConfigs.find(_ => _.id === configId)

        let optionalActions = participantConfig.optionalActions.map(id => {
            return actionConfigs.find(_ => _.id === id)
        })
        return {
            id: processParticipant.id,
            name: processParticipant.name,
            type: participantConfig.type,
            participants: participantConfig.optionalParticipantInfos,
            customizable: participantConfig.customizable,
            defaultActionId: participantConfig.defaultActionId,
            roleChangeable: participantConfig.roleChangeable,
            optionalActions: optionalActions
        }
    })
    return participants
}   
function translateParticipantFromConfigToFront(templateConfig){
    let participantConfig = translateParticipantFromConfig(templateConfig)
    let participants = participantConfig.map(_ => {
        let frontData = new FrontParticipant()
        frontData.id = _.id
        frontData.type = _.type
        //前端页面默认展示optionalParticipantInfos里面的第一个参与者
        if (_.participants.length > 0) {
            let participant = _.participants[0]
            frontData.enterpriseName = participant.enterpriseName
            frontData.contact = participant.contact
            frontData.name = participant.name
        }
        let actionType = _.optionalActions[0].envelopeAction
        frontData.actionType = actionType
        //主要存放额外的参与者option部分、actionTyep
        let metadata = {}
        metadata.optionalParticipantInfos = _.participants
        metadata.optionalActions = _.optionalActions
        metadata.customizable = _.customizable

        frontData.metadata = metadata

        return frontData
    })
    return participants
}

function findMainProcessParticipant(templateConfig){
    let mainProcessGroupId = templateConfig.mainProcessGroupId
    let processParticipants = templateConfig.processParticipants
    let processParticipant = processParticipants.filter(_ => _.id === mainProcessGroupId)[0]
    return processParticipant
}

function translateFormToFront(templateConfig){
    let envelopeForms = templateConfig.documentForms.map(form => {
        let newForm = new EnvelopeBaseForm()
        newForm.random = form.id
        newForm.type = form.type
        newForm.docId = form.docId
        newForm.page = form.docPage
        newForm.position = form.position
        newForm.participantProcessId = form.participantProcessId
        return newForm
    })
    return envelopeForms
}
function mergeInfoConfigs(envelopInfoData, infosFormConfigsData){
    let infoMap = {}
    let configsData = infosFormConfigsData
   
    configsData.forEach(config => {
        infoMap[config.infoId] = config
    })
    envelopInfoData.forEach(data => {
        if (infoMap[data.infoId]){
            let index = configsData.findIndex(_ => _.infoId === data.infoId)
            configsData[index] = data
        }
    })
    return configsData
}

function findDocument(form, docConfigs, envelopDocumentsData){
    let doc = ""
    doc = envelopDocumentsData.find(doc => doc.configId === form.docId)
    if (doc){
        return doc
    } else { //兼容旧模板配置中直接让表单和文件fieldId关联，而不是文件配置id
        let config = docConfigs.find(c => c.fileId === form.docId)
        if (!config) return ""
        form.docId = config.id
        doc = envelopDocumentsData.find(doc => doc.configId === form.docId)
        if (!doc) return ""
        return doc
    }
}

export {
    buildEnvelopeInfoData,
    translateParticipantFromConfig,
    translateParticipantFromConfigToFront,
    findMainProcessParticipant,
    translateFormToFront,
    mergeInfoConfigs,
    findDocument
}
export default {
    buildEnvelopeInfoData,
    translateParticipantFromConfig,
    translateParticipantFromConfigToFront,
    findMainProcessParticipant,
    translateFormToFront,
    mergeInfoConfigs,
    findDocument
}