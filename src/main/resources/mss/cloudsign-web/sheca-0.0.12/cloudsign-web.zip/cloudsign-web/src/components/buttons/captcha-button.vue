<!--
    @id     sys-btn-cap
    @desc   发送验证码组件
    @level  system
    @props
        size:String 大小和element同步
        *contact:String  联系方式
        *service:String  验证码类型 
            REGIST：用户注册
            LOGIN：用户登录
            ACTIVITY：激活用户
            SIGN：签名
            RESET_PWD：重置密码
            IDENTITY：实名认证
            BIND_CONTACT：覆盖式修改绑定联系方式
            VERIFICATION_CODE_LOGIN：验证码登录
            CONFIRM_AUTH: 验证
        *disabled:Boolean 是否禁用
        type: string 按钮方式
            SMS 短信
            VOICE 语音
    @events
        error(msg)  错误  "ERROR CONTACT" 错误的联系人  "SEND BUSY" 请求频繁    "SEND ERROR" 发送失败
        sending     发送中
        sendsuccess 发送成功
    @auther 陈曦源 周雪梅
    @date   2019-05-21 19:16:28
-->
<template>
    <el-button  v-if="type==='SMS'" :type="timeShow ? 'default' : 'primary'" :loading="sending" :disabled="disabled" :size="size" @click="sendVerifyCode">
        <template v-if="timeShow">{{timeShow}}s可重新获取</template>
        <template v-else><i class="icon-email email"></i>获取验证码</template>
    </el-button>
    <el-button v-else :type="voiceTimeShow ? 'default' : 'primary'" :loading="sending" :disabled="disabled" :size="size" @click="sendVerifyVoiceCode">
            <template v-if="voiceTimeShow">{{voiceTimeShow}}s可重新获取</template>
            <template v-else><i class="icon-phone-volume phone"></i>获取验证码</template>
    </el-button>
</template>

<script>
import {isPhone, isEmail} from "@wesign/check"
import {sms_code_post, mail_code_post, voice_code_post} from "@interfaces/auth/captcha.js"
import { ERROR_CODES } from "@errors/code.js"
import { MessageBox } from "element-ui"

export default {
    props: {
        size: {
            type: String,
        },
        contact: {
            type: String,
            required: true
        },
        service: { 
            type: String,
            required: true
        },
        code: String,
        disabled: {
            type: Boolean,
            default: false
        },
        type: { 
            type: String,
            default: "SMS"
        },
        developerEnterpriseWsid: String
    },
    data(){
        return {
            nextTime: 0,
            voiceNextTime: 0,
            voiceTimeShow: 0,
            timeShow: 0,
            sending: false
        }
    },
    watch: {
        service(){
            this.init()
        }
    },
    created(){
        this.init()
    },
    methods: {
        init(){
            let gloablCaptchaNextTime = parseInt(localStorage.getItem(`gloablCaptchaNextTime_${this.service}`)) || 0 
            let gloablVoiceCaptchaNextTime = parseInt(localStorage.getItem(`gloablVoiceCaptchaNextTime_${this.service}`)) || 0 

            this.nextTime = gloablCaptchaNextTime
            this.voiceNextTime = gloablVoiceCaptchaNextTime

            this.countDown()
            this.voiceCountDown()
        },
        sendVerifyVoiceCode(){
            let service = this.service
            let contact = this.contact
            let code = this.code
           
            if (!this.contact || !isPhone(contact).result){
                this.$emit("error", "ERROR_CONTACT")
                return
            }

            if (this.voiceNextTime > Date.now()){
                this.$emit("error", "ERROR_SEND_BUSY")
                return
            }

            
            this.sending = true
            this.$emit("sending")

            voice_code_post({
                phone: contact,
                service: service
            }).then(body => {
                this.$emit("sendsuccess", true)
                this.voiceNextTime = Date.now() + 60 * 1000
                localStorage.setItem(`gloablVoiceCaptchaNextTime_${this.service}`, this.voiceNextTime)
                this.voiceCountDown()
            }).catch(err => {
                console.error(err)
                if (err.code){
                    switch (err.code){
                        case ERROR_CODES.TIMEOUT:
                            this.commonStatus = "ERROR_TIMEOUT" //超时
                            break
                        case ERROR_CODES.SMS_FREQUENTLY:
                        case ERROR_CODES.SMS_FREQUENTLY_DIY:
                            this.alert("获取验证码太频繁，<br/>请稍等1~2分钟再重新获取。")
                            
                            this.voiceNextTime = Date.now() + err.data.expireIn * 1000
                            localStorage.setItem(`gloablVoiceCaptchaNextTime_${this.service}`, this.voiceNextTime)
                            this.voiceCountDown()
                            break
                        case ERROR_CODES.VOICE_IDENTIFY_AMOUNT_OUT_LIMIT: //今日可接收验证码超出数目
                            this.alert("接收验证码次数已超出今日上限，<br/>请明天再获取。")
                            break
                        case ERROR_CODES.VOICE_PHONE_IN_BLACKLIST:
                            this.alert("您的手机号被短信运营商列入黑名单，验证码发送失败。<br/>怎么办？<br/>解除黑名单，请联系客服:021-962600。")
                            break
                        default:
                            this.commonStatus = "ERROR_SEND_FAILED"
                    }
                } else {
                    this.commonStatus = "ERROR_SEND_FAILED"
                }
            }).then(_ => {
                this.sending = false
            })
        },
        sendVerifyCode(){
            let service = this.service
            let contact = this.contact
            let code = this.code
           
            if (!this.contact || !isPhone(contact).result && !isEmail(contact).result){
                this.$emit("error", "ERROR_CONTACT")
                return
            }

            if (this.nextTime > Date.now()){
                this.$emit("error", "ERROR_SEND_BUSY")
                return                
            }

            let post
            this.sending = true
            if (isPhone(contact).result){
                post = sms_code_post({
                    phone: contact,
                    service: service,
                    pusherChannelTag: this.developerEnterpriseWsid,
                    code: code
                }).then(body => {
                    this.$emit("sendsuccess", true)
                    this.nextTime = Date.now() + 60 * 1000
                    localStorage.setItem(`gloablCaptchaNextTime_${this.service}`, this.nextTime)
                    this.countDown()
                }).catch(err => {
                    console.error(err)
                    if (err.code){
                        switch (err.code){
                            case ERROR_CODES.TIMEOUT:
                                this.$emit("error", "ERROR_TIMEOUT") //超时
                                break
                            case ERROR_CODES.SMS_FREQUENTLY:
                            case ERROR_CODES.SMS_FREQUENTLY_DIY:
                                this.alert("获取验证码太频繁，<br/>请稍等1~2分钟再重新获取。")
                                this.nextTime = Date.now() + err.data.expireIn * 1000
                                localStorage.setItem(`gloablCaptchaNextTime_${this.service}`, this.nextTime)
                                this.countDown()
                                break
                            case ERROR_CODES.SMS_IDENTIFY_AMOUNT_OUT_LIMIT: //今日可接收验证码超出数目
                                this.alert("接收验证码次数已超出今日上限，<br/>请明天再获取。")
                                break
                            case ERROR_CODES.SMS_PHONE_IN_BLACKLIST:
                                this.alert("您的手机号被短信运营商列入黑名单，验证码发送失败。<br/>怎么办？<br/>解除黑名单，请联系客服:021-962600。")
                                break
                            default:
                                this.$emit("error", "ERROR_SEND_FAILED")
                        }
                    } else {
                        this.$emit("error", "ERROR_SEND_FAILED")
                    }
                })
            } else if (isEmail(contact).result){
                post = mail_code_post({
                    email: contact,
                    service: service,
                    pusherChannelTag: this.developerEnterpriseWsid,
                    code: code
                }).then(body => {
                    this.$emit("sendsuccess", true)
                    this.nextTime = Date.now() + 60 * 1000
                    localStorage.setItem(`gloablCaptchaNextTime_${this.service}`, this.nextTime)
                    this.countDown()
                }).catch(err => {
                    console.error(err)
                    this.$emit("error", "ERROR_SEND_FAILED")
                })
            }

            this.$emit("sending")
            post.then(_ => {
                this.sending = false
            })
        },
        countDown(){
            let nextTime = this.nextTime
            if (nextTime - Date.now() > 0){
                this.timeShow = parseInt((nextTime - Date.now()) / 1000)
                this.$emit("timeShow", true)
                setTimeout(this.countDown, 200)
            } else {
                this.timeShow = 0
            }
        },
        voiceCountDown(){
            let voiceNextTime = this.voiceNextTime
            if (voiceNextTime - Date.now() > 0){
                this.voiceTimeShow = parseInt((voiceNextTime - Date.now()) / 1000)
                this.$emit("timeShow", true)
                setTimeout(this.voiceCountDown, 200)
            } else {
                this.voiceTimeShow = 0
            }
        },
        alert(message){
            MessageBox.alert(message, "提示", {
                type: "warning",
                dangerouslyUseHTMLString: true,
                confirmButtonText: "我知道了"
            }).then(_ => {})
        }
    }

}
</script>
<style scoped>
.email,.phone{
    margin-right:3px;
}
</style>