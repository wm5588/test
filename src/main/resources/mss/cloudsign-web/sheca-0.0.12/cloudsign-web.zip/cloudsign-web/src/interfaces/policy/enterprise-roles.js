import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /policy/enterprise-roles
 * @method GET
 * @desc   获取企业角色列表
 * @author 陈曦源
 * @date   2018-02-05 15:05:25
 * ----------------------------------------------------
 */
export function getEnterpriseRoles(obj) {
    let {
        enterpriseWsid,
        filters
    } = obj

    return axios.get("/api/policy/enterprise-roles", {
        params: {
            enterpriseWsid,
            filters 
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /policy/enterprise-roles
 * @method GET
 * @desc   获取企业角色列表
 * @author 周雪梅
 * @date   2019-03-14 16:27:22
 * ----------------------------------------------------
 */
export function getEnterpriseRolesGroupList(obj) {
    let {
        enterpriseWsid,
        filters
    } = obj

    return axios.get("/api/policy/enterprise-roles-list", {
        params: {
            enterpriseWsid,
            filters 
        }
    })
}

/**
 * ----------------------------------------------------
 * @method  GET
 * @path    /api/policy/:enterpriseWsid/groups
 * @desc    获取企业角色列表（自定义）
 * @date    2019-03-13 21:40:23
 * @author  周雪梅
 * ----------------------------------------------------
 */
export function getEnterpriseRolesGroups(obj) {
    let {
        enterpriseWsid,
        groupWsid,
        fields,	
        filters,	
        sorts,	
        type,	
        current
    } = obj

    return axios.get(`/api/policy/${enterpriseWsid}/groups`, {
        params: {
            groupWsid,
            fields,	
            filters,	
            sorts,	
            type,	
            current
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/policy/enterprise-roles/author
 * @method GET
 * @desc   获取指定用户企业角色列表
 *         传入puser就查所有的，传入euser就查这个企业下的，传入puser和enterpriseWsid等价于euser
 * @author 陈曦源
 * @date   2018-03-20 15:26:13
 * ----------------------------------------------------
 */
export function getUserRoles(obj) {
    let {
        authorWsid,
        enterpriseWsid
    } = obj

    return axios.get("/api/policy/enterprise-roles/author", {
        params: {
            authorWsid,
            enterpriseWsid
        }
    })
}

/**
 * ----------------------------------------------------
 * @method  POST
 * @path    /api/policy/${enterpriseRoleWsid}
 * @desc    指定企业角色绑定用户
 * @date    2019-03-13 21:40:23
 * @author  周雪梅
 * ----------------------------------------------------
 */
export function addUserRole(obj) {
    let {
        enterpriseRoleWsid,
        userWsids
    } = obj

    return axios.post(`/api/policy/${enterpriseRoleWsid}/authors`, {
        userWsids
    })
}

/**
 * ----------------------------------------------------
 * @method  GET
 * @path    /api/policy/${enterpriseRoleWsid}
 * @desc    查询指定企业角色成员
 * @date    2019-03-13 21:40:23
 * @author  周雪梅
 * ----------------------------------------------------
 */
export function getRoleMember(obj) {
    let {
        enterpriseRoleWsid,
        fields,	
        filters,
        offset,
        limit,	
    } = obj

    return axios.get(`/api/policy/${enterpriseRoleWsid}/authors`, {
        params: {
            fields,	
            filters,
            offset,
            limit,	
        }
    })
}

/**
 * ----------------------------------------------------
 * @method  DELETE
 * @path    /api/policy/${enterpriseRoleWsid}
 * @desc    删除指定企业角色绑定的用户
 * @date    2019-03-13 21:40:23
 * @author  周雪梅
 * ----------------------------------------------------
 */
export function deleteUserRole(obj) {
    let {
        enterpriseRoleWsid,
        authorWsids
    } = obj

    return axios.delete(`/api/policy/${enterpriseRoleWsid}/authors`, {
        data: {
            authorWsids
        }
    })
}

