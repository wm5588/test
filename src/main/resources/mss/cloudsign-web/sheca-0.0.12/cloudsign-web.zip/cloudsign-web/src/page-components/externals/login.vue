<template lang="html">
    <externalFrame>
        <div style="padding: 20px">
            <login :targetURL="targetURL" @loginsuccess="loginsuccess"></login>
        </div>
    </externalFrame>
</template>

<script>
import externalFrame from "@page-components/frames/external-frame.vue"
import login from "@components/login/login.vue"
import Tab from "@components/commons/tabs/tab-default.vue"
import qs from "qs"

export default {
    data(){
        return {
            targetURL: "",
        }
    },
    created(){
        let query = qs.parse(location.search.substr(1))
        this.targetURL = query.targetURL ? decodeURIComponent(query.targetURL) : undefined
    },
    methods: {
        loginsuccess: function (userWsid) {
            if (this.type == "PRICE"){
                location.href = "/wesign/change"
            } else {
                location.href = "/wesign"
            }
        }
    },
    components: { login, externalFrame, Tab }
}
</script>
<style lang="less">
@import "~@styles/variable.less";
.tab-box{
    border-bottom:1px solid @color-border
}
.login-tab-nav{
    justify-content: center;
    padding-top: 15px !important;
}
.login-tab-nav .tab{
    width:50%;
    margin-right:0 !important;
}
</style>