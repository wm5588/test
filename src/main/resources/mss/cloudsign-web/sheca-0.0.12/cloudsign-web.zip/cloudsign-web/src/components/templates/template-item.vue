<template>
    <div class="template-item-main">
        <div class="template-item-top">
            <img :src="imgSrc" v-if="imgSrc"/>
        </div>
        <div class="template-item-footer">
            <p class="template-title">{{templateData.name}}</p>
        </div>
        <div class="btn-group">
            <div class="container">
                <el-button type="text" size="small" round class="btn" @click="startTemplate" v-if="permission.TEMPLATE_USE && templateData.status==='ENABLE'">使用模板</el-button>
                <el-button type="text" size="small" round class="btn" @click="enableThisTemplate" v-if="permission.TEMPLATE_ENABLE && templateData.status==='DRAFT'">启用模板</el-button>
                <el-button type="text" size="small" round class="btn" @click="editTemplate" v-if="templateData.status!='DISABLE'&& permission.TEMPLATE_EDIT">编辑模板</el-button>
                <el-button type="text" size="small" round class="btn" @click="reTemplateName" v-if="templateData.status!='DISABLE' && permission.TEMPLATE_RENAME">重命名</el-button>
                <el-button type="text" size="small" round class="delete-btn" @click="deleteThisTempalte" v-if="permission.TEMPLATE_DELETE && templateData.status==='DRAFT'">删除</el-button>
            </div>
        </div>
        <!-- 上传模板头像组件弹框 -->
        <el-dialog title="上传模板图标" ref='dialog' width="500px" :visible.sync="showDialog" :close-on-click-modal="false" :append-to-body="true">
            <avatarEditUpload v-if="showDialog" :defaultSrc="localImageSrc" :templateWsid="templateData.wsid" @e-commit="closeDialog"></avatarEditUpload>
        </el-dialog>

        <!-- 模板-->
        <el-dialog title="模板重命名" :visible.sync="renameDialog" :close-on-click-modal="false" :append-to-body="true" width="600px">
          <div class="create-container" @click.stop="">
            <div class="template-name">
              <label>模板名称</label>
              <input placeholder="请输入模板名称" v-model="templateName"/>
            </div>
            <div slot="footer" class="dialog-footer">
              <el-button  @click="renameDialog=false">取消</el-button>
              <el-button type="primary" @click="modifyName">确定</el-button>
            </div>
          </div>
        </el-dialog>
    </div>
</template>
<script>
import { selectFile } from "@commons/util.js"
import { checkAuthStatus } from "@commons/check-status.js"
import { checkEnterpriseAuthStatus } from "@commons/check-enterprise-status.js"

import avatarEditUpload from "@components/modal/template-avatar-edit-upload.vue"
import {enableTemplate, updateTemplate, templateToEnvelop, deleteTemplate, disableTemplate} from "@interfaces/templates/bsts.js"

export default {
    props: {
        templateData: {
            type: Object,
        }
    },
    data(){
        return {
            checked: false,
            showDialog: false,
            renameDialog: false,
            localImageSrc: "",
            templateName: "",
            popoverVisible: false
        }
    },
    computed: {
        imgSrc(){
            return this.templateData.fileHref.href || ""
        },
        userEdition(){
            return this.$store.getters.userEdition
        },
        permission(){
            return this.$store.getters
        },
        userWsid(){ 
            return this.$store.getters.userWsid
        },
        enterpriseAuthorWsid(){ //企业拥有者id
            return (this.$store.getters.enterpriseAuthorWsid)
        },
    },
    methods: {
        reTemplateName(){
            this.renameDialog = true
            this.templateName = this.templateData.name || ""
        },
        modifyName(){
            if (!this.templateName){
                this.$message.warning("请输入模板名称！")
                return 
            }
            let name = this.templateName
            updateTemplate({
                name,
                bstWsid: this.templateData.wsid
            }).then(res => {
                this.$message.success("模板重命名成功")
                this.renameDialog = false
                this.$emit("update")
            }).catch(err => {
                this.$message.error("模板重命名失败")
            })
        },
        selectImage() {
            selectFile("image/jpg,image/jpeg,image/png,image/gif,image/bmp,image/tiff").then(file => {
                this.editFile(file)
            }).catch(err => {
                this.$message.error("选择的文件类型错误，请选择正确的图片文件")
            })
        },
        editFile: function(file){
            let imgName = file.name 
            if (/\.(jpg|png|jpeg|gif|bmp|tiff)$/i.test(imgName)){
                if (!window.FileReader){
                    this.$message.error("浏览器不兼容FileReader")
                    return
                }
                else {
                    let reader = new FileReader()
                    reader.readAsDataURL(file)
                    reader.onload = item => {
                        this.showDialog = true
                        this.localImageSrc = item.target.result
                    }
                }
            } else {
                this.$message.info("请选择有效的图片文件")
            }
        },
        closeDialog() {
            this.showDialog = false
            this.$emit("update")
        },
        deleteThisTempalte(){
            this.$confirm("您确认要删除该模板吗？删除后将无法恢复！", "删除模板", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {
                // if (this.templateData.status === "ENABLE"){
                //     disableTemplate({
                //         bstWsid: this.templateData.wsid
                //     }).then(res => {
                //         if (res.data.data.bst.status === "DISABLE"){
                //             deleteTemplate({
                //                 bstWsid: this.templateData.wsid
                //             }).then(res => {
                //                 this.$message.success("删除模板成功")
                //                 this.$emit("deleteUpdate")
                //             }).catch(err => {
                //                 this.$message.error("删除模板失败")
                //             })
                //         } else {
                //             this.$message.error("删除模板失败")
                //         }
                //     }).catch(err => {
                //         this.$message.error("删除模板失败")
                //         console.error(err)
                //     })
                // } else {
                deleteTemplate({
                    bstWsid: this.templateData.wsid
                }).then(res => {
                    this.$message.success("删除模板成功")
                    this.$emit("deleteUpdate")
                }).catch(err => {
                    this.$message.error("删除模板失败")
                })
                // }
            }).catch(() => {})
        },
        enableThisTemplate(){
            this.$store.dispatch("getTemplateData", this.templateData.wsid).then(res => {
                let templateConfig = this.$store.state.template.templateConfig
                if (templateConfig.processParticipants.length <= 1) return this.$message.warning("至少添加一个签署方才能启用此模板!")
                enableTemplate({
                    bstWsid: this.templateData.wsid
                }).then(res => {
                    this.$message.success("启用模板成功")
                    this.$emit("enableTemplate")
                }).catch(err => {
                    this.$message.error("启用模板失败")
                })
            })
        },
        editTemplate(){
            this.$router.push({
                name: "template-editor",
                params: {
                    templateId: this.templateData.wsid
                }
            })
        },
        async startTemplate(){
            if (this.templateData.status === "ENABLE"){ //创建一个信封
                let userIddtvStatus = this.$store.getters.userIddtvStatus
                let enterpriseAuthStatus = this.$store.getters.enterpriseIddtvStatus
                let userWsid = this.$store.getters.activeUserWsid

                if (this.userEdition === "e" && !await checkEnterpriseAuthStatus(this.$router, enterpriseAuthStatus) || !await checkAuthStatus(this.$router, userIddtvStatus)){
                    return 
                } 
                if (this.userEdition === "p" && !await checkAuthStatus(this.$router, userIddtvStatus)){
                    return 
                }

                if (this.$store.getters.totalCharges === 0){
                    this.$confirm("签署余额不足，请前往充值", "提示", {
                        confirmButtonText: "立即前往充值",
                        cancelButtonText: "取消",
                        callback: action => {
                            if (action === "confirm"){
                                if (this.userEdition === "p"){
                                    this.$router.push({
                                        name: "person-purchase"
                                    })
                                } else {
                                    this.$router.push({
                                        name: "enterprise-purchase"
                                    })
                                }
                            }
                        },
                        type: "warning"
                    })
                    return
                }
                //模板转换信封
                templateToEnvelop({
                    bstWsid: this.templateData.wsid,
                    senderWsid: userWsid,
                    envelopeFlag: 0, //普通信封
                    metadata: null
                }).then(res => {
                    let data = res.data.data
                    let envelopeId = data.envelope.basicInfo.envelopeWsid
                    let templateId = data.envelope.basicInfo.templateWsid
                    this.$router.push({
                        name: "template-use",
                        params: {
                            envelopeId: envelopeId
                        },
                        query: {
                            templateId: templateId
                        }
                    })
                }).catch(err => {
                    this.$message.error("创建失败，请重试")
                    console.error(err)
                })
               
            } else { //编辑更新一个信封
                this.editTemplate()
            }
        }
    },
    components: {
        avatarEditUpload
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.template-item-main{
    .info-block-default;
    padding: 0;
    display: inline-block;
    .template-item-head{
        position: relative;
        display: flex;
        height: 26px;
        color: #666666;
        align-items: center;
        justify-content: space-between;
        .el-icon-more{
            margin-right: 8px;
        }
    }
    .template-item-top{
        height: 75%;
        background-color:rgba(122, 191, 255, 0.8);
        position: relative;
        .template-item-title{
            position: absolute;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1;
            background: rgba(0,0,0,0);
            .check-box{
                float: left;
                margin: 5px 10px;
            }
            .more-option{
                cursor: pointer;
                padding: 5px 10px;
                display: inline-block;
                position: absolute;
                z-index: 9;
                right: 0;
            }
            .icon-set{
                color: @color-white;
            }
        }
        img{
            position: absolute;
            left: 0;
            right: 0;
            width: 100%;
            z-index: 0;
            height: 100%;
        }
    }
    .template-item-footer{
        height: 25%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        text-indent: 12px;
        .template-title{
            font-size: 14/16 em;
            color: @color-list-font;
            font-weight: bold;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .template-creator{
            font-size: 12/16 em;
            color: @color-list-font;
        }
    }
    &:hover{
        .btn-group{
            display: block;
        }
    }
    .btn-group{
        position: absolute;
        top: 0;
        bottom:0;
        width: 100%;
        background:rgba(255,255,255,0.7);
        display: none;
        .container{
            height: 100%;
            display: flex;
            flex-direction: column;
            width: 100%;
            justify-content: center;
            position: absolute;
            top: 0;
        }
        .btn{
            background: #fff;
            color: #0c7ffc;
            width: 65%;
            margin: 5px auto;
            border: 1px solid @color-main;
            font-size: 15*@px;  
                &:hover{
                    color: #fff;
                    background: #0c7ffc;
                }
        }
    }
}
.create-container {
  padding: 0 50px;
  .el-dialog__header{
    padding: 0;
  }
  label,
  input {
    vertical-align: middle;
    display: inline-block;
    border: none;
  }
  label {
    color: #666666;
    line-height: 60px;
    min-width: 80px;
  }
  .template-name{
    border-bottom: 1px solid #dddddd;
  }
  .dialog-footer{
    text-align: right;
    margin-top: 30px;
  }
}
.delete-btn{
    background: #fff;
    color: @color-danger;
    width: 65%;
    margin: 5px auto;
    border: 1px solid @color-danger;
    font-size: 15*@px;  
        &:hover{
            color: #fff;
            background: @color-danger;
        }
    }
</style>
<style lang="less">
    .template-popper-list{
        min-width:60px !important;
        margin-left:2px !important;
        margin-right:0 !important;
        outline:none;
        cursor: pointer;
        li {
            &:hover{
                color: #4e82ee;
            }
        }
    }
</style>
