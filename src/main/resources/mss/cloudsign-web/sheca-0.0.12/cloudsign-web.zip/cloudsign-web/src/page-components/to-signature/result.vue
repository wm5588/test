<template>
    <div class="page-container">
        <div class="header">
            <div class="header-left">
                <img class="logo" :src="logoWhiteURL">
            </div>
        </div>
        <div class="title">大家签电子签名商户页面，签署结果提示</div>
        <div class="center">
            <center>
                <i class="icon-complete"></i>
            </center>
            <center style="margin-top: 20px;">
                <p>你已完成 <span>{{actionResult}}</span> 操作</p>
            </center>
        </div>
        <div class="signit">
            <img :src="require('@images/openapi-authorization/logo-ico.png')" style="width:20px">由大家签提供技术支持
        </div>
    </div>
</template>

<script>
import logoWhiteURL from "@images/wesign-logo-white.svg"
export default {
    data(){
        return {
            logoWhiteURL: logoWhiteURL,
        }
    },
    computed: {
        actionResult(){
            let result = this.$route.query.result
            switch (result){
                case "SIGNED":return "签署";break
                case "REJECTED":return "拒签";break
                case "PASSED":return "审核通过";break
                case "NOT_PASSED":return "审核不通过";break
                case "REVOKED":return "撤销";break
            }
        },
        pageCallback(){
            return this.$route.query.pageCallback
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.page-container{
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 0;
}
.header{
    height: 60px;
    margin: 0 auto;
    padding: 0 30px;
    background: @color-main;
     .header-left {
            float: left;
            line-height:60px;

            .logo{
                width: 100px;
            }
        }
}
.title{
    text-align:center;
    margin-top: 80px;
    font-size: @font-size-primary;
}
.signit{
    position:fixed;
    left:0;
    right:0;
    bottom:0;
    text-align:center;
}
.center{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    p{
        font-size: @font-size-primary;
        span{
            color: #000;
            font-weight: bold;
        }
    }
}
.icon-complete{
    color: @color-success;
    font-size: 100px;
}
</style>
