<template>
    <div>
        <div class="sys-rmain-header">
            <span class="bar-title"><i class="icon icon-finance"></i>消费记录</span>
            <div class="tab-nav">
                <router-link to="/user/info/payments/bill-records">账单记录</router-link>
                <router-link to="/user/info/payments/purchase-records">购买记录</router-link>
                <router-link to="/user/info/payments/invoice-claim">发票索取</router-link>
            </div>
        </div>
        <div class="sys-container-content">
            <router-view></router-view>
        </div>

    </div>
</template>

<script>
    export default{
        data:function(){
            return {
               
            }
        }
    }
</script>

<style lang="less" scoped>
    @import '../../styles/user/payments.less';
</style>