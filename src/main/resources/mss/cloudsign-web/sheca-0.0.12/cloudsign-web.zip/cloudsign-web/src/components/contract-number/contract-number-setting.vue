<template>
<div style="margin: 20px 0;">
    <div class="input-field">
        <div class="block">
            <span class="identification">固定标识</span>
            <el-tooltip placement="top">
                <div slot="content">
                    合同编号的一部分，比如标识合同所属公司/业务类型。<br/>
                    规则：公司名称简写-合同类型简写<br/>
                    示例：YQQ-LD<br/>
                    表示：大家签的劳动合同<br/>
                    <br/>
                    请根据您公司的编号管理规则输入</div>
                <el-input placeholder="标识合同类型/所属企业" maxlength="20" :value="numberMark" class="wesign-input" :class="{error:numberMarkErrMsg}"  
                    @input="$emit('update:numberMark', arguments[0])" @blur="checkNumberMark()"></el-input>
            </el-tooltip>
        </div>
        <div class="block">
            <span class="date">日期</span>
            <el-select :value="dateType" @change="$emit('update:dateType', arguments[0])" placeholder="请选择类型">
                <el-option
                v-for="item in dateOptions"
                :key="item.value"
                :label="item.value"
                :value="item.type">{{item.label}}
                </el-option>
            </el-select>
        </div>
        <div class="block">
            <span class="serial-number">流水号</span>
            <el-select :value="serialNumber" @change="$emit('update:serialNumber', arguments[0])" placeholder="请选择">
                <el-option
                v-for="item in serialNumberOptions"
                :key="item.value"
                :label="item.value"
                :value="item.type">{{item.label}}
                </el-option>
            </el-select>
        </div>
    </div>
    <span class="example" v-if="numberMark&&!numberMarkErrMsg">示例：{{numberMark}}-{{translateDateType(dateType)}}-{{serialNumber}}</span>
    <span class="transparent-block" v-if="numberMarkErrMsg"></span>
    <span class="error" v-if="numberMarkErrMsg">{{numberMarkErrMsg}}</span>
</div>
</template>
<script>
import { formatDate } from "@commons/util.js"
export default {
    props: {
        numberMark: String,
        numberDate: Object,
        serialNumber: String,
        dateType: String
    },
    data(){
        return {
            numberMarkErrMsg: "",
            dateOptions: [{
                value: formatDate(new Date(), "YY"),
                type: "YY",
                label: "按年，格式：YY"
            },
            {
                value: formatDate(new Date(), "YYYY"),
                type: "YYYY",
                label: "按年，格式：YYYY"
            }, {
                value: formatDate(new Date(), "YYMM"),
                type: "YYMM",
                label: "按年月，格式：YYMM"
            },
            {
                value: formatDate(new Date(), "YYYYMM"),
                type: "YYYYMM",
                label: "按年月，格式：YYYYMM"
            },
            {
                value: formatDate(new Date(), "YYMMdd"),
                type: "YYMMdd",
                label: "按年月日，格式：YYMMDD"
            },
            {
                value: formatDate(new Date(), "YYYYMMdd"),
                type: "YYYYMMdd",
                label: "按年月日，格式：YYYYMMDD"
            }],
            serialNumberOptions: [{
                value: "00~99",
                label: "2位编号：00~99",
                type: "00",
            },
            {
                value: "000~999",
                label: "3位编号：000~999",
                type: "000",
            },
            {
                value: "0000~9999",
                label: "4位编号：0000~9999",
                type: "0000",
            },
            {
                value: "00000~99999",
                label: "5位编号：00000~99999",
                type: "00000",
            },
            {
                value: "000000~999999",
                label: "6位编号：000000~999999",
                type: "000000",
            },
            {
                value: "0000000~9999999",
                label: "7位编号：0000000~9999999",
                type: "0000000",
            },
            {
                value: "00000000~99999999",
                label: "8位编号：00000000~99999999",
                type: "00000000",
            }]
        }
    },
    watch: {
        numberMark(nv){
            let timeTicker
            if (timeTicker){
                clearTimeout(timeTicker)
            }
            timeTicker = setTimeout(_ => {
                this.checkNumberMark()
            }, 600)

        }
    },
    methods: {
        checkNumberMark(){
            let reg = /^[A-Za-z0-9]+(-[A-Za-z0-9]+)*$/ig
            this.numberMark = this.numberMark.trim()
            if (this.numberMark === ""){
                this.numberMarkErrMsg = "请输入固定标识"
                return false
            }
            if (!reg.test(this.numberMark)){
                this.numberMarkErrMsg = "格式有误"
                return false
            }
            this.numberMarkErrMsg = ""
            return true
        },
        translateDateType(type){
            return this.dateOptions.find(el => el.type == type).value || this.formatDate(new Date(), "YYYY")
        },
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.input-field{
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    .block{
        display: flex;
        align-items: center;
        margin-right: 30px;
        margin-bottom: 5px;
    }
    .identification{
        margin-right:6px
    }
}
.error{
    color: @color-danger;
}
.transparent-block{
    display: inline-block;
    width: 68px;
}
.example{
    color: @color-main;
    line-height: 40px;
}
.wesign-input{
    display: block;
    width: 80%;
}
.serial-number,.date,.identification{
    display: inline-block;
    width: 70px;
}
</style>


