const IF_NOTIFICATION = (typeof Notification) !== "undefined"

class Notifyer{

    constructor(){
        this.router = null
        this.accept = false

        if (IF_NOTIFICATION){
            try {
                Notification.requestPermission().then(result => {
                    if (result === "granted"){
                        this.accept = true
                    }
                })
            } catch (error){
                //兼容safri老接口
                if (error instanceof TypeError) {
                    Notification.requestPermission(result => {
                        if (result === "granted"){
                            this.accept = true
                        }
                    })
                } else {
                    throw error
                }
            }
        }
    }

    init(router){
        this.router = router
    }

    notify(message){
        if (!this.accept || !IF_NOTIFICATION) return
        
        if (message.messageTitle === "【签署提醒】" || message.messageTitle === "【审核提醒】"){
            let notify = new Notification(message.messageTitle, {
                icon: "/img/logo-ico.ico",
                body: message.messageContent
            })

            notify.addEventListener("click", e => {
                this.router.push({
                    name: "envelope-detail",
                    params: {
                        envelopeId: message.attachMessage.envelopeWsid
                    }
                })
                window.focus()
            })
        }
    }
}

let notifyer = new Notifyer()

export {
    notifyer
}