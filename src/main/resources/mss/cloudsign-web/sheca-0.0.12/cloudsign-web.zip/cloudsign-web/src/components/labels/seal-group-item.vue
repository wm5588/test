<!--
    @id        ui-seal-group-iten
    @desc      印章分组
    @level     UI组件
    @author    潘维
    @date      2018-07-18 21:00:46
-->
<template lang="html">
    <li class="seal-group-item" @click="change">
        <el-popover
            ref="popover"
            placement="right-start"
            width="80"
            popper-class="wesign-popper-tree-list"
            v-model="popoverVisible"
            trigger="click">
            <ul style="text-align:left" v-if="!isParentNode">
                <li>
                    <span @click.stop="nodeAddChildGroup(node, data, store)" v-if="perimission.SEAL_GROUP_CREATE">添加分组</span>
                </li>
                <hr>
                <li>
                    <span @click.stop="nodeEditGroupName(node, data, store)" v-if="perimission.SEAL_GROUP_NAME_MODIFY">重命名</span>
                </li>
                <hr>
                <li>
                    <span @click.stop="nodeDeleteGroup(node, data, store)" v-if="perimission.SEAL_GROUP_DELETE">删除</span>
                </li>
                <hr>
                <li>
                    <span @click.stop="nodeTransferGroup(node, data, store)" v-if="perimission.SEAL_TRANSLATE">移动到</span>
                </li>
            </ul>
             <ul style="text-align:left" v-else>
                <li>
                    <span @click.stop="nodeAddChildGroup(node, data, store)" v-if="perimission.SEAL_GROUP_CREATE">添加分组</span>
                </li>
            </ul>
        </el-popover>
        <el-input v-focus autofocus size="small"
            v-show="data.isEdit"
            v-model="data.name"
            :ref="'treeInput' + data.name"
            @keyup.enter.native="$event.target.blur"
            @blur.stop="nodeEditPassGroup(node, data, store)">
        </el-input>
        <span style="width:80%;display:inline-block;" v-show="!data.isEdit">{{data.name}}</span>
        <i class="icon el-icon-caret-bottom label-operation" v-popover:popover @click.stop="change" v-if="perimission.SEAL_GROUP_OPERATION"></i>
    </li>
</template>
<script>
export default {
    props: ["node", "data", "store"],
    directives: {
        focus: {
            // 当绑定元素插入到 DOM 中。
            inserted: function (el) {
                // 聚焦元素
                el.focus()
            }
        }
    },
    data(){
        return {
            popoverVisible: false,
        }
    },
    computed: {
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        userWsid(){ 
            return this.$store.getters.userWsid
        },
        enterpriseAuthorWsid(){ //企业拥有者id
            return (this.$store.getters.enterpriseAuthorWsid)
        },
        perimission(){
            return this.$store.getters
        },
        isParentNode(){
            if (this.data.level === 1){
                return true
            } else {
                return false
            }
        }
    },
    mounted(){
        let name = this.data.name
        if (this.data.isEdit) {
            this.$refs["treeInput" + name].focus()
        }
    },
    methods: {
        nodeAddChildGroup(node, data, store){
            this.popoverVisible = false
            this.$emit("nodeAddChildGroup", node, data, store)
        },
        //重命名
        nodeEditGroupName(node, data, store){
            data.isEdit = true
            this.$nextTick(() => {
                this.$refs["treeInput" + data.name].focus()
            })
            this.$emit("nodeEditGroupName", node, data, store)
            this.popoverVisible = false
        },
        //编辑/重命名名称完成(失去焦点)
        nodeEditPassGroup(node, data, store){
            this.popoverVisible = false
            if (data.name === ""){
                this.$message.warning("分组名称不能为空")
                return false
            }
            data.isEdit = false
            this.$emit("nodeEditPassGroup", node, data, store)
        },
        nodeDeleteGroup(node, data, store){
            this.popoverVisible = false
            this.$emit("nodeDeleteGroup", node, data, store)
        },
        nodeTransferGroup(node, data, store){
            this.popoverVisible = false
            this.$emit("nodeTransferGroup", node, data, store)
        },
        change(){
            document.body.click()
        },
    }

}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.wesign-popper-tree-list ul li{
    padding:0;
    cursor:pointer;
}
ul{
    margin:0;
    padding:0;
}
.label-container{
    height:36px;
    line-height:36px;
}
.seal-group-item{
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  display:inline-block;
  line-height:36px;
  width:85%;
  cursor:pointer;
  padding-right: 10px;
  box-sizing: border-box;
}
input {
    border:0;
}
.el-tree-node__content .active,
.el-tree-node__content:hover {
    background-color:@color-list-choose;
    .label-operation{
        display: inline-block;
    }
}
.label-operation{
    position: absolute;
    right: 0px;
    line-height: 36px;
    display: none;
    width: 30px;
    text-align: center;
}

.label-operation:active{
   color: @color-add
}
</style>
<style lang="less">

.seal-group-item .el-input{
    width:85%;
}
.seal-group-item .el-input__inner{
    padding:0;
    text-indent:5px;
}
.wesign-popper-tree-list{
    min-width:100px !important;
    margin:0 !important;
    outline:none;
}
.group-container .el-tree--highlight-current .el-tree-node.is-current > .el-tree-node__content .label-operation{
    display:inline-block !important;
}
</style>