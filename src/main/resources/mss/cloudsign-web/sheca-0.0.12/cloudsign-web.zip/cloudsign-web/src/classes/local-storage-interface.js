//数据存储到local中的接口
class localStorageInterface{
    constructor(key){
        this._key = key//local的key
    }

    loadFromLocal(){
        let storage = window.localStorage

        let data = storage.getItem(this._key) || ""
        try {
            data = JSON.parse(data)
            for (let key in data){
                if (this[key] !== undefined){
                    this[key] = data[key]
                }
            }
        } catch (e) {
            
        }
    }

    saveToLocal(){
        let storage = window.localStorage
        try {
            storage.setItem(this._key, JSON.stringify(this, (key, value) => {
                if (key === "_key") return void (0)
                return value
            }))
        } catch (e){
            
        }
    }
}


export { localStorageInterface }

class cookiesInterface{
    constructor(key){
        this._key = key//local的key
    }

    loadFromLocal(){
        let storage = window.sessionStorage
        let data = storage.getItem(this._key) || ""
        try {
            data = JSON.parse(data)
            for (let key in data){
                if (this[key] !== undefined){
                    this[key] = data[key]
                }
            }
        } catch (e) {
            
        }
    }

    saveToLocal(){
        let storage = window.sessionStorage
        try {
            storage.setItem(this._key, JSON.stringify(this, (key, value) => {
                if (key === "_key") return void (0)
                return value
            }))
        } catch (e){
            
        }
    }
}


export { cookiesInterface }