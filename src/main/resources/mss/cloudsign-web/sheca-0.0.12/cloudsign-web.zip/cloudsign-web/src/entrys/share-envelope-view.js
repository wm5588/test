import "./common.js"
import "@styles/common.less"
import Vue from "vue"
import Vuex from "vuex"
import shareEnvelopeView from "@page-components/externals/share-envelope-view.vue"
//element-ui 引入
import {
    Row,
    Col,
    Message,
    MessageBox,
    Input,
    InputNumber,
    Button,
    Checkbox,
    Select,
    Option,
    Loading
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(InputNumber)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Select)
Vue.use(Option)
Vue.use(Loading.directive)
Vue.prototype.$message = Message
Vue.prototype.$loading = Loading.service
Vue.prototype.$msgbox = MessageBox
Vue.prototype.$confirm = MessageBox.confirm

new Vue({
    el: "#app",
    template: "<shareEnvelopeView />",
    components: {
        shareEnvelopeView
    }
})
