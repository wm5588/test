let config = {
    url: {
        app: "http://192.168.51.110:12080", //主站地址
        developer: "http://192.168.51.110:61113", //开放平台地址
        ws: "ws://192.168.51.110:61117", //websocket地址
        link:"http://192.168.51.110:61112"
    }
}

export { config }