const exit = require("$exit")
let askend = require('$HMAC').askend

/**
 * ----------------------------------------------------
 * @path   /api/verifications
 * @method GET
 * @desc   认证申请表单列表查询: 查询指定条件下的用户实名认证申请表单列表
 * @author 陈曦源,周雪梅
 * @date   2018-01-26 19:45:21
 * ----------------------------------------------------
 */
exports.get = function (req, res, next) {
    let {
        filters,
        fileds,
        offset,
        limit,
        sorts = "-submit_datetime"//FIXME: 后端目前只支持下划线
    } = req.query

    askend({
        reqMethod: 'get',
        reqURL: 'wesign-mss-identity://verifications',
        reqQuery: {
            filters,
            fileds,
            offset,
            limit,
            sorts
        },
        reqSession: req.cookies.SessionWsid
    }).then(resp => {
        exit(res, {identities: 
            resp.data.identities
        })
    }).catch(err => {
        next(err)
    })
}

/**
 * ----------------------------------------------------
 * @desc  认证信息提交指引
 * @from  实名认证微服务-认证申请表单 | OPTIONS /verifications
 * @date  2017-08-02 20:40:59
 * ----------------------------------------------------
 */
exports.options = function (req, res, next) {
    askend({
        reqMethod: 'options',
        reqURL: '6433/verifications',
        reqSession: req.cookies.SessionWsid,
        reqSuccess: function (body) {
            res.json(body)
        },
        reqError: function (err) {
            error.senderror(res, "000x000", { err })
        }
    })
}