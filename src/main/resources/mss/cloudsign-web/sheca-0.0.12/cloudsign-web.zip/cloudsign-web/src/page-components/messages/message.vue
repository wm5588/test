<template>
	 <div class="main-container">
        <div class="messages-info-title">
            <p class="wesign-info-title">消息通知</p>
            <!--<div class="message-tab-box">
                <p class="info-title">消息通知</p>
                <div class="router-link-box">
                    <span>签署消息</span>
                </div>
            </div>-->
		</div>
		<div class="messages-container">
			<div class="messages-container-tab-box">
				<Tab class="messages-container-tab" :tabs="statusTabs" :activeTab="activeStatusIndex" @active-tab="chooseStatus" :messagesLength="messagesLength"></Tab>
				<div class="more" v-if="activeStatusIndex == 0">
                    <!--<el-popover
                        ref="popover"
                        placement="bottom"
                        width="80"
                        popper-class="wesign-messages-list-item-popper-class"
                        v-model="popoverVisible"
                        trigger="click">
                        <ul style="text-align:left">
                            <li @click="readAllMessage()">
                                <span>全部标为已读</span>
                            </li>
                            <li v-if="activeStatusIndex == 1">
                                <span>清空已读消息</span>
                            </li>
                        </ul>
                    </el-popover>
                    <span v-popover:popover @click="popover">更多</span>
                    -->
                    <el-button v-if="messages.length" size="small" :loading="readAllLoading" type="primary" plain @click="readAllMessage">全部标记为已读</el-button>
                </div>
			</div>
			<div class="message-list-container">
                <div class="message-list-body">
                    <div class="message-list-body-scroll" v-loading="messageLoading">
                        <template v-if="messages.length">
                            <div class="message-col" v-for="(item,index) in messages" :class="activeStatusIndex== 0 ? 'unread-message' : 'read-message'" @click="rmarkReadMessage(item.id, item.envelopeWsid, item.targertWsid)" :key="index">
                                <div class="message-list-title-box">
                                    <div class="message-list-title">{{item.messageTitle}}</div>
                                    <div class="public-item">{{translateTime(item.createdDatetime)}}</div>
                                </div>
                                <div class="message-list-content">{{item.messageContent}}</div>
                                <!--<div class="message-list-item">{{item.sender}}</div>
                                <div class="message-list-item">
                                    <el-button type="text" @click="readMessage(item.id)">查看详情</el-button>
                                    <el-button v-if="activeStatusIndex == 1" type="text" @click="">删除</el-button>
                                </div>-->
                            </div>
                        </template>
                        <div class="message-empty" v-else>暂无数据</div>
                    </div>
                </div>
            </div>
		</div>
        <div class="footer-box">
            <div class="footer">
                <div class="pagination-footer">
                    <el-pagination background :page-count="totalPages"
                        :current-page="currentPage" @current-change="selectPage" 
                        layout="prev, pager, next, jumper, ->, total">
                    </el-pagination>
                </div>
            </div>
        </div>
	</div>
</template>
<script>
import Tab from "@components/commons/tabs/message-tab.vue"
import { newFormatDate, formatDate } from "@commons/util.js"
import {getUserMessages, pullMessage, sendMessage, readMessage, pullAnnouncement, readAllMessage} from "@interfaces/message-pusher/system-message.js"
export default {
    data(){
        return {
            activeStatusIndex: -1,
            statuses: [
                {name: "未读消息", statusCodes: ["UNREAD"]},
                {name: "已读消息", statusCodes: ["READ"]},
            ],
            messages: [],
            date: new Date(),
            itemLimit: 10,
            currentPage: 1,
            totalPages:　1,
            popoverVisible: false,
            readAllLoading: false,
            messageLoading: false
        }
    },
    computed: {
        statusTabs(){
            return this.statuses.map(s => s.name)
        },
        userWsid(){
            return this.$store.getters.userWsid
        },
        messagesLength(){
            return this.$store.getters.totalElements
        },
        unreadMessage(){
            return this.messages.filter(item => item.read == false).map(value => {
                return {
                    userNotifyId: value.id,
                    isread: true
                }
            })
        }
    },
    watch: {
        messagesLength(newVal, oldVal){
            if (newVal != oldVal){
                let query = this.getURLQuery()
                this.getMessages(query)
            }
        }
    },
    created(){
        let query = this.getURLQuery()
        if (query.status){
            this.activeStatusIndex = parseInt(query.status)
        } else {
            this.activeStatusIndex = 0
        }
        this.getMessages(query)
    },
    methods: {
        popover(){
            this.popoverVisible = !this.popoverVisible
            document.body.click()
        },
        chooseStatus(index){
            this.activeStatusIndex = index
            this.updateQuery({
                status: index,
                page: 1
            })
        },
        selectPage(page){
            let oldQuery = this.getURLQuery()
            let query = {}
            Object.assign(query, oldQuery, {
                page: page
            })
            this.updateQuery(query)
        },
        updateQuery(query){
            if (query.status){
                this.activeStatusIndex = query.status
            } else {
                this.activeStatusIndex = 0
            }

            this.getMessages(query)

            this.$router.replace({
                path: "/person/message",
                query: query
            })
        },
        getURLQuery(){
            let query = this.$route.query
            if (query.status) query.status = parseInt(query.status) || 0
            return query
        },
        readAllMessage(){
            if (this.activeStatusIndex == 0){
                this.readAllLoading = true
                readAllMessage({
                    userWsid: this.userWsid
                }).then(res => {
                    this.readAllLoading = false
                    this.getMessages()
                }).catch(err => {
                    this.readAllLoading = false
                    this.$message.error("读取消息失败")
                })
            }
        },
        rmarkReadMessage(id, envelopeWsid, targertWsid){
            if (envelopeWsid){
                if (targertWsid){
                    this.$store.dispatch("updateUserAccounts").then(_ =>{
                        let userAccounts = this.$store.getters.userAccounts
                        let userAccount = userAccounts.find(acount => acount.userWsid === targertWsid)
                        if (!userAccount || userAccount.memberStatus === "DISABLED"){
                            this.$alert("您已经被企业管理员从该企业移除，无法进入该企业内部", "提醒", {
                                type: "warning",
                                confirmButtonText: "确定",
                            }).then(_ => {
                                this.gotoEnvelopeDetail(id)
                            }, _ => {}).then(_ => {
                            })
                            return
                        }

                        this.$store.dispatch("changeUserAccount", targertWsid).then(_ => {
                        return this.gotoEnvelopeDetail(id, envelopeWsid)
                        }).catch(err => {
                            if (err.response){
                                let code = err.response.data.code
                                if (code === 101){
                                    this.$alert("您已被管理移除该企业，无权代表企业签署文件", "提醒", {
                                        type: "warning",
                                        confirmButtonText: "确定",
                                    }).then(_ => {
                                        // location.href = "/wesign"
                                    })
                                } 
                            }
                        })
                    })
                } else {
                    return this.gotoEnvelopeDetail(id, envelopeWsid)
                }
            } else {
                this.gotoEnvelopeDetail(id)
            }
        },
        gotoEnvelopeDetail(id, envelopeWsid){
            if(envelopeWsid){
                this.$router.push({
                    name: "envelope-detail",
                    params: {
                        envelopeId: envelopeWsid
                    }
                })
            }
            
            let notifications = []
            notifications.push({
                userNotifyId: id,
                isread: true
            })

            if (this.activeStatusIndex == 0){
                readMessage({
                    userWsid: this.userWsid,
                    notifications
                }).then(res => {
                    this.getMessages(this.getURLQuery())
                }).catch(err => {
                    this.$message.error("读取消息失败")
                })
            }
        },
        getMessages(query = this.getURLQuery()){
            let {
                page = 1,
                status = 0
            } = query 

            let filters = []
            if (query.status == 1){
                filters.push(`isread=true`)
            } else {
                filters.push(`isread=false`)
            }
            filters = filters.join(",") || undefined
            this.messageLoading = true
            this.$store.dispatch("updateUserMessage", {
                userWsid: this.activeUserWsid,
                filters,
                offset: (page - 1) * this.itemLimit,
                limit: this.itemLimit,
                sorts: "-createdDatetime"
            }).then(res => {
                this.messageLoading = false
                let messages = res.data.data.wsMessageList
                this.messages = messages.map(message => {
                    let messageInfo = JSON.parse(message.attachMessage)
                    return {
                        messageTitle: message.messageTitle,
                        id: message.messageId,
                        createdDatetime: message.createdDatetime,
                        messageContent: message.messageContent,
                        read: message.read,
                        sender: message.sender,
                        envelopeWsid: messageInfo.envelopeWsid, 
                        envelopeTitle: messageInfo.envelopeTitle,
                        targertWsid: messageInfo.targertWsid
                    }
                })
                let pages = res.data.data.page
                this.totalPages = pages.totalPages
                this.currentPage = parseInt(page)
            }).catch(err => {
                this.messageLoading = false
                console.error(err)
            }) 
        },
        translateTime(time){
            return newFormatDate(time, "HH:mm")
        },
    },
    components: {
        Tab
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.message-tab-box{
    margin: 15px 0;
    height: 55px;
    box-shadow: rgba(0, 0, 0, 0.06) 0 0 0.2rem 0.01rem;
    border-radius:8px;
    background: #fafafa;
    padding:0 25px;
    line-height: 55px;
    display: flex;
    position:relative;
    .info-title{
        font-size:@font-size-primary;
        position:absolute;
        top:0;
        font-weight:bold;
    }
    .router-link-box{
        margin:0 auto;
        text-align:center;
        font-size: @font-size-primary;
    }
}

.read-message{
    color:@color-font-regular
}
 .messages-container{
    .info-block-default;
    position: absolute;
    left: 40px;
    right: 40px;
    top: 75px;
    bottom: 50px;
	padding:0;
}
.message-list-content{
    padding-top:10px;
}
.messages-container-tab-box{
	border: 1px solid @color-line;
	position:relative;
}
.message-col{
	// height: 25px;
	// line-height: 25px;
	// display: flex;
	align-items:center;
	padding:15px 20px;
	border-bottom: 1px solid @color-line;
    cursor:pointer;
    .message-list-title-box{
        display:flex;
        justify-content:space-between;
    }
	&:hover{
		background: @color-background;
	}

	&:last-child{
		border-bottom: none;
	}
	// .message-list-item{
	// 	flex: 1;
	// 	white-space: nowrap;
	// 	overflow: hidden;
	// 	text-overflow: ellipsis;
	// }
}
.message-list-body{
	position:absolute;
	top: 50px;
    bottom:0;
	width: 100%;
}
.more{
	position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
}

.message-list-body-scroll{
	position: absolute;
	top:0;
	height: 100%;
	width: 100%;
	overflow: auto;
}
.message-empty{
	display: flex;
	align-items: center;
	justify-content: center;
	height: 100%;
}
.footer-box{
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    text-align:center;
}

</style>
<style lang="less">
.messages-container-tab{
	font-size:14px !important;
}

.wesign-messages-list-item-popper-class{
    padding: 0;
    min-width: 110px;
    width: 120px;
    line-height: 25px; 
    outline:none;
    ul{
        padding: 0 10px;
    }
    ul li{
    padding:0;
    cursor:pointer;
    }     
}
</style>