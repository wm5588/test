import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @desc  获取微信的session_key
 * @from  用户中心微服务API-Session | GET /users/extra-account/wechat-session
 * @date  2018-09-29 18:15:34
 * ----------------------------------------------------
 */
export function extra_account_sessions(obj) {
    let {
        code
    } = obj

    return axios.get("/api/wechat/wechat-session", {
        params: {
            code
        }
    })
}