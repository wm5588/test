<template>  
    <div>
        <div class="public-select-member-box" v-loading="bindingLoading">
            <div class="select-member-left">  
                <el-input ref="seachInput" v-model.trim="seachRoleMember" size="small" prefix-icon="el-icon-search" placeholder="请输入用户姓名、工号、联系方式进行搜索">
                    <el-button v-if="seachRoleMember!=''" slot="append" @click="clearSearch">清空</el-button>
                </el-input> 
                <!--<p v-if="seachRoleMember!=''" :class="checkAlled ? 'all-checked checked' : 'all-unchecked checked'"><i class="el-icon-circle-plus-outline" @click="setCheckedAllNodes"></i>全选</p>
                <p v-else>&nbsp; </p>:default-expanded-keys="[this.enterpriseGroupWsid]"-->
                <el-tree                 
                    :data="enterpriseRolesMemberGroups"
                    ref="unbindMeberTree"
                    node-key="wsid"
                    :highlight-current="true"
                    :default-expanded-keys="[this.enterpriseGroupWsid]"
                    :check-on-click-node="true"
                    :default-expand-all= "false"
                    :expand-on-click-node="true"
                    :accordion ="true"
                    :check-strictly ="true"
                    :render-content="renderUnboundMember"
                    @check-change ="handleNodeUnboundMember"
                    @node-click="changeUnboundMember"
                    :filter-node-method="filterUnboundMemberNode"
                    @check="checkGroupNode"
                    >
                </el-tree>
            </div>
            <div class="select-member-right">
                <p>已选择的成员 ({{selectRoleMembers.length}})</p>
                <el-tree                 
                    :data="selectRoleMembers"
                    ref="tree"
                    accordion
                    node-key="wsid"
                    :check-on-click-node="true"
                    :default-expand-all= "true"
                    :expand-on-click-node="false"
                    :check-strictly ="true"
                    :render-content="renderContentSelectMember"
                    @check-change ="handleSelectMember"
                    >
                </el-tree>
            </div>
        </div>
        <div class="dialog-footer">
            <el-button @click="cancle">取 消</el-button>
            <el-button type="primary" @click="confirm">确 定</el-button>
        </div>
    </div>
</template>
<script>
import { getEnterpriseGroups } from "@interfaces/enterprise/enterprise.js"
import treeRender from "@components/labels/roles-item.vue"
export default {
    data(){
        return {
            bindingLoading: false,
            seachRoleMember: "",

            enterpriseRolesMemberGroups: [],
            selectRoleMembers: [],
            highlightItem: false,
            filterMembers: [],
            checked: false,
            checkAlled: false, 
            enterpriseGroupWsid: ""
        }
    },
    computed:{
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        enterpriseAuthorWsid(){
            return (this.$store.getters.enterpriseAuthorWsid)
        },
        enterpriseEuserAuthorWsid(){
            return this.$store.getters.enterpriseEuserAuthorWsid
        },
    },
    watch: {
        seachRoleMember(oldVal, newVal){
            if (oldVal === ""){
                this.getEnterpriseRolesGroupsList()
            } else if (oldVal !== newVal){
                this.getEnterpriseRolesGroupsList()
            } 
        },
    },
    created(){
        this.getEnterpriseRolesGroupsList()
    },
    methods:{
         clearSearch(){
            this.seachRoleMember = ""
        },
        filterUnboundMemberNode(value, data, node) {
            if (!value) return true
            if (data.name.indexOf(value) !== -1){
                let dataInfo = {
                    name: data.name,
                    wsid: data.wsid, 
                    type: data.type,
                    phone: data.phone,
                    email: data.email,
                    staffNo: data.staffNo,
                    authorWsid: data.authorWsid,
                    parentWsid: data.parentWsid,
                    level: data.level,
                    checked: node.checked,
                    children: []
                }
                this.filterMembers.push(dataInfo) 
                // let checked = this.filterMembers.every(item => item.checked === true)
                return data.name.indexOf(value) !== -1
            }
        },
        handleNodeUnboundMember(data, node, store){
            data.checked = node
            if (data.type === "MEMBER"){
                if (data.checked){
                    if (this.selectRoleMembers.every(m => m.wsid !== data.wsid)){
                        this.selectRoleMembers = [data]
                    }

                } else {
                    this.selectRoleMembers = this.selectRoleMembers.filter(m => m.wsid !== data.wsid)
                }
            }
        },
        changeUnboundMember(data){
            this.$nextTick(_ => {
                this.$emit("update:highlightItem", true)
            }) 
        },
        handleSelectMember(data, node){
            this.$nextTick(_ => {
                let index = this.selectRoleMembers.findIndex(d => d.wsid === data.wsid)
                this.selectRoleMembers.splice(index, 1)
                this.$refs.unbindMeberTree.setChecked(data, false)
            })
        },
        checkGroupNode(a,b){
            if (b.checkedKeys.length > 0) {
                this.$refs.unbindMeberTree.setCheckedKeys([a.wsid])
            }
        },
        renderContentSelectMember(h, { node, data, store }){
            return (
                <span class="custom-tree-node">
                    <i class="icon-user user"></i>
                    <span>{data.name}</span>
                    {
                        data.type === "MEMBER" ? <i class="el-icon-close error"></i> : ""
                    } 
                </span>
            )
        },
        renderUnboundMember(h, { node, data, store }) {
            let that = this
            return h(treeRender, {
                props: {
                    node,
                    data,
                    store
                },
            })
        },
        confirm(){
            this.$emit("confirm", this.selectRoleMembers)
        },
        clear(){
            this.$nextTick(_ =>{
                this.$refs.unbindMeberTree.setCheckedKeys([])
            })
        },
        cancle(){
            this.$emit("cancle")
        },
        getEnterpriseRolesGroupsList(groupWsid){
            this.bindingLoading = true
            getEnterpriseGroups({
                enterpriseWsid: this.enterpriseWsid,
                groupWsid: groupWsid || "",
                // filterEnteRoleWsids: this.enterpriseRoleWsid,
                current: false,
                scopes: "nickname,realName,contact,staffNo",
                keyword: this.seachRoleMember,
                type: this.seachRoleMember ? "MEMBER" : "ALL"
            }).then(res => {
                let enterpriseRolesGroups = res.data.data.groups
                if (this.seachRoleMember === ""){
                    let enterpriseGroup = enterpriseRolesGroups.filter(role => role.group.type === "ENTERPRISE")
                    this.enterpriseGroupWsid = enterpriseGroup[0].group.groupWsid
                    let merberGroup = enterpriseRolesGroups.filter(role => role.group.type === "MEMBER").filter(member=> member.enterpriseMember.authorWsid!== this.enterpriseEuserAuthorWsid)
                    let departmentGroup = enterpriseRolesGroups.filter(role => role.group.type === "DEPARTMENT")
                    let newEnterpriseRolesGroups = enterpriseGroup.concat(departmentGroup.concat(merberGroup))
                    newEnterpriseRolesGroups = newEnterpriseRolesGroups.map(member => {
                        let phone, email, staffNo, authorWsid, name
                        if (member.enterprise){
                            name = member.enterprise.name
                        } 
                        
                        if (member.enterpriseDepartment){
                            name = member.enterpriseDepartment.name
                        } 

                        if (member.enterpriseMember){
                            phone = member.enterpriseMember.phone
                            email = member.enterpriseMember.email
                            staffNo = member.enterpriseMember.staffNo
                            authorWsid = member.enterpriseMember.authorWsid
                            name = member.enterpriseMember.realName || member.enterpriseMember.nickname
                        } else {
                            phone = ""
                            email = ""
                            staffNo = ""
                            authorWsid = ""
                        }

                        return {
                            name: name || member.group.name,
                            wsid: member.group.groupWsid, 
                            type: member.group.type,
                            phone: phone,
                            email: email,
                            staffNo: staffNo,
                            authorWsid: authorWsid,
                            parentWsid: member.group.parentGroupWsid,
                            level: member.group.level,
                            checked: false,
                            children: []
                        }
                    })
                    newEnterpriseRolesGroups.sort((a, b) => a.level - b.level)
                    let levels = []
                    newEnterpriseRolesGroups.forEach((item, index) => {
                        if (!levels[newEnterpriseRolesGroups[index].level]){
                            levels[newEnterpriseRolesGroups[index].level] = new Object()
                        }
                        levels[newEnterpriseRolesGroups[index].level][newEnterpriseRolesGroups[index].wsid] = newEnterpriseRolesGroups[index]
                    })
        
                    for (let i = levels.length - 1; i > 1; i--){  
                        for (let obj in levels[i]){  
                            if (levels[i - 1][levels[i][obj].parentWsid].children == undefined){  
                                levels[i - 1][levels[i][obj].parentWsid].children = new array() 
                            }  
                            levels[i - 1][levels[i][obj].parentWsid].children.push(levels[i][obj])
                        }  
                    }  

                    let departmentsLevels2 = []
                    for (let department in levels[1]) {
                        departmentsLevels2.push(levels[1][department])
                    }
                    this.bindingLoading = false
                    this.enterpriseRolesMemberGroups = departmentsLevels2
                    this.$nextTick(_ => {
                        let selectMeberTree = this.$refs.unbindMeberTree.setCheckedNodes(this.selectRoleMembers)
                    })
                } else {
                    this.bindingLoading = false
                    let enterpriseRolesMemberGroups = enterpriseRolesGroups.filter(member=> member.enterpriseMember.authorWsid!== this.enterpriseEuserAuthorWsid).map(member => {
                        let phone, email, staffNo, authorWsid, name
                        if (member.enterprise){
                            name = member.enterprise.name
                        } 
                        
                        if (member.enterpriseDepartment){
                            name = member.enterpriseDepartment.name
                        } 

                        if (member.enterpriseMember){
                            phone = member.enterpriseMember.phone
                            email = member.enterpriseMember.email
                            staffNo = member.enterpriseMember.staffNo
                            authorWsid = member.enterpriseMember.authorWsid
                            name = member.enterpriseMember.realName || member.enterpriseMember.nickname
                        } else {
                            phone = ""
                            email = ""
                            staffNo = ""
                            authorWsid = ""
                        }

                        return {
                            name: name || member.group.name,
                            wsid: member.group.groupWsid, 
                            type: member.group.type,
                            phone: phone,
                            email: email,
                            staffNo: staffNo,
                            authorWsid: authorWsid,
                            parentWsid: member.group.parentGroupWsid,
                            level: member.group.level,
                            checked: false,
                            children: []
                        }
                    })
                    this.enterpriseRolesMemberGroups = enterpriseRolesMemberGroups
                    this.$nextTick(_ => {
                        let selectMeberTree = this.$refs.unbindMeberTree.setCheckedNodes(this.selectRoleMembers)
                    })
                }
            }).catch(err => {
                this.bindingLoading = false
                console.log(err)
            })
        },
    },
    components: {
        treeRender,
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.public-select-member-box{
    display:flex;
    p{
        line-height:30px;
        height:30px;
    }
    .select-member-left{
        flex:1;
        margin-right:20px;
        .el-tree{
            height:460px;
            overflow-y:auto;
            margin-top:15px;
        }
    }
    .select-member-right{
        flex:1;
        .el-tree{
            height:460px;
            overflow-y:auto;
            margin-top:15px;
        }
    }
}
.dialog-footer{
    padding-top:15px;
    text-align:right;
}
</style>