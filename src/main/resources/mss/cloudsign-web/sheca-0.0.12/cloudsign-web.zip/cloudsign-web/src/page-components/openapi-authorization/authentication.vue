<!--
    @id        page-person-auth
    @desc      个人实名认证主页
    @level     page：页面组件
    @author    周雪梅
    @date      2019-02-27 14:20:51
-->
<template>
    <div class="wrap">
        <div class="main-container">
            <h2 class="authentication-title">签约方验证</h2>
            <div class="authentication-container">
                <div class="authentication-center-box">
                    <p class="authentication-resulut-title">身份验证未通过</p>
                    <p><i class="icon-notice wait icon"></i></p>
                    <p class="await-title">帐号{{this.$store.state.phone}}已完成个人实名认证，本次提交信息与该帐号已绑定信息不一致</p>
                </div>
                <div class="authentication-error-box">
                    <p class="bold">本次提交个人信息如下</p>
                    <div class="contact-info-box">
                        <p>帐号：{{this.$store.state.phone}}</p>
                        <p>姓名：{{this.$store.state.name}}</p>
                        <p>身份证号：{{this.$store.state.idCardNo}}</p>
                    </div>
                    <p class="bold">身份验证未通过怎么办？</p>
                    <div class="authentication-error-list-box">
                        <p class="item">请联系邀请方纠正您的姓名和身份证信息，并重新发送邀请</p> 
                    </div>
                </div>
                <el-button type="primary" class="authentication-result-btn" @click="goBack">返回</el-button>
            </div>
        </div>
    </div>
</template>

<script>
import querystring from "querystring"
export default {
    data(){
        return {
            returnUrl: ""
        }
    },
    created(){
        let query = location.search.slice(1)
        query = querystring.parse(query)
            
        this.returnUrl =  decodeURIComponent(query.returnUrl) || "DEFAULT"
    },
    methods:{
        goBack(){
            if(this.returnUrl && this.returnUrl!=="DEFAULT"){
                location.href = `${this.returnUrl}`
            } else {
                window.location.href="about:blank";
                window.close()
            }
        }
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
@media screen and (max-width: 780px){
    .main-container{
        top:0px !important;
    }
}
.main-container{
    max-width:600px;
    position:relative;
    top:70px;
    margin:0 auto;
    overflow-x:hidden;
    .authentication-title{
        text-align:center;
        // padding: 20px 0;
    }

    .authentication-container{
        .info-block-default;
        max-width:600px;
        min-height: 400px;
        margin:0 auto;
        padding:15px;
        text-align:center;
    }
}
.icon{
    font-size:@font-size-largger
}
.await{
    color:@color-info;
}
.wait{
    color:@color-warning
}
.await-title{
    font-size:@font-size-regular !important;
    line-height:25px;
}
.authentication-result-btn{
    width:100%;
    max-width:300px;
    margin:40px 0;
    cursor:pointer;
}

.authentication-resulut-title{
    font-size:@font-size-primary !important;
}
.hint{
    color:@color-font-regular;
    font-size:@font-size-info;
    span{
        padding-top:8px;
        display:inline-block;
    }
}
.authentication-center-box{
    text-align:center;
    padding-bottom:15px;
    p{
        padding-top:15px;
    }
    border-bottom:1px solid #ccc
}
.authentication-error-box{
    width:90%;
    max-width:450px;
    min-width:300px;
    margin:0 auto;
    text-align: left;
}
.contact-info-box{
    font-size:12px;
    p{
        line-height:20px;
    }
}
.bold{
    font-weight:bold;
    padding:15px 0
}
.authentication-error-list-box{
    font-size:@font-size-info
}
</style>
