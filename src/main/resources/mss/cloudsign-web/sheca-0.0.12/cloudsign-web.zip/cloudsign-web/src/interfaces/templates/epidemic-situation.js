import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/templates/epidemic-situation-templates
 * @method GET
 * @desc   查询疫情临时合同场景模版
 * @author 陈曦源
 * @date   2020-02-19 19:46:53
 * ----------------------------------------------------
 */
export function getEpidemicSituationTemplates(obj) {
    let {
        enterpriseWsid
    } = obj
    
    return axios.get(`/api/templates/epidemic-situation-templates`, {
        params: {
            enterpriseWsid
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/templates/epidemic-situation-templates/generate
 * @method POST
 * @desc   生成疫情临时合同场景模版
 * @author 陈曦源
 * @date   2020-02-11 22:10:53
 * ----------------------------------------------------
 */
export function generateEpidemicSituationTemplates(obj) {
    let {
        authorWsid,
    } = obj

    return axios.post(`/api/templates/epidemic-situation-templates/generate`, {
        authorWsid
    })
}