import axios from '@interfaces/axios.js'

/**
 * ----------------------------------------------------
 * @desc  认证图片上传json: 用json格式给指定的认证资料上传的认证图片
 * @from  实名认证微服务-认证申请表单 | POST /verifications/{idttv-wsid}/image/json-upload
 * @date  2017-08-02 11:19:25
 * ----------------------------------------------------
 */
export function authImgJson_post(obj) {
    let {
        idttvWsid,
        fileName,
        hash,
        fileData,
        imageCode
    } = obj

    return axios.post('/api/verifications/' + idttvWsid + '/image/json-upload', {
        fileName,
        hash,
        fileData,
        imageCode
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/verifications/${identityWsid}/image/form-upload
 * @method POST
 * @desc   认证图片上传form: 用form格式给指定的认证资料上传的认证图片
 * @author 陈曦源
 * @date   2018-01-29 19:03:44
 * ----------------------------------------------------
 */
export function authImgForm(obj) {
    let {
        identityWsid,
        fileName,
        imageCode,
        file,
        hash,
        onUploadProgress
    } = obj

    let formdata = new FormData()
    
    formdata.append("fileName", fileName)
    formdata.append("imageCode", imageCode)
    formdata.append("file", file)
    if (hash) formdata.append("hash", hash)

    return axios.post(`/api/verifications/${identityWsid}/image/form-upload`, formdata, {
        onUploadProgress
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/verifications/identity-card
 * @method POST
 * @desc   身份证图像识别
 * @author 周雪梅
 * @date   2018-03-13 11:50:37
 * ----------------------------------------------------
 */
export function cardImgForm(obj) {
    let {
        file
    } = obj

    let formdata = new FormData()
    
    formdata.append("file", file)

    return axios.post(`/api/verifications/identity-card`, formdata)
}

/**
 * ----------------------------------------------------
 * @path   /api/verifications/business-license-ocr
 * @method POST
 * @desc   营业执照识别
 * @author 周雪梅
 * @date   2018-08-29 20:55:39
 * ----------------------------------------------------
 */
export function businessLicenseImgForm(obj) {
    let {
        file
    } = obj

    let formdata = new FormData()
    
    formdata.append("file", file)

    return axios.post(`/api/verifications/business-license-ocr`, formdata)
}
