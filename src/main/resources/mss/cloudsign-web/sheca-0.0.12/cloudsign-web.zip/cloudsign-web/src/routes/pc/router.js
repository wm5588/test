import { MessageBox } from "element-ui"

import indexRoute from "./routes/index.js"

let pcRoutes = {
    mode: "history",
    base: "/wesign",
    routes: [
        indexRoute,
        {
            path: "/person/auth",
            name: "person-auth",
            meta: {
                title: "个人实名认证",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/person/auth.vue"))
                }, "page-person-auth")
            }
        },
        {
            path: "/enterprise/auth",
            name: "enterprise-auth",
            meta: {
                title: "企业实名认证",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/enterprise/enterprise-auth.vue"))
                }, "page-enterprise-auth")
            } 
        },
        {
            path: "/person/purchase",
            name: "person-purchase",
            meta: {
                title: "个人购买",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/person/purchase.vue"))
                }, "page-purchase")
            } 
        },
        {
            path: "/enterprise/purchase",
            name: "enterprise-purchase",
            meta: {
                title: "企业购买",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/enterprise/purchase/buy.vue"))
                }, "page-purchase")
            } 
        },
        {
            path: "/envelopes/:envelopeId",
            meta: {
                beforeEach(to, from, next, {store}){
                    if (store.getters.totalCharges === 0){
                        MessageBox.confirm("您的文档份数不足，无法编辑文档，请充值文档份数后重试", "提示", {
                            confirmButtonText: "立即前往充值",
                            cancelButtonText: "取消",
                            callback: action => {
                                if (action === "confirm"){
                                    if (store.getters.userEdition === "p"){
                                        next({
                                            name: "person-purchase"
                                        })
                                    } else {
                                        next({
                                            name: "enterprise-purchase"
                                        })
                                    }
                                } else {
                                    next(from.fullPath)
                                }
                            },
                            type: "warning"
                        })
                    } else {
                        next()
                    }
                },
                auths: {
                    AUTH_CONTROL_ENVELOPE: true
                },
                "auth-redirect": "/envelopes"
            },
            component: {
                template: "<router-view></router-view>"
            },
            children: [
                {
                    path: "editor",
                    name: "envelope-editor",
                    meta: {
                        title: "文件编辑页面",
                    },
                    component: resolve => {
                        require.ensure([], () => {
                            resolve(require("@page-components/wesign/envelope/envelope-editor.vue"))
                        }, "page-envelope")
                    }
                },
                {
                    path: "/template/:envelopeId/forms-editor",
                    name: "template-forms-editor",
                    meta: {
                        title: "模板使用表单编辑页面",
                    },
                    component: resolve => {
                        require.ensure([], () => {
                            resolve(require("@page-components/wesign/templates/template-forms-editor.vue"))
                        }, "page-template")
                    }
                },
                {
                    path: "bulk-editor",
                    name: "envelope-bulk-editor",
                    meta: {
                        title: "文件编辑页面",
                    },
                    component: resolve => {
                        require.ensure([], () => {
                            resolve(require("@page-components/wesign/envelope/envelope-bulk-sending/envelope-bulk-editor.vue"))
                        }, "page-envelope")
                    }
                },
                {
                    path: "forms-editor",
                    name: "envelope-forms-editor",
                    meta: {
                        title: "文件签名项编辑页面",
                    },
                    component: resolve => {
                        require.ensure([], () => {
                            resolve(require("@page-components/wesign/envelope/envelope-forms-editor.vue"))
                        }, "page-envelope")
                    }
                },
                //批量发送表单编辑页面
                {
                    path: "forms-bulk-editor",
                    name: "envelope-forms-bulk-editor",
                    meta: {
                        title: "文件签名项编辑页面",
                    },
                    component: resolve => {
                        require.ensure([], () => {
                            resolve(require("@page-components/wesign/envelope/envelope-bulk-sending/envelope-forms-bulk-editor.vue"))
                        }, "page-envelope")
                    }
                },
            ]
        },
        {
            path: "/envelopes/:envelopeId/signature",
            name: "envelope-signature",
            meta: {
                title: "文件签名页面",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/envelope/envelope-signature.vue"))
                }, "page-envelope")
            }
        },
        {
            path: "/envelopes/:envelopeId/audit",
            name: "envelope-audit",
            meta: {
                title: "文件审核页面",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/envelope/envelope-audit.vue"))
                }, "page-envelope")
            }
        },
        {
            path: "/envelopes/:envelopeId/preview",
            name: "envelope-preview",
            meta: {
                title: "文件预览页面"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/envelope/envelope-preview.vue"))
                }, "page-envelope")
            }
        },
        //创建模板
        {
            path: "/templates/:templateId/editor",
            name: "template-editor",
            meta: {
                title: "业务模板"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/templates/templates-create.vue"))
                }, "page-template")
            }, 
        },
        //模板使用
        {
            path: "/template/:envelopeId/use",
            name: "template-use",
            meta: {
                title: "使用模板页面"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/templates/template-use.vue"))
                }, "page-template")
            },
            // children: [
            //     {
            //         path: "forms-editor",
            //         name: "template-forms-editor",
            //         meta: {
            //             title: "模板使用表单编辑页面",
            //         },
            //         component: resolve => {
            //             require.ensure([], () => {
            //                 resolve(require("@page-components/wesign/templates/template-forms-editor.vue"))
            //             }, "async-template")
            //         }
            //     },
            // ]
        },
        {
            path: "/change",
            meta: {
                title: "切换组织",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/externals/change.vue"))
                }, "page-change")
            }
        },
        {
            path: "/403",
            meta: {
                title: "莫得权限",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/warn/error-403.vue"))
                }, "asyn-warn")
            }
        },
        {
            path: "/404",
            meta: {
                title: "未找到目标页面",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/warn/error-404.vue"))
                }, "asyn-warn")
            }
        },
        {
            path: "/envelop-openapi-complete",
            meta: {
                title: "操作完成",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/wesign/envelope/envelop-openapi-complete.vue"))
                }, "page-envelope")
            }
        }
    ]
}

export default pcRoutes