export function _assignObjectWithSrcProperties(target, source, level = Infinity){
    for (let key in target){
        if (source[key]){
            if (typeof target[key] === "object" && !Array.isArray(target[key]) && level !== 1){
                _assignObjectWithSrcProperties(target[key], source[key], level - 1)
            } else {
                target[key] = source[key]
            }
        }
    }
}

//判断矩阵是否相交
export function ifRectIntersect(rect1, rect2){
    if (rect1.top > rect2.top){
        let x = rect1
        rect1 = rect2
        rect2 = x
    }

    if (rect1.bottom < rect2.top) return false

    if (rect2.left < rect1.right && rect2.right > rect1.left) return true
    return false
}

//滚动扩展函数
export function scrollExtend(options){
    let handler = null
    let {
        scrollStart,
        scrollIng,
        scrollEnd,
        delay = 200
    } = options

    return function(){
        let _arguments = arguments
        if (!handler && scrollStart) scrollStart.apply(this, _arguments)
        if (handler) clearTimeout(handler)
        if (scrollIng) scrollIng.apply(this, _arguments)
        if (scrollEnd){
            handler = setTimeout(() => {
                handler = null
                scrollEnd.apply(this, _arguments)
            }, delay)
        }
    }
}

//格式化日期
export function formatDate(dateStr, format) {
    let date
    if (typeof dateStr === "string") {
        date = new Date(Date.parse(dateStr))
    }
    else if (typeof dateStr === "number") {
        date = new Date(dateStr)
    }
    else {
        date = dateStr
    }
    if (!(date instanceof Date))
        return "格式化串错误"

    let nowDate = new Date()
    let RegObj = {
        "Y+": date.getFullYear(),
        "M+": date.getMonth() + 1,
        "d+": date.getDate(),
        "D+": date.getDate(),
        "h+": date.getHours() % 12 == 0 ? 12 : date.getHours(),
        "H+": date.getHours(),
        "m+": date.getMinutes(),
        "s+": date.getSeconds()
    }
    let dateObj = {
        "Y": date.getFullYear(),
        "M": date.getMonth() + 1,
        "d": date.getDate(),
        "D": date.getDate(),
        "h": date.getHours() % 12 == 0 ? 12 : date.getHours(),
        "H": date.getHours(),
        "m": date.getMinutes(),
        "s": date.getSeconds()
    }

    let nowDateObj = {
        "Y": nowDate.getFullYear(),
        "M": nowDate.getMonth() + 1,
        "d": nowDate.getDate(),
    }

    
    let ONEDAY = 24 * 3600 * 1000
    let lastDate = nowDate.getTime() - nowDate.getTime() % ONEDAY - ONEDAY - 8 * 3600 * 1000 //FIXME: 暂时只支持中国的时区 东八区
    
    if (dateObj["Y"] === nowDateObj["Y"] && dateObj["M"] === nowDateObj["M"] && dateObj["d"] === nowDateObj["d"]){
        RegObj["XXXX"] = `今天`
    } else if (dateStr - lastDate > 0 && dateStr - lastDate < ONEDAY){
        RegObj["XXXX"] = `昨天`
    } else if (RegObj["Y"] === nowDateObj["Y"]){ //同一年
        RegObj["XXXX"] = `${dateObj["M"]}/${dateObj["d"]}`
    } else { //不同年
        RegObj["XXXX"] = `${dateObj["Y"]}/${dateObj["M"]}/${dateObj["d"]}`
    }

    if (new RegExp("(XXXX)").test(format)) {
        format = format.replace(RegExp.$1, RegObj["XXXX"])
    }

    for (let reg in RegObj) {
        if (RegObj.hasOwnProperty(reg)) {
            if (new RegExp("(" + reg + ")").test(format)) {
                format = format.replace(RegExp.$1, ("0000" + RegObj[reg]).substr(-RegExp.$1.length))
            }
        }
    }
    return format
}

//格式化日期
export function newFormatDate(dateStr, format) {
    return formatDate(dateStr, `XXXX${format ? " " + format : ""}`)
}

//选取文件函数
const selectFile = (function(){
    let input = document.createElement("input")
    input.type = "file"
    input.style.opacity = "0"

    return function(accept = "", size){
        //后缀格式为 .xxx类型
        //MIME为  xxxx/yy 或者 xxxx/*
        //逗号分隔
        let accepts = accept.split(",").map(type => type.trim()).filter(type => type)
        input.accept = accepts.join(",")

        let acceptTests = accepts.map(type => {
            if (/^\./.test(type)){ //为后缀
                return {
                    target: "name", //检查名称
                    regExp: new RegExp(`${type.replace(".", "\\.")}$`, "i")
                }
            } else { //为MIME类型
                if (/\/\*$/.test(type)){ //泛匹配
                    return {
                        target: "type", //检查名称
                        regExp: new RegExp(`^${type.replace("*", "\\S+")}$`, "i")
                    }
                } else {
                    return {
                        target: "type", //检查名称
                        regExp: new RegExp(`^${type}$`, "i")
                    }
                }
            }
        })

        return new Promise((resolve, reject) => {
            input.onchange = e => {
                let file = input.files[0]
                if (!file) return

                if (size && file.size > size){
                    reject(new TypeError("ERROR_FILE_SIZE"))
                    return
                }

                let result = true
                if (acceptTests.length > 0) {
                    result = acceptTests.some(test => {
                        return test.regExp.test(file[test.target])
                    })
                }

                if (result){
                    resolve(file)
                } else {
                    reject(new TypeError("ERROR_FILE_TYPE"))
                }

                input.value = ""
            }
            
            //兼容IE Input不在DOM树上无法触发选择的问题
            document.body.appendChild(input)
            input.click()
            document.body.removeChild(input)
        })
    }
})()
export { selectFile }

//转换image base64为file
export function ImageDataToFile(imgData){
    let img = imgData
    //转换为文件对象
    let arr = img.split(",")
    let mime = arr[0].match(/:(.*?);/)[1]
    let bstr = atob(arr[1])
    let n = bstr.length
    let u8arr = new Uint8Array(n)
    while (n--){
        u8arr[n] = bstr.charCodeAt(n)
    }
    //兼容IOS 将FILE换成BLOB
    let file = new Blob([u8arr], {
        type: mime
    })

    return file
}

export function ImageDataCompress(image){
    let canvas = document.createElement("canvas")
    let ctx = canvas.getContext("2d")
    let maxHeight = 512
    let maxWidth = 512
    if (image.height > maxHeight){
        image.width = image.width * maxHeight / image.height
        image.height = maxHeight
    }

    if (image.width > maxWidth){
        image.height = image.height * maxWidth / image.width
        image.width = maxWidth
    }

    canvas.width = image.width
    canvas.height = image.height

    ctx.save()
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.drawImage(image, 0, 0, image.width, image.height)
    let file = canvas.toDataURL()
    return file
}

export function ImageUrlToBase64(path, callback){
    let img = new Image()
    img.src = path
    console.log(path)
 
    //图片加载完成后触发
    img.onload = function(){
        let canvas = document.createElement("canvas")
        //获取绘画上下文
        let ctx = canvas.getContext("2d")
 
        // 获取图片宽高
        let imgWidth = img.width
        let imgHeight = img.height
        console.log(imgWidth, imgHeight)
        //设置画布宽高与图片宽高相同
        canvas.width = imgWidth
        canvas.height = imgHeight
 
        //绘制图片
        ctx.drawImage(img, 0, 0, imgWidth, imgHeight)
        //图片展示的 data URI
        let dataUrl = canvas.toDataURL("image/png")
        callback ? callback(dataUrl) : ""
    }
}

let getCharSizeByCanvas = (function(){
    let canvas = document.createElement("canvas")
    canvas.style.positon = "ablsolute"
    let ctx = canvas.getContext("2d")

    return function(str, style = {}){
        let {
            fontSize = 14,
            fontFamily = "Arial"
        } = style
        document.body.appendChild(canvas)
        ctx.font = `${fontSize}px ${fontFamily}`
        document.body.removeChild(canvas)
        let text = ctx.measureText(str) // TextMetrics object
        let result = {
            height: fontSize,
            width: text.width
        }
        return result
    }
})()

//base64转图片
export function base64ToLoadedImage(base64){
    return new Promise(function(resolve, reject){
        let img = document.createElement("img")
        img.src = base64
        img.onload = function(){
            resolve(img)
        }
        img.onerror = reject
    })
}

//获取imageData的非空白区域的最大矩阵
export function getImageDataImageRect(imageData){
    let width = imageData.width
    let height = imageData.height

    //查找矩阵
    let top = 0
    findtop: for (;top < height;top++){
        for (let i = 0; i < width; i++){
            if (imageData.data[(top * width + i) * 4 + 3] === 255){
                top--
                break findtop
            }
        }
    }

    let bottom = height - 1
    findbottom: for (;bottom >= 0;bottom--){
        for (let i = 0; i < width; i++){
            if (imageData.data[(bottom * width + i) * 4 + 3] === 255){
                bottom++
                break findbottom
            }
        }
    }

    let left = 0
    findleft: for (;left < width;left++){
        for (let i = top; i < bottom; i++){
            if (imageData.data[(i * width + left) * 4 + 3] === 255){
                left--
                break findleft
            }
        }
    }

    let right = width - 1
    findright: for (;right >= 0;right--){
        for (let i = top; i < bottom; i++){
            if (imageData.data[(i * width + right) * 4 + 3] === 255){
                right++
                break findright
            }
        }
    }

    return {
        top,
        bottom,
        left,
        right
    }
}

//图片数据转base64
export function imageDataTobase64(imageData){
    let width = imageData.width
    let height = imageData.height

    let canvas = document.createElement("canvas")
    canvas.width = width
    canvas.height = height
    let ctx = canvas.getContext("2d")
    ctx.putImageData(imageData, 0, 0)
    return canvas.toDataURL()
}

export {
    getCharSizeByCanvas
}