class documents {
    constructor() {
        this.id = parseInt(Math.random() * 100000000) //文档组对象id
        this.moreDocuments = true // 文档组还能添加更多文档
        this.maxDocumetnsCount = 5 // 最大文档数
        this.documentConfigs = new Array() //文档配置数组 由下文的documentConfigObject组成
        this.documentForms = new Array() //文档表单配置数组 有下文的documentFormObject 组成
    }
}
class documentConfigObject {
    constructor() {
        this.id = parseInt(Math.random() * 100000000) //预置文档位id
        this.name = "" //文档名称
        this.fileId = "" // 文档预置文件id
        this.sourceFileId = "" //文件上传后原始文件Id (主要是支持文件替换的时候下载原始文件)
        this.replaceLevel = 1 //文档是否可替换等级，0-不可替换 1-可替换 2-必须替换
        this.required = true //文档是否必须
        this.defaultShow = true //默认是否展示
    }
}

class documentFormObject {
    constructor() {
        this.id = parseInt(Math.random() * 100000000) //预置表单项id
        this.docId = "" //预置文档位id
        this.docPage = "" //文档页数
        this.participantProcessId = "" //预置流程参与者id
        this.type = "" //表单项类型 "TEXT"文本 "SIGN"手写签名 "SEAL"签章签名 "DATE"日期
        this.positions = { //位置  scale为1的情况下
            ulx: Number, //左上
            uly: Number,
            lrx: Number, //右下
            lry: Number
        }
    }
}

const FORMS_CONFIG = [{
    type: "SIGN",
    name: "签名框",
    icon: require("@images/envelopes/signname.png"),
    defaultSize: {
        height: 40 / 1.2,
        width: 100 / 1.2,
    }
},
{
    type: "SEAL",
    name: "签章框",
    icon: require("@images/envelopes/seal.png"),
    defaultSize: {
        height: 40 / 25.4 * 96,
        width: 40 / 25.4 * 96,
    }
},
{
    type: "TEXT",
    name: "文本框",
    icon: require("@images/envelopes/text.png"),
    defaultSize: {
        height: 15,
        width: 150 / 1.2,
    }
},
{
    type: "DATE",
    name: "日期框",
    icon: require("@images/envelopes/date.png"),
    defaultSize: {
        height: 15,
        width: 190 / 1.33,
    }
}
]

const FORMS_CONFIG_TYPE_MAP = new Map()
FORMS_CONFIG.forEach(form => FORMS_CONFIG_TYPE_MAP.set(form.type, form))

class EnvelopeFormPosition{
    constructor(){
        this.ulx = 0
        this.uly = 0
        this.lrx = 0
        this.lry = 0
    }

    static formRect(top, left, width, height){
        let position = new EnvelopeFormPosition()
        position.uly = top
        position.ulx = left
        position.lry = top + height
        position.lrx = left + width
        return position
    }
}
export {
    documents,
    documentConfigObject,
    documentFormObject,
    FORMS_CONFIG_TYPE_MAP,
    EnvelopeFormPosition
}