import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/count
 * @method GET
 * @desc   统计信封个数
 * @author 周雪梅
 * @date   2018-01-31 15:14:23
 * ----------------------------------------------------
 */
export function getEnvelopesCount(obj) {
    let {
        authorWsid,
        fields = null,
        filters = null
    } = obj

    return axios.get("/api/envelopes/count", {
        params: {
            authorWsid,
            fields,
            filters
        }
    })
}