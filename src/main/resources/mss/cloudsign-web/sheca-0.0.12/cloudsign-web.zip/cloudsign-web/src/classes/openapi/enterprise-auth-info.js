import { cookiesInterface } from "@classes/local-storage-interface.js"
const ENTERPRISEAUTHINFOLOCALSTATUS_LOCALSTORAGE_KEY = "wesign-enterprise-auth-info-status"

class EnterpriseAuthInfoLocalStatus extends cookiesInterface {
    constructor(){
        super(ENTERPRISEAUTHINFOLOCALSTATUS_LOCALSTORAGE_KEY)
        
        this.adminActiveType = ""
        this.isAuthAgreement = false
        this.isPrivacyAgreement = false
        this.loadFromLocal()
    }

    setAdminActiveType(nv){
        this.adminActiveType = nv
        this.saveToLocal()
    }

    setIsAuthAgreement(nv){
        this.isAuthAgreement = nv
        this.saveToLocal()
    }

    setIsPrivacyAgreement(nv){
        this.isPrivacyAgreement = nv
        this.saveToLocal()
    }
}

export { EnterpriseAuthInfoLocalStatus }

