//异步加载pdfjs
function getPDFJsLib(){
    return import(
        /* webpackChunkName: "pdfjs" */ 
        /* webpackPrefetch: true */
        /* webpackPreload: true */
        "script-loader!pdfjs-dist/build/pdf.min.js").then(function(){
        const pdfjsLib = window.pdfjsLib
        pdfjsLib.GlobalWorkerOptions.workerSrc = "/js/pdf.worker.min@2.2.228.js"
        return pdfjsLib
    })
}

//应用全局PDF存储
let PDF_MAP = new Map()

const getPDFDocument = async function(src, reload){
    if (PDF_MAP.get(src) && !reload) return PDF_MAP.get(src)
    let startTime = Date.now()
    let pdfjsLib = await getPDFJsLib()
    let pdfHandle = pdfjsLib.getDocument({
        url: src,
        cMapUrl: "/outputs/cmaps/",
        cMapPacked: true,
        rangeChunkSize: 256 * 1024, //256kb
        disableStream: true,
        disableAutoFetch: true
    }).then(pdf => {
        console.log(`加载文档完成：${Date.now() - startTime}`)
        return pdf
    })
    
    PDF_MAP.set(src, pdfHandle)
    return pdfHandle
}

export {
    getPDFDocument
}