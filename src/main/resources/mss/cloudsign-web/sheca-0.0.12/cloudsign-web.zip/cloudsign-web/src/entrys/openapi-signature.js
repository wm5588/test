import "./common.js"
import "@styles/common.less"
import "@commons/wesign-signature-sdk-child.js"
import Vue from "vue"

import VueRouter from "vue-router"
Vue.use(VueRouter)

import Vuex from "vuex"
Vue.use(Vuex)

//element-ui 引入
import {
    Row,
    Col,
    Message,
    MessageBox,
    Input,
    Button,
    Checkbox,
    Loading,
    Select,
    Option,
    InputNumber,
    Dialog,
    Carousel,
    CarouselItem,
    DatePicker,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Loading)
Vue.use(Select)
Vue.use(Option)
Vue.use(InputNumber)
Vue.use(Dialog)
Vue.use(Carousel)
Vue.use(CarouselItem)
Vue.use(DatePicker)
Vue.prototype.$message = Message
Vue.prototype.$alert = MessageBox.alert

import routerConfig from "@routes/openapi-signature/index.js"
let router = new VueRouter(routerConfig)

router.push({
    path: `/${location.search}`,
})

import storeConfig from "@store/openapi-signature/index.js"
let store = new Vuex.Store(storeConfig)

//APP注册
import App from "@page-components/openapi-signature/app.vue"

let vm = new Vue(Object.assign(App, {
    router,
    store
}))
vm.$mount("#app")