import { USER_EDITION } from "@utils/users.js"
import { getCurrentMemberWsid } from "@utils/enterprises.js"

import { getEnvelopeData } from "@interfaces/envelopes/index.js"
import { getUserRoles } from "@interfaces/policy/enterprise-roles.js"
import { getEnvelopeParticipants } from "@interfaces/envelopes/participants.js"
import { translateParticipantDatasFromEnd } from "@classes/envelopes/participants.js"

//获取一个人在信封当中的参与者角色列表
async function getCurrentParticipantsInEnvelope(userWsid, envelopeWsid) {
    //判断用户是个人版还是企业版
    let userEdition = USER_EDITION.getUserEditionByUserWsid(userWsid)
    if (userEdition === USER_EDITION.NULL){
        throw new Error("ERROR_USER_WSID") //错误的用户ID
    }

    let envelopActiveUserWsid = userWsid //信封中的用户ID 个人为PUSER 企业为MEM

    //当是企业成员时的额外操作
    let enterpriseRoles = []
    if (userEdition === USER_EDITION.ENTERPRISE){
        enterpriseRoles = await getUserRoles({
            authorWsid: userWsid
        }).then(res => {
            return res.data.data.enterpriseRoles.map(enterpriseRole => enterpriseRole.wsid)
        })

        //更新envelopActiveUserWsid
        envelopActiveUserWsid = await getCurrentMemberWsid(userWsid)
    }
    

    //获取信封参与者
    let participants = await getEnvelopeParticipants({
        envelopeWsid: envelopeWsid
    }).then(res => {
        return res.data.data.participants
    })

    //获取符合要求的当前参与者
    participants = translateParticipantDatasFromEnd(participants)
        .filter(participant => {
            if (userEdition === USER_EDITION.ENTERPRISE){
                if (enterpriseRoles.find(r => participant.authorWsid === r)){
                    return true
                }
            }
            return participant.authorWsid === envelopActiveUserWsid
        })
    return participants
}

//判断当前人是否为信封发起人
async function ifEnvelopeSender(userWsid, envelopeWsid){
    let senderWsid = await getEnvelopeData({
        envelopeWsid: envelopeWsid
    }).then(res => {
        return res.data.data.envelope.basicInfo.senderWsid
    })

    let userEdition = USER_EDITION.getUserEditionByUserWsid(userWsid)
    if (userEdition === USER_EDITION.PEROSN){
        return userWsid === senderWsid
    } else if (userEdition === USER_EDITION.ENTERPRISE){
        return await getCurrentMemberWsid(userWsid) === senderWsid
    } else {
        return false
    }
}

export {
    getCurrentParticipantsInEnvelope,
    ifEnvelopeSender
}