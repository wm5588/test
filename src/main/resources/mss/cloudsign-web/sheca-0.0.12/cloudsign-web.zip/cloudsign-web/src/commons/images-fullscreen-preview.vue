<!--     
    @desc     图片全屏组件
    @level    ui：UI组件
    @author   周雪梅,陈曦源
    @date     2019-02-21 13:48:36
-->
<template>
    <transition name="fade">
        <div v-show="visiable" class="img-layer" @click="close" @mousewheel="mouseScale" :class="sourceType?'auth-background':''">
            <template v-if="images.length && sourceType" @click="close"> 
                <div class="head"><i class="el-icon-arrow-left left"></i>{{images[activeIndex].src.message || ""}}</div>
            </template>
            <transition name="fade">
                <img class="big-img" v-if="images[activeIndex]" :style="imageStyle" :key="images[activeIndex].src.realsrc" :src="images[activeIndex].src.realsrc"/>
            </transition>
            <template v-if="images.length > 1 && !sourceType">
                <div class="left-btn" @click.stop="preImage">
                    <svg width="50" height="100">
                        <path d="M 45 5 L 5 50 L 45 95" style="fill:transparent;stroke-width: 5px;stroke-linecap:round;stroke-linejoin:round"></path>
                    </svg>
                </div>
                <div class="right-btn" @click.stop="nextImage">
                    <svg width="50" height="100">
                        <path d="M 5 5 L 45 50 L 5 95" style="fill:transparent;stroke-width: 5px;stroke-linecap:round;stroke-linejoin:round"></path>
                    </svg>
                </div>
                <div class="footer">
                    {{activeIndex + 1}} / {{images.length}}
                </div>
            </template>
        </div>
    </transition>
</template>

<script>
export default {
    data(){
        return {
            visiable: false,
            imageMap: {},
            activeIndex: 0,
            oldBodyOverflow: "",

            originRect: null,
            imgRect: {
                top: 0,
                left: 0,
                height: 0,
                width: 0
            },
            source: null
        }
    },
    computed: {
        imageStyle(){
            let rect = this.imgRect
            return {
                top: rect.top + "px",
                left: rect.left + "px",
                height: rect.height + "px",
                width: rect.width + "px",
            }
        },
        images(){
            let imageMap = this.imageMap
            return Object.keys(imageMap).map(key => {
                return imageMap[key]
            })
        },
        sourceType(){
            if (this.source && this.source === "AUTH_PREVIEW"){
                return true
            } else {
                return false
            }
        }
    },
    watch: {
        visiable(nv){
            if (nv){
                this.oldBodyOverflow = document.body.style.overflow
                document.body.style.overflow = "hidden"
            } else {
                document.body.style.overflow = this.oldBodyOverflow
            }
        }
    },
    methods: {
        preImage(){
            let index = this.activeIndex - 1
            if (index < 0) index = this.images.length - 1
            this.activeIndex = index
            this.$nextTick(this.initImage)
        },
        nextImage(){
            let index = this.activeIndex + 1
            if (index >= this.images.length) index = 0
            this.activeIndex = index
            this.$nextTick(this.initImage)
        },
        mouseScale(){

        },
        appendImage(id, src){
            this.$set(this.imageMap, id, {
                id,
                src
            })
        },
        updateImage(id, src){
            this.imageMap[id].src = src
        },
        removeImage(id){
            this.$delete(this.imageMap, id)
        },
        initImage(){
            let src = this.images[this.activeIndex].src.realsrc
            let img = new Image()
            img.src = src
            img.onload = e => {
                let width = img.width
                let height = img.height
                let imgRect = this.imgRect
                

                let viewHeight = document.documentElement.clientHeight
                let viewWidth = document.documentElement.clientWidth
                let p 
                console.log(viewWidth)
                if(viewWidth > 510){
                    p = Math.min(500 / width, viewHeight * 0.8 / height)
                } else {
                    p = Math.min(300 / width, viewHeight * 0.8 / height)
                }
                
                imgRect.width = width * p
                imgRect.height = height * p
                imgRect.left = viewWidth / 2 - imgRect.width / 2
                imgRect.top = viewHeight / 2 - imgRect.height / 2
            }
        },
        open(id, srcDom){
            if (id){
                let index = this.images.findIndex(image => image.id == id)
                if (index === -1) index = 0
                this.activeIndex = index
            }
            
            let rect = srcDom.getBoundingClientRect()
            let imgRect = this.imgRect
            this.originRect = rect
            imgRect.top = rect.top
            imgRect.left = rect.left
            imgRect.width = rect.width
            imgRect.height = rect.height

            this.visiable = true
            this.$nextTick(this.initImage)
        },
        close(){
            let rect = this.originRect
            let imgRect = this.imgRect
            imgRect.top = rect.top
            imgRect.left = rect.left
            imgRect.width = rect.width
            imgRect.height = rect.height
            this.visiable = false
        }
    }
}
</script>

<style lang="less" scoped>
.fade-enter{
    opacity: 0;
}
.fade-enter-to{
    opacity: 1;
}

.fade-leave{
    opacity: 1;
}
.fade-leave-to{
    opacity: 0;
}

.fade-enter-active, .fade-leave-active {
    transition: opacity .33s;
}

/*遮罩层样式*/
 .img-layer {
    position: fixed;
    z-index: 9999;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.7);
    width: 100%;
    height: 100%;
    overflow: hidden;
}
.seal-background{
     background: rgba(255, 255, 255, 0.8);
}
.auth-background{
    background: rgba(0, 0, 0, 1);
}
.left{
    text-align: left;
    position: absolute;
    left: 0;
    height: 40px;
    line-height: 40px;
    width: 40px;
    text-align: center;
}
/*不限制图片大小，实现居中*/
.big-img {
    display: block;
    position:absolute;
    transition: all .5s;
    width:90%
}

.btn(){
    z-index: 100;
    cursor: pointer;
    position: absolute;
    top: 50%;
    transform: translate(0, -50%);

    path{
        stroke:#ffffff9c;
        transition: stroke .3s;
    }

    &:hover{
        path{
            stroke:#ffffff;
        }
    }
}

.left-btn{
    .btn;
    left: 20px;
}

.right-btn{
    .btn;
    right: 20px;
}

.head{
    z-index: 100;
    position: absolute;
    left: 0;
    right: 0;
    top: 0px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    background:#fff;
}
.footer{
    z-index: 100;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 10px;
    height: 30px;
    line-height: 30px;
    text-align: center;
    color:#fff;
}
</style>