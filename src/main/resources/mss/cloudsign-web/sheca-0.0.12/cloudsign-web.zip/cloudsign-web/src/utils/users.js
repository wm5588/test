import { getUserAccounts} from "@interfaces/user/user.js"

class USER_EDITION{
    static getUserEditionByUserWsid(userWsid){
        if (/^WSID_PUSR/.test(userWsid)){
            return USER_EDITION.PERSON
        } else if (/^WSID_EUSR/.test(userWsid)) {
            return USER_EDITION.ENTERPRISE
        } else {
            return USER_EDITION.NULL
        }
    }
}

USER_EDITION.PERSON = "p"
USER_EDITION.ENTERPRISE = "e"
USER_EDITION.NULL = ""


//用户尝试切换到目标企业下
async function userAccountInEnterprise(userWsid, enterpriseName){
    let accounts = await getUserAccounts({
        userWsid: userWsid,
        limit: 10000
    }).then(res => res.data.data.accounts)
    let account = accounts.find(account => account.enterpriseName === enterpriseName && account.idttvStatus === "SENIOR_PASSED")
    return account
}

export {
    USER_EDITION,
    userAccountInEnterprise
}