<template>
    <div class="cut">
        <div class="container" ref = 'cont'>
            <div class='clip-main'>
                 <div class="box" ref='box'></div>
                 <div class="clip" ref='clip'></div>   
                <!-- <div class="clip" ref='clip' @mousedown='clipMove($event)'></div> -->
            </div>
           <div class="preview" ref='pre'>
            </div>
            <span class='preview-title'>签章预览</span>
            <!--<div class='example-container'>
                <div class="example-seal">
                    <div v-for='es in exampleSeals'>
                       <span :style='{background:"url("+es+") center no-repeat"}'></span>
                    </div>
                </div>
                <span class='example-title'>上传示例</span>
            </div>-->
            <div class='clip-oper'>
                <span @click='rotate("l")'><i class="icon icon-left-90"></i></span>
                <span @click='rotate("r")'><i class="icon icon-right-90"></i></span>
                <span @click='zoom(0.1)'><i class="icon icon-zoom-out"></i></span>
                <span @click='zoom(-0.1)'><i class="icon icon-zoom-in"></i></span>
            </div>
        </div>
        <div class="upload-info">
            <p>单击“生成/生成签名”，即表示同意该签章可用于签署您（或您的代理）的各种文件，包括具有法律约束力的合约，与用笔纸上的签章具有相同效力。</p>
        </div>
        <div class="clip-btn">
            <span class="reupload">
                <input type="file" ref='inputImg' @change='inputChange()' />
                <span>重传</span>
            </span>
            <button @click='buildImg(preImg,preRect,previewBox)'><span>生成</span></button>
        </div>
    </div>
</template>


<script>
    export default{
        props: ['imgurl'],
        data: function(){
            return {
                box: {
                    width: 230,
                    height: 230
                },
                previewBox: {
                    width: 130,
                    height: 130
                },
                initialImg: {
                },
                realImg: {
                },
                direction: 0, //图片方向 0：上，1：右，2：下，3：左
                imgScale: 1,
                clipImg: {},
                clip: {},
                preRect: {},
                clipDown: false,
                imgDown: false,
                exampleSeals: ['/img/seal/mistake-gf.png', '/img/seal/mistake-bq.png', '/img/seal/mistake-mh.png', '/img/seal/mistake-gg.png']
            }
        },
        // computed:{
        //     // scale:function(){ 
        //     //     let me = this;
        //     //     return me.previewBox.width / me.clip.width;
        //     // },
        // },
        mounted: function(){
            this.resizeImg(this.imgurl)
    },
        methods: {
            inputChange: function () {
                let me = this
                let imgSrc = me.$refs.inputImg.value
                let reg = /\.(jpg|png|jpeg|gif)$/i
                if (!reg.test(imgSrc)) {
                    alert('请选择图片文件')
                    me.$refs.inputImg.value = ''
                } else {
                    if (!window.FileReader) {
                        alert('浏览器不兼容FileReader')
                        return
                    } else {
                        let reader = new FileReader()
                        reader.onload = function (item) {
                            me.resizeImg(item.target.result)
                        }
                        reader.readAsDataURL(me.$refs.inputImg.files[0])
                    }
                }
            },
            resizeImg: function (src) {
                let me = this
                me.img = new Image()
                me.preImg = new Image()
                me.img.src = src
                me.img.setAttribute('ondragstart', 'return false;')
                me.img.style.webkitUserSelect = 'none'
                me.preImg.src = src
                me.img.onload = function(){
                    me.realImg.width = me.img.width
                    me.realImg.height = me.img.height
                    if (me.img.width > me.img.height) {

                        me.clipImg.width = me.box.width
                        me.clipImg.height = me.box.width / me.img.width * me.img.height
                        me.clipImg.top = (me.box.height - me.clipImg.height) / 2
                        me.clipImg.left = 0
                        me.initialImg.width = me.clipImg.width
                        me.initialImg.height = me.clipImg.height


                        me.clip.width = me.clipImg.height
                        me.clip.height = me.clipImg.height
                        me.clip.top = me.clipImg.top
                        me.clip.left = (me.box.width - me.clip.width) / 2
                

                    } else {
                        me.clipImg.height = me.box.height
                        me.clipImg.width = me.box.height / me.img.height * me.img.width
                        me.clipImg.top = 0
                        me.clipImg.left = (me.box.width - me.clipImg.width) / 2

                        me.initialImg.width = me.clipImg.width
                        me.initialImg.height = me.clipImg.height


                        me.clip.width = me.clipImg.width
                        me.clip.height = me.clipImg.width
                        me.clip.left = me.clipImg.left
                        me.clip.top = (me.box.height - me.clip.height) / 2


                    }
                    me.calcStyle()
                    me.img.addEventListener('mousedown', me.picMove)
                    me.$refs.clip.addEventListener('mousedown', me.clipMove)
                    me.$refs.box.innerHTML = ''
                    me.$refs.pre.innerHTML = ''
                    me.$refs.box.appendChild(me.img)
                    me.$refs.pre.appendChild(me.preImg)
                }
                
            },
            // clipMove:function(event){
            //     let me = this;
            //     me.clipDown = true;
            //     let e = event||window.event;
            //     me.start = {
            //         x:e.clientX,
            //         y:e.clientY
            //     };
            //     window.addEventListener('mousemove',function(event){
            //         if(!me.clipDown)
            //             return;
            //         let e = event || window.event;
            //         let dx = e.clientX - me.start.x;
            //         let dy = e.clientY - me.start.y;
            //         me.start = {
            //             x:e.clientX,
            //             y:e.clientY
            //         };
            //         me.clip.left += dx;
            //         me.clip.top += dy;
            //         if(me.clip.left < 0)
            //             me.clip.left = 0;
            //         if(me.clip.top < 0)
            //             me.clip.top = 0;
            //         if(me.clip.left + me.clip.width > me.box.width)
            //             me.clip.left = me.box.width - me.clip.width;
            //         if(me.clip.top + me.clip.height > me.box.height)
            //             me.clip.top = me.box.height - me.clip.height;
            //         me.calcStyle();
            //     });
            //     window.addEventListener('mouseup',function(){
            //         me.clipDown = false;
            //     })
            // },
            picMove: function(event){
                let me = this
                me.imgDown = true
                let e = event || window.event
                me.start = {
                    x: e.clientX,
                    y: e.clientY
                }
                window.addEventListener('mousemove', function(event){
                    if (!me.imgDown)
                        return
                    let e = event || window.event
                    let dx = e.clientX - me.start.x
                    let dy = e.clientY - me.start.y
                    me.start = {
                        x: e.clientX,
                        y: e.clientY
                    }
                    me.clipImg.left += dx
                    me.clipImg.top += dy
                    if (me.direction % 2 == 0){
                        if (me.clipImg.left < -me.clipImg.width)
                            me.clipImg.left = -me.clipImg.width
                        if (me.clipImg.top < -me.clipImg.height)
                            me.clipImg.top = -me.clipImg.height
                        if (me.clipImg.left > me.box.width)
                            me.clipImg.left = me.box.width
                        if (me.clipImg.top > me.box.height)
                            me.clipImg.top = me.box.height
                    }
                    else {
                        if (me.clipImg.left < -(me.clipImg.width / 2 + me.clipImg.height / 2))
                            me.clipImg.left = -(me.clipImg.width / 2 + me.clipImg.height / 2)
                        if (me.clipImg.top < -(me.clipImg.width + me.clipImg.height) / 2)
                            me.clipImg.top = -(me.clipImg.width + me.clipImg.height) / 2
                        if (me.clipImg.left > me.box.width + me.clipImg.height / 2 - me.clipImg.width / 2)
                            me.clipImg.left = me.box.width + me.clipImg.height / 2 - me.clipImg.width / 2
                        if (me.clipImg.top > me.box.height - (me.clipImg.height - me.clipImg.width) / 2 )
                            me.clipImg.top = me.box.height - (me.clipImg.height - me.clipImg.width) / 2
                    }
                    
                    me.calcStyle()
                })
                window.addEventListener('mouseup', function(){
                    me.imgDown = false
                })
            },
            calcStyle: function(){
                let me = this
                me.calcPreRect()
                me.img.style.cssText += 'position:absolute;width:' + me.clipImg.width + 'px;height:' + me.clipImg.height + 'px;left:' + me.clipImg.left + 'px;top:' + me.clipImg.top + 'px'
                me.preImg.style.cssText += 'position:absolute;width:' + me.preRect.width + 'px;height:' + me.preRect.height + 'px;left:' + me.preRect.left + 'px;top:' + me.preRect.top + 'px'
                me.$refs.clip.style.cssText += 'position:absolute;width:' + me.clip.width + 'px;height:' + me.clip.height + 'px;left:' + me.clip.left + 'px;top:' + me.clip.top + 'px'
            },
            calcPreRect: function(){
                let me = this
                me.scale = me.previewBox.width / me.clip.width
                me.preRect = {
                    width: me.clipImg.width * me.scale,
                    height: me.clipImg.height * me.scale,
                    top: (me.clipImg.top - me.clip.top) * me.scale,
                    left: (me.clipImg.left - me.clip.left) * me.scale
                }
            },
            
            buildImg: function(){
                // getBoundingClientRect这个方法返回一个矩形对象，包含四个属性：left、top、right和bottom。分别表示元素各边与页面上边和左边的距离
                let me = this
                let clipR = me.$refs.pre.getBoundingClientRect()
                let imgR = me.preImg.getBoundingClientRect()
                let canvas = document.createElement('canvas')
                canvas.width = me.previewBox.width
                canvas.height = me.previewBox.height
                let ctx = canvas.getContext('2d')
            
                let xPos = canvas.width / 2
                let yPos = canvas.height / 2
                ctx.clearRect(0, 0, 150, 150)
                ctx.save()
                ctx.translate(xPos, yPos)
                ctx.rotate(me.direction * 90 * Math.PI / 180)
                ctx.translate(-xPos, -yPos)

                let realScale = me.realImg.width / me.preRect.width
                //console.log(imgR,clipR);
                let l, t
                switch (me.direction){
                    case 0:
                        //不知道为什么 就是要加一；若不加一会出现图片错位的问题
                        l = clipR.left - imgR.left + 1
                        t = clipR.top - imgR.top + 1
                        ctx.drawImage(me.preImg, l * realScale, t * realScale, clipR.width * realScale, clipR.height * realScale, 0, 0, me.previewBox.width, me.previewBox.height)
                        break
                    case 1:
                        l = clipR.top - imgR.top + 1
                        t = imgR.right - clipR.right + 1
                        ctx.drawImage(me.preImg, l * realScale, t * realScale, clipR.width * realScale, clipR.height * realScale, 0, 0, me.previewBox.width, me.previewBox.height)
                        break
                    case 2:
                        l = imgR.right - clipR.right + 1
                        t = imgR.bottom - clipR.bottom + 1
                        ctx.drawImage(me.preImg, l * realScale, t * realScale, clipR.width * realScale, clipR.height * realScale, 0, 0, me.previewBox.width, me.previewBox.height)
                        break
                    case 3:
                        l = imgR.bottom - clipR.bottom + 1
                        t = clipR.left - imgR.left + 1
                        ctx.drawImage(me.preImg, l * realScale, t * realScale, clipR.width * realScale, clipR.height * realScale, 0, 0, me.previewBox.width, me.previewBox.height)
                        break
                }
                me.$emit('send-img', canvas.toDataURL("image/png"))//触发父组件的send-img,send-img,并传参数canvas.toDataURL("image/png")
                ctx.restore()
            },
            /**
            * 
            * @param {float} scale   放大或缩小的倍数
            */
            zoom: function(scale){
                let me = this
                me.imgScale += scale
                if (me.imgScale === 0)
                    me.imgScale === 0.1
                let w = me.clipImg.width
                let h = me.clipImg.height
                me.clipImg.width = me.initialImg.width * me.imgScale
                me.clipImg.height = me.initialImg.height * me.imgScale
                me.clipImg.left -= (me.clipImg.width - w) / 2
                me.clipImg.top -= (me.clipImg.height - h) / 2
                me.calcPreRect()
                me.calcStyle()
            },
            /**
            * 
            * @param {string} d   旋转方向（'l'：向左转，'r'：向右转）
            */
            rotate: function(d){
                let me = this
                if (d === 'r')
                    me.direction = (me.direction + 1) % 4
                else {
                    me.direction = (me.direction + 3) % 4
                }
                me.img.style.transform = 'rotate(' + (me.direction * 90) + 'deg)'
                me.preImg.style.transform = 'rotate(' + (me.direction * 90) + 'deg)'
            }
        }
    }
</script>


<style scoped>
    .cut .container{
        height:330px;
        position:relative;
    }
    .cut .container .clip-main{
        width: 230px;
        height: 230px;
        border: 20px solid #ccc;
        position: absolute;
    }
    .cut .box{
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        right: 0;
        overflow: hidden;
    }
    .cut .clip{
        border: 1px solid #33cc99;
        box-sizing: border-box;
        position: absolute;
        cursor: move;
    }
    .cut .preview{
        position: absolute;
        width:130px;
        height: 130px;
        border: #dbdee2 1px solid;
        overflow: hidden;
        right:  0; 
        box-sizing: border-box;
    }
    .cut .preview-title{
        position:absolute;
        width:130px;
        text-align:center;
        display:inline-block;
        top:135px;
        right:0;
    }
    .cut .clip-oper{
        position:relative;
        top:290px;
        width:270px;
        text-align:center;
    }
    .icon{
        color:#fff;
    }
    .cut .clip-oper span{
        display:inline-block;
        margin:0 15px;
        width:32px;
        text-align:center;
        line-height:32px;
        border-radius:16px;
        background:#7c7c7c;
        color:#fff;
        cursor:pointer;
        font-size:20px;
    }
    .cut .clip-oper span:hover{
        background:#3c4651;
    }
    .cut .example-container{
        width:130px;
        height:150px;
        position:absolute;
        right:0;
        top:160px;
    }
    .cut .example-container .example-title{
        display:inline-block;
        text-align:center;
        width:100%;
    }
    .cut .example-container .example-seal div{
        display:inline-block;
        height:62px;
        overflow:hidden;
    }
    .cut .example-container .example-seal div span{
        width:60px;
        height:60px;
        display:inline-block;
        background-size:100% 100%;
        border: 1px solid #efefef;
    }
    .cut .upload-info{
        position:absolute;
        padding-bottom: 20px;
        width:490px;
        font-size: 12px;
        color: #91969d;
        text-align: left;
    }
    .cut .clip-btn{
        text-align:right;
        margin-top:50px;
    }
    .cut .clip-btn .reupload{
        position: relative;
        width: 70px;
        padding: 10px 45px;
        color: #fff;
        background-color: #a7b2b8;
        margin-right:5px;
        font-size:16px;
    }
    .cut .clip-btn .reupload:hover{
        background-color: #91969d;
    }
    .cut .clip-btn .reupload input{
        font-size: 0;
        display: inline-block;
        width: 100%;
        height: 100%;
        opacity: 0;
        -moz-opacity: 0;
        filter: alpha(opacity=0);
        cursor: pointer;
        position: absolute;
        z-index: 1;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
    }
    .cut .clip-btn  button{
        background-color: #095db1;
        color:#fff;
        border: 0;
        width: 130px;
        padding: 10px 30px;
        cursor: pointer;
        font-size:16px;
    }
</style>