import Vue from 'vue'

//事件名称：fileUpLoad
//功能描述：拖拽上传文件事件监听

export default new Vue()