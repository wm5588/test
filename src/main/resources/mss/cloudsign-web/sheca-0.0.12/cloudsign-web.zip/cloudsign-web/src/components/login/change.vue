<template lang="html">
  <div class="info">
    <el-button v-for="account in accounts" :key="account.id" :type="account.now ? 'info' : 'default'"  
        @click="change(account.id)">
        {{account.name}}
    </el-button>
    <p>蓝色为当前账户，白色为可切换账户</p>
  </div>
</template>

<script>
export default {
    computed: {
        accounts() {
            return this.$store.getters.userAccounts.map(account => {
                let name

                if (account.enterpriseName) name = account.enterpriseName
                else name = "个人版"

                let now = false

                if (account.userWsid === this.$store.getters.userWsid)
                    now = true

                return {
                    name,
                    now,
                    id: account.userWsid
                }
            })
        }
    },
    methods: {
        change: function (destinationWsid) {
            this.$store.dispatch("changeUserAccount", destinationWsid).then(_ => {
                this.$router.replace("/user")
            })
        }
    }
}
</script>

<style scoped>
.el-button{
    width:96%;
    margin: auto;
    display: block;
    margin-bottom: 10px;
}
</style>
