<!--
    @id        ui-code-explain
    @desc      收不到验证码组件
    @level     ui：UI组件
    @author    周雪梅
    @date      2018-12-18 21:38:02
-->
<template>
	<modal @close-modal='close' @close-dialog="close" width='90%' height='260px' :top="top" title='收不到验证码'>
		<div class="modal-container">
            <p slot="messages">1、{{messages}}</p>
			<p slot="msg">2、{{msg}}</p>
			<p slot="message">3、{{message}}</p>
            <div  v-if="type=='PHONE'">
                <p>4、如果接收不到短信，可以绑定邮箱获取验证码</p>
                <p>5、若仍无法解决，请联系客服021-962600</p>
            </div>
			<div v-else>
                <p>4、若仍无法解决，请联系客服021-962600</p>
            </div>
		</div>
    </modal>
</template>

<script>
import modal from "./modal.vue"
export default{
    props: {
        msg: {
            type: String
        },
        messages: {
            type: String
        },
        message: {
            type: String
        },
        top: {
            type: String,
            default: "200px"
        },
        type: String
    },
    data(){
        return {
        }
    },
    methods: {
        close(){
            this.$emit("close-modal")
        }
    },
    components: {modal}
}
</script>

<style scoped>
.modal-container{
	text-align:left;
	padding:20px 20px;
}
.modal-container p{
	line-height:25px;
}
</style>