let config = {
    url: {
        app: "https://app.signit.cn", //主站地址
        developer: "https://developer.signit.cn", //开放平台地址
        ws: "wss://ws-app.signit.cn", //websocket地址
        link: "http://r.signit.cn"
    }
}

export { config }