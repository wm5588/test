let errormsg = require('./errormsg.json')

exports.senderror = function(res, code, data){
    let err = {
        code: code,
        msg: errormsg[code]
    }
    if (data) err.data = data

    if (/^000/.test(code)){
        res.status(500)
    } else {
        res.status(400)
    }
    res.json({err})
}
