//由于VUE-ROUTER设置的key，当访问相同路径的页面时，会将老旧的页面的key值提升到相同页面的最高值，导致后续无法判断当前所处的页面位置
//遂暂时采用直接记录每次页面的访问路径的方式

const HISTORY_MAX_SIZE = 100
const STORE_KEY = "vue-router-history-routes-store"

class VueRouterHistory{
    
    constructor(router){
        router.$history = this

        this._router = router
        this.routes = []
        
        this.init()
    }

    //初始化监听router信息
    init(){
        let router = this._router
        let route = router.currentRoute
        this.loadData()

        router.afterEach((to, form) => {
            if (this.routes.length > HISTORY_MAX_SIZE) this.routes.pop()
            this.routes.unshift({
                fullPath: to.fullPath,
                hash: to.hash,
                name: to.name,
                params: to.params,
                path: to.path,
                query: to.query
            })
            this.saveData()
        })
    }

    saveData(){
        let sessionStorage = window.sessionStorage
        if (!sessionStorage) return
        sessionStorage.setItem(STORE_KEY, JSON.stringify(this.routes))
    }
    
    loadData(){
        let sessionStorage = window.sessionStorage
        if (!sessionStorage) return
        let data
        try {
            data = sessionStorage.getItem(STORE_KEY)
            data = JSON.parse(data)
            this.routes = data || []
        } catch (e) {
            this.routes = []
        }
    }
}

export default VueRouterHistory