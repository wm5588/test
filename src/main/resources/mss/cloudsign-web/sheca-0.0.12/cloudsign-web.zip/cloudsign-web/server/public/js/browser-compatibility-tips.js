/*eslint-disable*/

/*  浏览器兼容性提示脚本,只考虑PC端    */

/*
提示级别：ERROR   无法使用

以是否支持webSocket为判断依据
*/

/*
提示级别：WARING   警告，主要提示浏览器版本过低
IE all
FireFox < 40
Chrome < 40
*/

(function(){
    var STATE
    
    if (checkError()){
        STATE = "ERROR";
        tips_error();
    // } else if (checkWarning()){//暂时不加提示
    //     STATE = "WARING";
    //     tips_warning();
    } else {
        STATE = "PASS";
    }
    
    //检查是否不可运行
    function checkError(){
        return !window.WebSocket;
    }
    
    //检查是否需要警告
    function checkWarning(){
        return false;
    }
    
    //提示必须更换浏览器
    function tips_error(){
        var div = document.createElement("div");
        div.className = "error-container";
        div.innerHTML = '<div class="tips-container">'+
                            '<img src="./img/bad-browser-dialog.png"/>'+
                            '<a class="chrome-download" target="_blanck" href="http://www.google.cn/chrome/browser/desktop/index.html">立即下载</a>'+
                            '<a class="firefox-download" target="_blanck" href="http://www.firefox.com.cn/">立即下载</a>'+
                        '</div>';
        document.body.appendChild(div);

        var style = document.createElement("style");
        style.setAttribute('type', 'text/css')
        var styleContent = '.error-container{'+
            'z-index: 20001;'+
            'position: fixed;'+
            'left: 0;'+
            'top: 0;'+
            'width: 100%;'+
            'height: 100%;'+
            'background: #888888;'+
            'background: rgba(0,0,0, 0.2);'+
        '}\n'+
        '.tips-container{'+
            'position:absolute;'+
            'top:50%;'+
            'left:50%;'+
            'margin-left:-450px;'+
            'margin-top:-200px;'+
            'height: 400px;'+
            'width: 900px;'+
        '}'+
        '.chrome-download{'+
            'cursor:pointer;'+
            'position:absolute;'+
            'top:313px;'+
            'left:358px;'+
            'height: 30px;'+
            'line-height: 30px;'+
            'color: white;'+
            'width: 100px;'+
            'text-align: center;'+
            'text-decoration:none;'+
            'text-decoration-line: none;'+
        '}'+
        '.firefox-download{'+
            'display:block;'+
            'cursor:pointer;'+
            'position:absolute;'+
            'top:313px;'+
            'left:488px;'+
            'height: 30px;'+
            'line-height: 30px;'+
            'color: white;'+
            'width: 100px;'+
            'text-align: center;'+
            'text-decoration:none;'+
            'text-decoration-line: none;'+
        '}';
        if(style.styleSheet){
            style.styleSheet.cssText = styleContent
        } else {
            style.innerHTML = styleContent
        }

        document.body.appendChild(style);
    }
    
    //建议更换浏览器
    function tips_warning(){
        alert("辣鸡的浏览器");
    }
})();
