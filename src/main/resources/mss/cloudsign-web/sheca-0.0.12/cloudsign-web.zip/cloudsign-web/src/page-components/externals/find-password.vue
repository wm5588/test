<template lang="html">
    <externalFrame>
        <h1 class="pic-title">{{findPasswordTitle}}</h1>
        <vfindpassword @findpasswordsuccess="findpasswordsuccess"></vfindpassword>
    </externalFrame>
</template>

<script>
import externalFrame from "@page-components/frames/external-frame.vue"
import vfindpassword from '@components/login/find-password.vue'

export default {
    data(){
        return {
            findPasswordTitle: "找回密码"
        }
    },
    methods: {
        findpasswordsuccess(){
            this.findPasswordTitle = "重置密码"
        }
    },
    components: { vfindpassword, externalFrame }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
</style>

