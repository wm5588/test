import axios from "@interfaces/axios.js"
import { getEnvelopeDocuments } from "./documents.js"

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/:participantWsid/reject
 * @method POST
 * @desc   拒签文件
 * @author 陈曦源
 * @date   2018-01-31 16:57:49
 * ----------------------------------------------------
 */
export function rejectEnvelope(obj) {
    let {
        envelopeWsid,
        participantWsid,
        rejectReason
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/participants/${participantWsid}/reject`, {
        rejectReason
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/:participantWsid/authorize
 * @method POST
 * @desc   转签
 * @author 周雪梅
 * @date   2018-01-31 16:57:49
 * ----------------------------------------------------
 */
export function transferSiginEnvelope(obj) {
    let {
        envelopeWsid,
        participantWsid,
        name,
        message,
        contact
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/participants/${participantWsid}/authorize`, {
        name,
        message,
        contact
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/revoke
 * @method POST
 * @desc   撤销文件
 * @author 陈曦源
 * @date   2018-01-31 16:57:52
 * ----------------------------------------------------
 */
export function revokeEnvelope(obj) {
    let {
        envelopeWsid,
        revokeReason
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/revoke`, {
        revokeReason
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/:participantWsid/check
 * @method POST
 * @desc   审核信封
 * @author 陈曦源
 * @date   2018-02-01 14:25:52
 * ----------------------------------------------------
 */
export function checkEnvelope(obj) {
    let {
        envelopeWsid,
        participantWsid,
        checkPass,
        censorReason
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/participants/${participantWsid}/check`, {
        checkPass,
        censorReason
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/:participantWsid/confirm
 * @method POST
 * @desc   确认信封
 * @author 陈曦源
 * @date   2018-09-03 21:55:23
 * ----------------------------------------------------
 */
export function confirmEnvelope(obj) {
    let {
        envelopeWsid,
        participantWsid,
        opcode
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/participants/${participantWsid}/confirm`, {
        opcode
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/:participantWsid/view
 * @method POST
 * @desc   浏览信封
 * @author 陈曦源
 * @date   2019-04-29 15:08:45
 * ----------------------------------------------------
 */
export function viewEnvelope(obj) {
    let {
        envelopeWsid,
        participantWsid,
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/participants/${participantWsid}/view`)
}

/**
 * ----------------------------------------------------
 * @desc  删除指定信封
 * @from  信封流转微服务API-信封资源操作 | DELETE /envelopes/{envelope-wsid}
 * @date  2017-08-02 10:02:26
 * ----------------------------------------------------
 */
export function envelopes_delete(obj) {
    let {
        envelopeWsid
    } = obj

    return axios.delete("/api/envelopes/" + envelopeWsid, {})
}

/**
 * ----------------------------------------------------
 * @desc  创建一个信封（正常流程）
 * @from  信封流转微服务API-信封资源操作 | POST /envelopes/normal
 * @date  2017-08-02 17:33:54
 * ----------------------------------------------------
 */
export function envelopesNormal_post(obj) {
    let {
        type
    } = obj

    return axios.post("/api/envelopes/normal", {
        type
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/pack
 * @method POST
 * @desc   打包下载文件
 * @author 陈曦源
 * @date   2019-11-14 10:02:47
 * ----------------------------------------------------
 */
export function downloadEnvelope(obj = {}) {
    let {
        name,
        envelopeWsid,
        withAudit,
        type
    } = obj

    if (type == "PDF") {
        window.open(`/api/envelopes/${envelopeWsid}/pack?withAudit=${withAudit}&filename=《${name || envelopeWsid}》电子文档.pdf`)
    } else {
        window.open(`/api/envelopes/${envelopeWsid}/pack?withAudit=${withAudit}&filename=《${name || envelopeWsid}》电子文档.zip`)
    }

    return Promise.resolve()
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/audit
 * @method POST
 * @desc   查看、下载凭证
 * @author 潘维, 陈曦源
 * @date   2018-08-15 11:44:53
 * ----------------------------------------------------
 */
export function downloadAudit(obj) {
    let {
        name,
        envelopeWsid,
    } = obj

    window.open(`/api/envelopes/${envelopeWsid}/audit?filename=${`《${name || envelopeWsid}》签署电子凭证.pdf`}`)

    return Promise.resolve()
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/notification-receive
 * @method POST
 * @desc   提醒信封参与者
 * @author 陈曦源
 * @date   2018-03-13 09:40:12
 * ----------------------------------------------------
 */
export function notificationParticipants(obj = {}) {
    let {
        envelopeWsid
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/participants/notification-receive`)
}

export function envelopes_create(obj) {
    let {
        type = 0//创建的信封类型
    } = obj

    return axios.post("/api/envelopes", {
        type
    })
}

export function envelope_start(obj) {
    let {
        envelopeId
    } = obj

    return axios.post("/api/envelopes/start", {
        envelopeId
    })
}

//获取指定信封信息
export function get_envelope(obj) {
    let {
        envelopeId,
        fields
    } = obj

    return axios.get("/api/envelope/get", {
        params: {
            envelopeId,
            fields
        }
    })
}

//提醒签名
export function notifyEnvelope(obj) {
    let {
        envelopeId
    } = obj
    
    return axios.post("/api/envelope/notify", {
        envelopeId
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/copy
 * @method POST
 * @desc   复制已完成的信封
 * @author 潘维
 * @date   2018-12-17 10:04:27
 * ----------------------------------------------------
 */
export function copyEnvelope(obj) {
    let {
        envelopeWsid
    } = obj
    
    return axios.post(`/api/envelopes/${envelopeWsid}/copy`, {
        envelopeWsid
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/:participantWsid/auth-types
 * @method GET
 * @desc   获取指定参与者签署认证类型
 * @author 潘维
 * @date   2019-04-25 14:34:21
 * ----------------------------------------------------
 */
export function getAuthTypes(obj) {
    let {
        envelopeWsid,
        participantWsid
    } = obj
    
    return axios.get(`/api/envelopes/${envelopeWsid}/participants/${participantWsid}/auth-types`)
}
