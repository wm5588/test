let nums = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K",
    "L", "M", "N", "O", "P", "Q", "R",
    "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
    "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x",
    "y", "z"
]

function getRandomCaptcha() {
    let canvas = document.createElement("canvas") //获取HTML端画布
    canvas.width = 100
    canvas.height = 60
    let context = canvas.getContext("2d") //获取画布2D上下文
    context.fillStyle = "cornflowerblue" //画布填充色
    context.fillRect(0, 0, canvas.width, canvas.height)
    // 创建渐变
    let gradient = context.createLinearGradient(0, 0, canvas.width, 0)
    gradient.addColorStop("0", "magenta")
    gradient.addColorStop("0.5", "blue")
    gradient.addColorStop("1.0", "red")
    //清空画布
    context.fillStyle = gradient //设置字体颜色
    context.font = "25px Arial" //设置字体
    let rand = new Array()
    let x = new Array()
    let y = new Array()
    for (let i = 0; i < 4; i++) {
        rand[i] = nums[Math.floor(Math.random() * nums.length)]
        x[i] = i * 16 + 10
        y[i] = Math.random() * 20 + 20
        context.fillText(rand[i], x[i], y[i])
    }
    //画3条随机线
    for (let i = 0; i < 3; i++) {
        drawline(canvas, context)
    }
    // 画30个随机点
    for (let i = 0; i < 30; i++) {
        drawDot(canvas, context)
    }

    let data = canvas.toDataURL("image/png")
    let code = rand.join("")
    return {
        data,
        code
    }
}
 
// 随机线
function drawline(canvas, context) {
    context.moveTo(Math.floor(Math.random() * canvas.width), Math.floor(Math.random() * canvas.height)) //随机线的起点x坐标是画布x坐标0位置，y坐标是画布高度的随机数
    context.lineTo(Math.floor(Math.random() * canvas.width), Math.floor(Math.random() * canvas.height)) //随机线的终点x坐标是画布宽度，y坐标是画布高度的随机数
    context.lineWidth = 0.5 //随机线宽
    context.strokeStyle = "rgba(50,50,50,0.3)" //随机线描边属性
    context.stroke() //描边，即起点描到终点
}
// 随机点(所谓画点其实就是画1px像素的线，方法不再赘述)
function drawDot(canvas, context) {
    let px = Math.floor(Math.random() * canvas.width)
    let py = Math.floor(Math.random() * canvas.height)
    context.moveTo(px, py)
    context.lineTo(px + 1, py + 1)
    context.lineWidth = 0.2
    context.stroke()
 
}

export default getRandomCaptcha