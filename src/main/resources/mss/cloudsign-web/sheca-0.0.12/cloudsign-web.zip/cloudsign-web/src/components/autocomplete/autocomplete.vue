<template>
    <div class="auto-input">
        <!-- 弹出框 -->
        <el-popover ref="popover" trigger="manual" :popper-class="enterpriseAuth? 'enterprise-auth-auto-complete-popover' : 'auto-complete-popover'" placement="bottom-start"
            :visible-arrow="true" :value="showSuggestion" @click.stop>
            <div class="box" :style="{width:width+'px'}">
                <li class="suggestion" v-for="(item, index) in suggestion" :key="index" @click="turnValue(item)">
                    <slot :item="item">
                        {{item[valueKey]}}
                    </slot>
                </li>
            </div>
        </el-popover>
        <el-input ref="input" v-popover:popover :value="value" :size="size" :placeholder="placeholder" :disabled="disabled"
            @input="valueUpdate" @focus="focus" @blur="blur" >
                <!-- 加载转圈圈 -->
                <template v-if="enterpriseAuth">
                    <i slot="suffix" class="arrow" :class="showSuggestion? 'el-icon-arrow-up' : 'el-icon-arrow-down'"></i>
                </template>
                <template v-else>
                    <i slot="suffix" class="el-input__icon el-icon-loading loading-icon" v-if="flag && loading"></i>
                </template>
        </el-input>
    </div>
</template>

<script>
function debounce(fn, wait){ 
    let timeout = null
    return function() {
        if (timeout !== null) clearTimeout(timeout)
        timeout = setTimeout(_ => {
            fn.apply(this, arguments)
        }, wait)
    }
}

export default {
    name: "AutoCompleteInput",
    props: {
        valueKey: {
            type: String,
            default: "value"
        },
        size: {
            type: String
        },
        value: [String, Number],
        placeholder: {
            type: String,
            default: ""
        },
        fetchSuggestions: Function,
        disabled: {
            type: Boolean,
            default: false
        },
        enterpriseAuth:{
            type: Boolean,
            default: false
        },
    },
    data () {
        return {
            showSuggestion: false,
            suggestion: [],
            loading: false,
            width: 0,
            flag: false
        }
    },
    created(){
        document.addEventListener("click", this.globalClickHandle)
        this.getData = debounce(this.getData, 500).bind(this)
    },
    beforeDestroy(){
        document.removeEventListener("click", this.globalClickHandle)
    },
    methods: {
        focus(){
            this.flag = true
            this.getData(this.value)
            this.$emit("focus")
        },
        blur(){
            this.flag = false
            this.$emit("blur")
        },
        globalClickHandle(){
            if(this.enterpriseAuth && this.flag){
                this.showSuggestion = true
            } else {
                this.showSuggestion = false
            }
            this.$forceUpdate()
        },
        valueUpdate(value){
            this.$emit("input", value)
            this.getData(value)
        },
        turnValue(item){
            this.$emit("input", item[this.valueKey])
            this.$emit("select", item)
            this.globalClickHandle()
        },
        getData(queryString){
            if (!this.flag) return
            if (!this.fetchSuggestions) return

            this.loading = true
            this.fetchSuggestions(queryString, (suggestions) => {
                this.loading = false
                this.suggestion = suggestions

                if (this.flag && suggestions.length > 0){
                    this.width = this.$refs.input.$el.getBoundingClientRect().width
                    this.showSuggestion = true
                } else if (suggestions.length === 0){
                    this.showSuggestion = false
                }
            })
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

.box{
    height: 200px;
    overflow: auto;
    margin: 0px;
    padding: 0px;
}

.loading-icon{
    font-size:20px;
    color:@color-main;
}

.suggestion{
    list-style:none;
    padding-bottom: 5px;
    padding-top: 5px;
    padding-left: 15px;
    padding-right: 10px;
}

.suggestion:hover{
    background:	@color-background;
}
    
</style>

<style>
.auto-complete-popover.el-popper{
  padding: 0px;
  padding-top: 10px;
}
.enterprise-auth-auto-complete-popover.el-popper{
  padding: 0px;
  padding-top: 10px;
  /* max-width: 496px;
  width: 100%; */
}
.arrow{
    line-height: 40px;
    width: 25px;
}
</style>

