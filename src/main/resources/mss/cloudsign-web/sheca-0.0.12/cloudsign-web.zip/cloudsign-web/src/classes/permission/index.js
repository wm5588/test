function translateEndPermissionToFont(permissions, enterpriseOwner){
    let map = {
        "ENVELOPE": [],
        "SEAL": [],
        "ENTERPRISE": [],
        "TEMPLATE": []
    }
    permissions.forEach((el, index) => {
        switch (el.permissions){
            case "enterprises:envelopes:view":
                map["ENVELOPE"].push("ENTERPRISE_ENVELOPE_ALL")
                break
            case "officeSeals:manage":
                map["SEAL"].push("SEAL_MANAGEMENT")
                map["SEAL"].push("SEAL_CREATE")
                map["SEAL"].push("SEAL_AUTHORIZE")
                break
            case "officeSeals:approve":
                map["SEAL"].push("SEAL_AUDIT")
                break
            case "members:manage":
                map["ENTERPRISE"].push("ENTERPRISE_MEMBERS_MANAGEMENT")
                break
            case "privileges:manage":
                map["ENTERPRISE"].push("ROLES_MANAGEMENT")
                break
            case "applications:manage":
                if (enterpriseOwner) { map["ENTERPRISE"].push("APPLICATIONS_MANAGEMENT") }
                break
            case "bills:manage":
                map["ENTERPRISE"].push("FINANCE_MANAGEMENT")
                break
            case "enterprises:{wsid}:contractNumbers:set":
                map["ENTERPRISE"].push("CONTRACT_NUMBER_SETTING")
                break
            case "businessScenarioTemplates:manage":
                map["TEMPLATE"].push("TEMPLATE_MANAGEMENT")
                map["TEMPLATE"].push("TEMPLATE_CREATE")
                break
        }
        
    })
    return map
}

export default {translateEndPermissionToFont}
export {translateEndPermissionToFont}