import IndexPage from "@page-components/to-signature/index.vue"
import CheckPage from "@page-components/to-signature/check.vue"
import SignPage from "@page-components/to-signature/sign.vue"
import ResultPage from "@page-components/to-signature/result.vue"

let routerConfig = {
    mode: "history",
    base: "/to-signature",
    routes: [
        {
            path: "/",
            meta: {
                title: "加载中"
            },
            component: IndexPage
        },
        {
            path: "/check",
            meta: {
                title: "加载中"
            },
            component: CheckPage
        },
        {
            path: "/sign",
            meta: {
                title: "加载中"
            },
            component: SignPage
        },
        {
            path: "/result",
            meta: {
                title: "加载中"
            },
            component: ResultPage
        },
    ]
}

export default routerConfig