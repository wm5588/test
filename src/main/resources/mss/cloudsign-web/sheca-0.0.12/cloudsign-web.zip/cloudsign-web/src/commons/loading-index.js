import Loading from '../components/modal/loading/loading.vue'

const loading={
    install:function(Vue){
        Vue.component('loading',Loading)
    }  //'Loading'这就是后面可以使用的组件的名字，install是默认的一个方法
};

export default loading;