import { scanUploadClient } from "./wsclient"

export function createRoom(obj){
    let {
        roomkey
    } = obj

    scanUploadClient.emit("create-room", {roomkey})
}

export function joinRoom(obj, cb){
    let {
        roomkey
    } = obj

    //FIXME: 暂时通过超时来检验
    let timeoutHandle

    scanUploadClient.emit("join-room", {roomkey})
    scanUploadClient.once(`room:${roomkey}:creater-exist`, () => {
        clearTimeout(timeoutHandle)
        cb()
    })

    timeoutHandle = setTimeout(_ => {
        scanUploadClient.off(`room:${roomkey}:creater-exist`)
        cb(new Error("TIME_OUT"))
    }, 5000)
}

export function createrExist(obj){
    let {
        roomkey,
        uploaderId
    } = obj

    scanUploadClient.emit("creater-in-room", {roomkey, uploaderId})
}

export function closeRoom(obj){
    let {
        roomkey
    } = obj

    scanUploadClient.emit("close-room", {
        roomkey 
    })
    scanUploadClient.off(`room:${roomkey}:upload`)
    scanUploadClient.off(`room:${roomkey}:uploader-join`)
}

export function uploadData(obj, cb){
    let {
        roomkey,
        imageData,
        sealData
    } = obj

    //FIXME: 暂时通过超时来检验
    let timeoutHandle

    scanUploadClient.emit("upload-to-room", {
        roomkey,
        imageData,
        sealData
    })
    scanUploadClient.once(`room:${roomkey}:upload-success`, () => {
        clearTimeout(timeoutHandle)
        cb()
    })

    timeoutHandle = setTimeout(_ => {
        scanUploadClient.off(`room:${roomkey}:upload-success`)
        cb(new Error("TIME_OUT"))
    }, 20 * 1000)
}

export function listenUpload(obj, cb){
    let {
        roomkey
    } = obj

    scanUploadClient.on(`room:${roomkey}:upload`, cb)
}

export function uploadSuccess(obj){
    let {
        roomkey,
        uploaderId
    } = obj

    scanUploadClient.emit("upload-success", {roomkey, uploaderId})
}

export function listenUploaderJoin(obj, cb){
    let {
        roomkey
    } = obj

    scanUploadClient.on(`room:${roomkey}:uploader-join`, cb)
}