<!--
    @id        ui-department-iten
    @desc      部门设置
    @level     UI组件
    @author    周雪梅
    @date      2019-01-05 18:47:48
-->
<template lang="html">
    <div class="department-item" @click="change">
         <div class="custom-tree-node" v-if="data.type === 'MEMBER'">
            <el-popover
                ref="popover"
                placement="right-start"
                width="210"
                popper-class="wesign-popper-tree-role-list"
                v-model="popoverVisible"
                visible-arrow = true
                trigger="click">
                <ul style="text-align:left">
                    <li>
                        <span><i class="icon-user user"></i></span>{{data.name}}
                    </li>
                    <li>
                        <span>工号：</span>{{data.staffNo || "暂无"}}
                    </li>
                    <li>
                        <span>手机：</span>{{data.phone || "暂无"}}
                    </li>
                    <li>
                        <span>邮箱</span>{{data.email || "暂无"}}
                    </li>
                </ul>
            </el-popover>
            <i class="icon-user user"></i> 
            {{data.name}}
            <i v-if="node.checked===true" class="el-icon-check right check"></i> 
            <span class="list" v-popover:popover @click.stop="change"><i class="icon-list2"></i></span>
        </div>
        <div v-else class="custom-tree-node"><i class="icon-folder-open user"></i>{{data.name}}</div>
    </div>
</template>
<script>

export default {
    props: ["node", "data", "store"],
    data(){
        return {
            popoverVisible: false,
        }
    },
    methods: {
        change(){
            document.body.click()
        },
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

ul{
    margin:0;
    padding:0;
}
.label-container{
    height:36px;
    line-height:36px;
}
.department-item{
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  display:inline-block;
  line-height:36px;
  text-indent:5px;
  width:85%;
  cursor:pointer;
  padding-right: 10px;
  box-sizing: border-box;
}


// .merber-itme .active,
// .department-item:hover{
  
//   background-color:@color-list-choose;

//   &:hover .label-operation{
//       display: inline-block;
//   }
// }
input {
  
    border:0;
}

.el-tree-node__content .active,
.el-tree-node__content:hover {
    background-color:@color-list-choose;
    .label-operation{
        display: inline-block;
    }
}
.label-operation{
    position: absolute;
    right: 0px;
    line-height: 36px;
    display: none;
    width: 30px;
    text-align: center;
}

.label-operation:active{
    color: @color-add
}
.user{
    margin-right:5px;
}

</style>
<style lang="less">

.department-item .el-input{
    width:85%;
}
.department-item .el-input__inner{
    padding:0;
    text-indent:5px;
}
.wesign-popper-tree-role-list{
    min-width:50px !important;
}
.el-tree{
    background:#fafafa !important;
}
.wesign-popper-tree-role-list li{
    height:38px;
    line-height:38px;
    max-width:210px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis

}
.wesign-popper-tree-role-list li:hover{
    cursor:pointer !important;
}
.wesign-popper-tree-role-list li span{
    width:42px;
    display:inline-block;
    i{
        font-size:20px;
    }
}
.custom-tree-node .list{
    height:38px;
    width:30px;
    text-align:center;
    line-height:38px;
    display:inline-block;
    position:absolute;
    right:0px;
    top:0px;
    i{
        font-size:16px;
    }
}
</style>