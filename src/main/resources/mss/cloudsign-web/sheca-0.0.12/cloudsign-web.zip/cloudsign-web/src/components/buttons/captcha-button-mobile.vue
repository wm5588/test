<template>
    <div>
        <div v-if="timeShow" class="send">{{timeShow}}s</div>
        <div v-else class="get-code" @click="sendVerifyCode">获取验证码</div>
    </div>
</template>

<script>
import captchaButton from "./captcha-button.vue"
import { MessageBox } from "mint-ui"

export default {
    mixins: [captchaButton],
    methods: {
        alert(message){
            MessageBox.alert(message, "提示", {
                type: "warning"
            }).then(_ => {})
        }
    }
}
</script>
<style lang="less" scoped>
.send{
    color: #999;
    text-align: center;
}
.send:hover,.send:active{
    color:#0c7ffc;
    font-size:0.14rem;
}
.get-code{
    color: #0c7ffc;
    font-size:0.14rem;
    text-align: right;
}

</style>

