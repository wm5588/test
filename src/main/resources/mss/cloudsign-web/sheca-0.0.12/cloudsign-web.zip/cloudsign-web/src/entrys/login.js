import "./common.js"
import "@styles/common.less"
import Vue from "vue"
import login from "@page-components/externals/login.vue"

//element-ui 引入
import {
    Row,
    Col,
    Message,
    Input,
    Button,
    Checkbox,
    Form,
    FormItem,
    Alert,
    Dialog,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Alert)
Vue.use(Dialog)
Vue.prototype.$message = Message

new Vue({
    el: "#app",
    template: "<login />",
    components: {
        login
    }
})