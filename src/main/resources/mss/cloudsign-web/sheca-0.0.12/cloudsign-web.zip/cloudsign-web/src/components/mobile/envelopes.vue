<!--
    @id        envelopes
    @desc      移动端查看信封列表页
    @level     system：系统组件
    @author    潘维
    @date      2019-01-03 14:26:27
-->
<template>
  <div class="wesign-mobile-main">
    <docNav :activeType="listActive" @change-active="changeStatus"></docNav>
    <div v-if="envelopes.length" class="doc-container" ref="scoller" :key="random">
      <div style="height: 0.03rem"></div>
      <div
        class="doc-list"
        v-infinite-scroll="loadMore"
        infinite-scroll-disabled="moreLoading"
        infinite-scroll-distance="10"
        infinite-scroll-immediate-check="false"
      >
        <div
          :key="index"
          v-for="(e,index) in envelopes"
          class="envelope-list border"
          @click.stop.prevent="getEnvelopeDetail(e.envelopeWsid)"
        >
          <div class="doc-detail">
            <div style="display:flex;align-items: center">
              <p class="doc-name">{{e.title}}</p>
              <span class="doc-bulk-tag" v-if="e.multisendNum">批量</span>
            </div>
            <p class="date">{{getDate(e.createdDatetime)}}</p>
            <p class="send-people">发起方：{{e.sender.username}}</p>
          </div>
          <div :class="tagClass(e.envelopeStatus)">{{getStatus(e.envelopeStatus)}}</div>
          <i
            v-if="e.envelopeStatus == 'SUCCESS_COMPLETED'"
            class="download icon-down-load"
            @click.stop="downloadDocument(e, e.envelopeWsid,e.title)"
          ></i>
        </div>
        <!--底部判断是加载图标还是提示“全部加载”-->
        <div class="more-loading" v-show="moreLoading">
          <mt-spinner type="snake" color="#999" :size="20"></mt-spinner>
        </div>
      </div>
    </div>
    <div class="doc-container-no" v-else>
      <div class="bg-pic">
        <img src="../../images/mobile/no-file-bg.png" />
      </div>
    </div>
  </div>
</template>

<script>
import { Toast, MessageBox, InfiniteScroll, Spinner, Indicator } from "mint-ui";
import docNav from "./common/doc-header.vue";
import { getEnvelopes } from "@interfaces/envelopes/index.js";
import {
  downloadEnvelope,
  downloadEnvelopes
} from "@interfaces/envelopes/envelope.js";
import { getEnvelopeDocuments } from "@interfaces/envelopes/documents.js";
import { EnvelopeStatus } from "@classes/mobile/envelopes.js";

import { newFormatDate } from "@commons/util.js";

export default {
  data() {
    return {
      envelopes: [],
      listActive: 0,
      envelopeStatusMap: {
        0: [101, 102, 103, 104, 105, 106, 201, 202, 203, 204, 205, 109, 210], //全部文档
        1: [104, 105, 109], //待我签署
        2: [106, 101, 102, 103], //待他人签署
        3: [201], //已完成
        4: [1], //草稿
        5: [203, 204, 205, 210, 202] //其他文件
      },
      moreLoading: false,
      currentPage: 1,
      totalPages: 20,
      limit: 10,
      allLoaded: false,

      random: Math.random(),
      type: ""
    };
  },
  computed: {
    nowQuery() {
      let query = JSON.parse(JSON.stringify(this.$route.query));
      return query;
    }
  },
  watch: {
    listActive(nv) {
      if (sessionStorage) {
        sessionStorage.setItem("listActiveType", nv);
      }
    }
  },
  created() {
    if (sessionStorage) {
      this.listActive = parseInt(sessionStorage.getItem("listActiveType")) || 0;
    }

    this.envelopes = [];
    let query = this.nowQuery;
    this.currentPage = 1;
    this.listActive = parseInt(query.status) || this.listActive;
    query.status = this.listActive;
    Indicator.open();
    setTimeout(_ => {
      this.getEnvelopesData(query);
    }, 333);
    this.allLoaded = false;
  },
  methods: {
    getEnvelopesData(query) {
      let { status = 0 } = query;
      let queryStatus = this.envelopeStatusMap[status] || [];
      let statutasKey = [];
      queryStatus.forEach(code => {
        let key = EnvelopeStatus.getKeyByCode(code);
        statutasKey.push(key);
      });
      let envelopeShownStatus = statutasKey.join(",") || undefined;
      let authorWsid = this.$store.getters.activeUserWsid;
      let filters = [];
      filters.push(`currentSequence>=assignedSequence`);
      filters = filters.join(",");
      if (!filters) filters = undefined;

      getEnvelopes({
        authorWsid,
        envelopeShownStatus,
        offset: (this.currentPage - 1) * this.limit,
        limit: this.limit,
        filters
      })
        .then(res => {
          let body = res.data;
          this.envelopes = this.envelopes.concat(body.data.envelopes);
          this.envelopes.forEach(e => {
            let array = e.sender.username.split(",");
            if (array.length > 1) {
              e.sender.username = array[1] + " (" + array[0] + ")";
            }
          });
          let page = res.data.data.page;
          this.totalPages = page.totalPages;

          if (page.number === page.totalPages) {
            this.allLoaded = true;
          }
        })
        .catch(err => {
          console.error(err);
        })
        .then(_ => {
          Indicator.close();
          this.moreLoading = false;
        });
    },
    downloadDocument(val, envelopeWsid, title) {
      getEnvelopeDocuments({
        envelopeWsid: envelopeWsid
      }).then(res => {
        let documents = res.data.data.documents;
        if (documents.length > 1) {
          this.type = "ZIP";
        } else {
          this.type = "PDF";
        }
        MessageBox.confirm("", {
          title: "提示",
          message: `您确定下载文件《${title}》?`,
          confirmButtonText: "确定"
        }).then(
          () => {
            return downloadEnvelope({
              envelopeWsid: envelopeWsid,
              name: title,
              withAudit: false,
              type: this.type
            })
              .then(_ => {
                Toast({
                  message: "获取文件成功，正在下载",
                  iconClass: "icon icon-confirm"
                });
              })
              .catch(err => {
                Toast({
                  message: "获取文件失败",
                  iconClass: "icon icon-refuse"
                });
              });
          },
          () => {}
        );
      });
    },
    loadMore() {
      if (this.allLoaded) {
        //加载完所有数据，则不再触发loadMore方法
        Toast({
          message: "已经加载所有文件了哦",
          duration: 1000
        });
        this.moreLoading = false;
        return;
      }
      let query = this.nowQuery;

      if (parseInt(this.currentPage) < this.totalPages) {
        this.currentPage = parseInt(this.currentPage) + 1;
      }
      this.updateQuery(query);
      this.moreLoading = true;
    },
    tagClass(status) {
      let statusCode = EnvelopeStatus.getCodeByKey(status);
      switch (statusCode) {
        case 1:
          return "wesign-mobile-tag-others"; //草稿
        case 2:
          return "wesign-mobile-tag-others"; //等待发送
        case 3:
          return "wesign-mobile-tag-others"; //挂起
        case 4:
          return "wesign-mobile-tag-others"; //处理中(挂起待确认)
        case 101:
          return "wesign-mobile-tag-others"; //投递中
        case 102:
          return "wesign-mobile-tag-others"; //流程处理中
        case 103:
          return "wesign-mobile-tag-others"; //流程结束系统处理中
        case 104:
          return "wesign-mobile-tag-me-sign"; //待我签
        case 105:
          return "wesign-mobile-tag-me-sign"; //待我审核
        case 106:
          return "wesign-mobile-tag-me-sign"; //待他人处理
        case 107:
          return "wesign-mobile-tag-me-sign"; //待我纠正
        case 108:
          return "wesign-mobile-tag-me-sign"; //待他人纠正
        case 109:
          return "wesign-mobile-tag-waiting-join-enterprise"; //待加入企业
        case 201:
          return "wesign-mobile-tag-complete"; //已完成
        case 202:
          return "wesign-mobile-tag-others"; //已完成（作废）
        case 203:
          return "wesign-mobile-tag-waiting-join-enterprise"; //已被拒签
        case 204:
          return "wesign-mobile-tag-waiting-join-enterprise"; //审核未通过
        case 205:
          return "wesign-mobile-tag-others"; //已被撤销
        case 206:
          return "wesign-mobile-tag-others"; //超时未签
        case 207:
          return "wesign-mobile-tag-others"; //废弃
        case 210:
          return "wesign-mobile-tag-others"; //超时未签
        default:
          return "wesign-mobile-tag-others"; //未知
      }
    },
    getStatus(status) {
      return EnvelopeStatus.getStatusNameByKey(status);
    },
    getDate(date) {
      return newFormatDate(date, "hh:mm:ss");
    },
    changeStatus: function(type) {
      this.envelopes = [];
      this.allLoaded = false;
      this.currentPage = 1;
      this.listActive = type;
      Indicator.open();

      this.$router.replace({
        path: "/envelopes",
        query: {
          status: type
        }
      });

      this.$nextTick(_ => {
        this.random = Math.random();
        this.getEnvelopesData({
          status: type
        });
      });
    },
    updateQuery(newQuery) {
      this.getEnvelopesData(newQuery);
      this.$router.replace({
        path: "/envelopes",
        query: newQuery
      });
    },
    getEnvelopeDetail(id) {
      this.$router.push("/envelopes/" + id + "/detail/");
    }
  },
  components: {
    docNav
  }
};
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.title {
  background: @color-main;
  height: 50 * @px;
  text-align: center;
  p {
    line-height: 50 * @px;
    color: @color-white;
    font-size: @font-size-title;
  }
}
.doc-container {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  top: 50 * @px;
  overflow: scroll;
}
.doc-container-no {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  top: 50 * @px;
  text-align: center;
  .bg-pic {
    position: absolute;
    height: 160 * @px;
    width: 250 * @px;
    left: 50%;
    top: 45%;
    transform: translate(-50%, -50%);
    color: #9b9ea2;
    img {
      width: 200 * @px;
    }
  }
}
.envelope-list {
  display: flex;
  height: 80 * @px;
  position: relative;
  margin: 0.1rem 0.2rem;
  box-shadow: rgba(0, 0, 0, 0.06) 0 0 0.2rem 0.01rem;
  border-radius: 5px;
  background: #fff;
}
.doc-detail {
  flex: 1;
  padding: 10 * @px;
  p {
    line-height: 1.5;
  }
}
.doc-name {
  font-size: @font-size-primary;
  color: @color-title;
  max-width: 200 * @px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  display: inline-block;
}
.doc-bulk-tag {
  font-size: @font-size-regular;
  color: @color-title;
  width: 40 * @px;
  background: #0c7ffc;
  border-radius: 4 * @px;
  text-align: center;
  color: #fff;
  margin: 0 5 * @px;
  line-height: 1.5;
}
.date {
  font-size: @font-size-info;
  color: @color-main;
}
.send-people {
  font-size: @font-size-info;
  color: #999;
  width: 250 * @px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.doc-status {
  position: absolute;
  left: 0;
  bottom: 0;
  color: @color-white;
  line-height: 25 * @px;
  width: 70 * @px;
  transform: translate(-50%, 0);
  text-align: center;
}
.more-loading {
  height: 30 * @px;
  text-align: center;
  span {
    position: absolute;
  }
}
.download {
  font-size: 0.24rem;
  display: inline-block;
  color: #4e82ee;
  position: absolute;
  bottom: 10 * @px;
  right: 10 * @px;
  cursor: pointer;
}
</style>
