import { MessageBox } from "element-ui"

import {getUserMessages} from "@interfaces/message-pusher/system-message.js"
import { backendClient } from "@interfaces/web-socket/wsclient.js"
import { notifyer } from "@notifications/index.js"

function initData(){
    return {
        totalElements: 0,
    }
}

const module_userMessage = {
    state: initData(),
    getters: {
        totalElements(state){
            return state.totalElements
        },
    },
    mutations: {
        increaseTotalElements(state){
            state.totalElements = state.totalElements + 1 
        },
        accpetNotification(state){
            state.notificationAble = true
        }
    },
    actions: {
        async initListenPushMessage({commit, dispatch, getters}){
            let session
            try {
                session = document.cookie.split(";").map(data => data.split("=").map(_ => _.trim())).find(_ => _[0] === "SessionWsid")[1]
            } catch (err){
                console.error(err)
            }
            if (session){
                //解除之前的绑定
                backendClient.off("push-message")
                backendClient.off("reconnect")
                
                backendClient.emit("regist-puser", {session})
                backendClient.on("push-message", data => {
                    if (data.actionType === "SYSTEM_ENTERPRISE_USER_DISABLE"){ //被企业禁用
                        dispatch("messageOfUserBeenDisabled", data)
                    } else if (data.actionType === "SYSTEM_CHANGE_BIND_WEAPP"){
                        dispatch("updateUserData")
                        try {
                            commit("increaseTotalElements")
                        } catch (err){
                            
                        }
                    } else if (data.actionType === "SYSTEM_UNBIND_WEAPP"){
                        dispatch("updateUserData")
                        try {
                            commit("increaseTotalElements")
                        } catch (err){
                            
                        }
                    } else {
                        try {
                            notifyer.notify(data)
                            commit("increaseTotalElements")
                        } catch (err){
                            
                        }
                    }
                })

                backendClient.on("reconnect", _ => {
                    dispatch("initListenPushMessage")
                })
            }
        },
        async updateUserMessage({state, getters}, data){
            return getUserMessages({
                userWsid: getters.userWsid,
                filters: data.filters,
                offset: data.offset,
                limit: data.limit,
                sorts: data.sorts
            }).then(res => {
                let pages = res.data.data.page
                if (data.filters == "isread=false"){
                    state.totalElements = pages.totalElements || 0
                }
                return res
            })
        },
        messageOfUserBeenDisabled({dispatch, getters}, message){
            //检查当前所在企业
            let targetUserWsid = message.attachMessage.targertWsid
            let activeUserWsid = getters.activeUserWsid
            let accounts = getters.userAccounts
            let account = accounts.find(account => account.userWsid === activeUserWsid)
            if (targetUserWsid === activeUserWsid){ //是当前的,提示并弹出
                MessageBox.alert(`您已被当前企业(${account.enterpriseName})禁用,无法访问该企业资源,即将退出系统`, "提醒", {
                    type: "warning"
                }).then(_ => {}, _ => {}).then(_ => {
                    dispatch("user_logout")
                })
            } else {
                dispatch("updateUserAccounts")
            }
        }
    }
}

export default module_userMessage
