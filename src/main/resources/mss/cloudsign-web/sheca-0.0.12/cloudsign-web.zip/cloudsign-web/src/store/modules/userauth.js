import { getVerifications, getVerificationInfo, personAuth } from '@interfaces/auth/auth.js'
import { _assignObjectWithSrcProperties } from '@commons/util.js'

const module_userAuth = {
    state: {
        description: "", //描述
        info: {},
        status: "NO",
        submitDatetime: 0, //提交时间
        handleDatetime: 0,
        expireDatetime: 0,
        wsid: "",
        realName: "", //真实姓名
        userWsid: "",
    },
    getters: {
        idttvWsid(state) {
            return state.wsid
        },
        authInfo(state) {
            return state.info
        }
    },
    actions: {
        // async updateModule({state, dispatch}) {
        //     return dispatch("updateAuthData")
        // },
        updateAuthData({state, getters, dispatch}) {
            let userWsid = getters.userPWsid
            return getVerifications({
                filters: `user_wsid=${userWsid}` //FIXME: 后端目前只支持下划线
            }).then(body => {
                if (body.data.identities[0]){
                    state.wsid = body.data.identities[0].wsid
                    return dispatch("updateAuthInfo")
                } else {
                    return dispatch("createUserAuth")
                }
            })
        },
        updateAuthInfo({state}) {
            let idttvWsid = state.wsid
            return getVerificationInfo({
                idttvWsid
            }).then(body => {
                _assignObjectWithSrcProperties(state, body.data.identity, 1)
            })
        },
        createUserAuth({state, getters, dispatch}) {
            let userWsid = getters.userWsid
            return personAuth({
                userWsid
            }).then(body => {
                state.wsid = body.data.identity.wsid
                return dispatch("updateAuthInfo")
            })
        }
    }
}

export default module_userAuth