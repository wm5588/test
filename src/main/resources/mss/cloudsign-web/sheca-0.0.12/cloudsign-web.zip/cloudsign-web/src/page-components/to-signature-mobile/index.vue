<template>
    <div class="page-container"></div>
</template>

<script>
import base from "@page-components/to-signature/index.vue"
import {Indicator, MessageBox} from "mint-ui"

export default {
    mixins: [base],
    methods: {
        init(){
            Indicator.open()
            this.check().then(_ => {
                let action = this.$route.query.action
                let envelopeWsid = this.$route.query.envelopeWsid
                let pageCallback = this.$route.query.pageCallback
                let selectedAuthTypes = this.$route.query.selectedAuthTypes
                let enableNoAppearance = this.$route.query.enableNoAppearance
                let enableSimpleDisplay =  this.$route.query.enableSimpleDisplay
                let appId = this.$route.query.appId
                if (action === "SIGN"){
                    this.$router.replace({
                        path: "/sign",
                        query: {
                            envelopeWsid,
                            action,
                            selectedAuthTypes,
                            enableNoAppearance,
                            enableSimpleDisplay,
                            pageCallback,
                            appId,
                            circleAngle:this.circleAngle,
                            themeColor:this.themeColor
                        }
                    })
                } else {
                    this.$router.replace({
                        path: "/check",
                        query: {
                            envelopeWsid,
                            action,
                            selectedAuthTypes,
                            enableNoAppearance,
                            enableSimpleDisplay,
                            pageCallback,
                            appId,
                            circleAngle:this.circleAngle,
                            themeColor:this.themeColor
                        }
                    })
                }
            }).catch(err => {
                console.log(err)
                switch (err.message){
                    case "ERROR_NOT_LOGIN":
                        MessageBox.alert("未登录，请先登录", "提示").then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = `/login?targetURL=${encodeURIComponent(location.href)}`
                        })
                        break
                    case "ERROR_INCOMPLETE_LINK_PARAMETERS":
                        MessageBox.alert("参数不完整，请输入完整的链接!", "提示").then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    case "ERROR_UNSUPPORTED_OPERATIONS":
                        MessageBox.alert("不支持的操作方式!", "提示").then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    case "ERROR_AUTHENTICATION_IS_WAITING_REVIEW":
                        MessageBox.alert("您的实名认证信息正在审核中，暂时不能进行该操作，请耐心等待或者联系客服 021-962600", "提示", {
                            confirmButtonText: "我知道了",
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_AUTHENTICATION_HAS_BEEN_REJECTED":
                        MessageBox.alert("您的实名认证信息未通过审核，您可重新提交认证信息", "提示", {
                            confirmButtonText: "前往登录认证",
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_AUTHENTICATION_INFORMATION_IS_EXPIRED":
                        MessageBox.alert("您的实名认证信息已过期，将影响功能的正常使用，请重新认证", "提示", {
                            confirmButtonText: "前往登录认证",
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_AUTHENTICATION_INFORMATION_IS_NULL":
                        MessageBox.alert("您尚未进行实名认证，签署的文件不具备法律效力，暂时不能进行该操作，请完成实名认证", "提示", {
                            confirmButtonText: "前往登录认证",
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ENTERPRISE_AUTHENTICATION_IS_ERROR":
                        MessageBox.alert("您当前的企业未完成实名认证，签署的文件不具备法律效力，暂时不能进行该操作，请完成企业的实名认证", "提示", {
                            confirmButtonText: "前往登录认证",
                            cancelButtonText: "取消",
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            localStorage.setItem("AUTH_AUTO", "True")
                            if (this.$route.query.username) localStorage.setItem("AUTH_USERNAME_LOCK", this.$route.query.username)
                            if (this.$route.query.phone) localStorage.setItem("AUTH_PHONE_LOCK", this.$route.query.phone)
                            localStorage.setItem("AUTH_CALLBACK_URL", location.href)
                            location.href = "/login"
                        })
                        break
                    case "ERROR_WAITING_JOIN_ENTERPRISE":
                        MessageBox({
                            title: "提示",
                            message: "您不是企业成员，请先加入企业",
                            showConfirmButton: true,
                            confirmButtonText: "退出"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_NOT_IN_ENVELOPE_FLOW":
                        MessageBox({
                            title: "提示",
                            message: "您不是签署方，无权限访问",
                            showConfirmButton: true,
                            confirmButtonText: "返回"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_NOT_A_SIGNER":
                        MessageBox({
                            title: "提示",
                            message: "您不是签署方，无法进行签署操作",
                            showConfirmButton: true,
                            confirmButtonText: "返回"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_NOT_A_CHECKER":
                        MessageBox({
                            title: "提示",
                            message: "您不是审核方，无法进行签署操作",
                            showConfirmButton: true,
                            confirmButtonText: "返回"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.href = "/login"
                        })
                        break
                    case "ERROR_NEED_WAIT_OTHER":
                        MessageBox({
                            title: "提示",
                            message: "未轮到您处理请耐心等待",
                            showConfirmButton: true,
                            confirmButtonText: "退出",
                        }).then(_ => {
                            location.href = "/login"
                        }, _ => {})
                        break
                    case "ERROR_ALREADY_DONE":
                        MessageBox.alert("您已经完成过对这份文档的操作,本次签署服务已经结束!", "提示", {
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ENVELOPE_STATUS_IS_NOT_MATCH":
                         MessageBox({
                            title: "提示",
                            message: "系统繁忙请稍后再试",
                            showConfirmButton: true,
                            showCancelButton: true,
                            confirmButtonText: "刷新",
                            cancelButtonText: "退出"
                        }).then(_ => {
                            if(_ === "confirm"){
                                location.reload()
                            } else {
                                location.href = "/login"
                            }
                        }, _ => {})
                        break
                    case "ERROR_ENVELOPE_HAD_BEEN_REVOKED":
                        MessageBox.alert("对不起,该文档已被撤销,您目前不能进行操作", "提示", {
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ENVELOPE_HAD_BEEN_ED_FAIL_EXPIRED":
                         MessageBox.alert("对不起,该文档已过期,您目前不能进行操作", "提示", {
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    case "ERROR_ENVELOPE_HAD_BEEN_REJECTED":
                        MessageBox.alert("对不起,该文档已被拒签,您目前不能进行操作", "提示", {
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                        break
                    default:
                        MessageBox.alert("对不起,遇到了未知的错误", "提示", {
                        }).then(_ => {}, _ => {}).then(_ => {
                            //TODO: 跳转
                            location.href = "/login"
                        })
                }
            }).then(_ => {
                Indicator.close()
            })
        }
    }
}
</script>
<style lang="less" scoped>
.page-container{
    position: absolute;
    top:0;
    left: 0;
    bottom: 0;
    right: 0;
}
</style>
